# Temo-Learn (Jakarta EE · Tomcat 10.1 / 11 · MySQL)

Sustainable-agriculture learning platform for Botswana: public site, student portal, teacher portal, admin console.

| Layer | What it is |
|---|---|
| Controllers | Java **servlets** (`bw.temo.web`, `bw.temo.api`) |
| Views | **JSP + JSTL**, layouts as tag files (`WEB-INF/tags`) |
| Browser code | plain **JavaScript** ES modules (`webapp/js`, `webapp/js/pages`), no inline scripts |
| Database | **MySQL 8.0.13+** (MariaDB 10.5+ also works), tables created automatically on first start |
| Server | **Tomcat 10.1 or 11** (Jakarta namespace). Tomcat 9 will NOT work. |

## 1. Database

Start MySQL, then nothing else is needed if you connect as `root`: the app creates the `temolearn` database and all tables itself on first start. Tell it your MySQL password:

* IntelliJ: Run > Edit Configurations > Tomcat > **Startup/Connection** or **Server** tab > Environment variables: `TEMO_DB_PASSWORD=your_mysql_password`
* or put it in `src/main/resources/temo.properties` (`db.password=`).

If you prefer a dedicated user (recommended outside your own PC):

```sql
CREATE USER 'temo'@'localhost' IDENTIFIED BY 'choose-a-password';
CREATE DATABASE temolearn CHARACTER SET utf8mb4;
GRANT ALL ON temolearn.* TO 'temo'@'localhost';
```
and set `TEMO_DB_USER=temo`, `TEMO_DB_PASSWORD=choose-a-password`.

## 2. Build and deploy

```bash
mvn clean package            # -> target/temo-learn.war
cp target/temo-learn.war $CATALINA_HOME/webapps/
$CATALINA_HOME/bin/startup.sh
```

Open http://localhost:8080/temo-learn/. To serve from `/`, name the WAR `ROOT.war`. Both work; every URL is context-path safe.

IntelliJ: Add Configuration > Tomcat Server (Local) > Deployment: `temo-learn:war exploded`. In the Deployment tab, set *Application context* to `/temo-learn` (or `/`).

## 3. Settings

Each can be set as an environment variable, a `-D` JVM option (`CATALINA_OPTS="-Dtemo.db.url=..."`), or in `src/main/resources/temo.properties`.

| Env var | Default | |
|---|---|---|
| `TEMO_DB_URL` | `jdbc:mysql://localhost:3306/temolearn?createDatabaseIfNotExist=true&...` | |
| `TEMO_DB_USER` / `TEMO_DB_PASSWORD` | `root` / *(empty)* | |
| `TEMO_ADMIN_EMAIL` | `admin@temolearn.local` | first admin, created only if no admin exists |
| `TEMO_ADMIN_PASSWORD` | *(empty)* | empty = a random password is generated and printed once in `logs/catalina.out` |
| `TEMO_COOKIE_SECURE` | `false` | set `true` behind https |

## 4. Roles and pages

* **Public** `/`, `/courses`, `/about`, `/contact`, `/login`, `/signup`. Sign-up creates students only.
* **Student** `/portal/student` (dashboard), `/courses` (My Learning + learner view), `/explore`, `/games`, `/profile`.
* **Teacher** `/portal/teacher` (+ `/courses`, `/editor?id=`, `/students`, `/games`, `/profile`). Created by an admin.
* **Admin** `/portal/admin` (+ `/users`, `/content`, `/feedback`).

JSON endpoints live under `/api/{common,student,teacher,admin}/...`.

## 5. Security (replaces the old Firestore rules)

Roles are checked on the server for every page and API call (account reloaded from the DB each request, so disabling a user is immediate) · PBKDF2 password hashing · login throttling · session-fixation protection · CSRF token on every POST/PUT/DELETE · strict CSP (`script-src 'self'`) · quizzes are graded on the server and the answer key is never sent to learners · locked sections are withheld server-side · teachers can only change their own courses · all SQL is parameterised.

## 6. Good to know

* **Starter courses**: the 10 syllabus entries come from `src/main/resources/starter-courses.json` (seeded once, shown on the public site, copyable by teachers). Edit that file to change the syllabus text before first start.
* **No email service**: there is no "forgot password" email. An admin resets passwords from Admin > Users.
* **Page background photos** are optional: see the comment in `css/style.css` (`--page-bg`).
* Uploaded profile pictures and course thumbnails are stored in the database as small data-URIs (size-capped).
