package bw.temo.config;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Settings come from (highest priority first):
 *   1. JVM property     -Dtemo.db.url=...
 *   2. environment      TEMO_DB_URL=...
 *   3. temo.properties  (inside the WAR, in WEB-INF/classes)
 */
public final class AppConfig {
    private static final Properties FILE = new Properties();

    static {
        try (InputStream in = AppConfig.class.getClassLoader().getResourceAsStream("temo.properties")) {
            if (in != null) FILE.load(new java.io.InputStreamReader(in, java.nio.charset.StandardCharsets.UTF_8));
        } catch (IOException e) {
            throw new ExceptionInInitializerError(e);
        }
    }

    private AppConfig() {}

    public static String get(String key, String fallback) {
        String v = System.getProperty("temo." + key);
        if (v == null || v.isBlank()) v = System.getenv("TEMO_" + key.toUpperCase().replace('.', '_'));
        if (v == null || v.isBlank()) v = FILE.getProperty(key);
        return v == null || v.isBlank() ? fallback : v.trim();
    }

    public static boolean getBool(String key, boolean fallback) {
        String v = get(key, null);
        return v == null ? fallback : Boolean.parseBoolean(v);
    }

    public static int getInt(String key, int fallback) {
        try {
            return Integer.parseInt(get(key, String.valueOf(fallback)));
        } catch (NumberFormatException e) {
            return fallback;
        }
    }
}
