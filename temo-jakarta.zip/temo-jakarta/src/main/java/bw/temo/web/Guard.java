package bw.temo.web;

import bw.temo.dao.Courses;
import bw.temo.dao.Enrollments;
import java.sql.SQLException;
import java.util.Map;

/** The "is this yours?" checks. Every API handler that touches a course goes through one of these. */
public final class Guard {
    private Guard() {}

    /** Teachers may change only courses they wrote. Admins may change any (but never the built-in starters). */
    public static Map<String, Object> editableCourse(Ctx c, String courseId) throws SQLException {
        Map<String, Object> course = Courses.byId(courseId);
        if (course == null || "starter".equals(course.get("status"))) throw ApiException.notFound();
        if (!c.isAdmin() && !c.uid().equals(course.get("authorId"))) throw ApiException.forbidden();
        return course;
    }

    public static Map<String, Object> editableModule(Ctx c, String moduleId) throws SQLException {
        Map<String, Object> m = Courses.moduleById(moduleId);
        if (m == null) throw ApiException.notFound();
        editableCourse(c, (String) m.get("courseId"));
        return m;
    }

    public static Map<String, Object> editableItem(Ctx c, String itemId) throws SQLException {
        Map<String, Object> i = Courses.itemById(itemId);
        if (i == null) throw ApiException.notFound();
        editableCourse(c, (String) i.get("courseId"));
        return i;
    }

    /** A learner may use a course only while it is published and they are enrolled. */
    public static Map<String, Object> learnerCourse(Ctx c, String courseId) throws SQLException {
        Map<String, Object> course = Courses.byId(courseId);
        if (course == null || !"published".equals(course.get("status"))) throw ApiException.notFound();
        if (!Enrollments.exists(c.uid(), courseId)) throw new ApiException(403, "permission-denied", "You are not enrolled in this course.");
        return course;
    }

    /** An activity of the course that is in an open (unlocked) section. */
    public static Map<String, Object> learnerItem(String courseId, String itemId) throws SQLException {
        Map<String, Object> item = Courses.itemById(itemId);
        if (item == null || !courseId.equals(item.get("courseId"))) throw ApiException.notFound();
        Map<String, Object> mod = Courses.moduleById((String) item.get("moduleId"));
        if (mod == null || Boolean.TRUE.equals(mod.get("locked"))) {
            throw new ApiException(403, "permission-denied", "That section isn't open yet.");
        }
        return item;
    }

    public static boolean isRole(Ctx c, String... roles) {
        for (String r : roles) if (r.equals(c.role())) return true;
        return false;
    }
}
