package bw.temo.web;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

/**
 * Every signed-in page. Who may open which area is decided by AuthFilter; this servlet only
 * maps the URL to a JSP. The page itself loads its data from the /api servlets.
 */
@WebServlet(name = "PortalPages", urlPatterns = "/portal/*")
public class PortalPages extends HttpServlet {
    private static final Map<String, String> VIEWS = Map.ofEntries(
        Map.entry("/student", "portal/student"),
        Map.entry("/student/courses", "portal/student-courses"),
        Map.entry("/student/explore", "portal/student-explore"),
        Map.entry("/student/games", "portal/student-games"),
        Map.entry("/student/profile", "portal/student-profile"),
        Map.entry("/teacher", "portal/teacher"),
        Map.entry("/teacher/courses", "portal/teacher-courses"),
        Map.entry("/teacher/editor", "portal/teacher-editor"),
        Map.entry("/teacher/students", "portal/teacher-students"),
        Map.entry("/teacher/games", "portal/teacher-games"),
        Map.entry("/teacher/profile", "portal/teacher-profile"),
        Map.entry("/admin", "portal/admin"),
        Map.entry("/admin/users", "portal/admin-users"),
        Map.entry("/admin/content", "portal/admin-content"),
        Map.entry("/admin/feedback", "portal/admin-feedback"));

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String path = req.getPathInfo() == null ? "" : req.getPathInfo();
        if (path.length() > 1 && path.endsWith("/")) path = path.substring(0, path.length() - 1);
        String view = VIEWS.get(path);
        if (view == null) { resp.sendError(HttpServletResponse.SC_NOT_FOUND); return; }
        Web.render(req, resp, view);
    }
}
