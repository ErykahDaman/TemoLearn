package bw.temo.web;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Base class for the JSON API servlets. A subclass is mapped to a URL prefix such as /api/student/*
 * and registers its routes in routes(). Who may call the prefix is decided in AuthFilter;
 * what each caller may touch (their own data only) is checked inside the handlers.
 */
public abstract class ApiServlet extends HttpServlet {
    private static final Logger LOG = Logger.getLogger(ApiServlet.class.getName());
    private final Router router = new Router();

    protected abstract void routes(Router r);

    @Override
    public void init() throws ServletException {
        routes(router);
    }

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        req.setCharacterEncoding("UTF-8");
        String path = req.getPathInfo();
        Router.Match m = router.find(req.getMethod(), path == null ? "/" : path);
        Ctx c = new Ctx(req, resp, m == null || m.params() == null ? Map.of() : m.params());
        try {
            if (m == null) throw ApiException.notFound();
            if (m.handler() == null) throw new ApiException(405, "method-not-allowed", "That action isn't allowed here.");
            m.handler().handle(c);
        } catch (ApiException e) {
            fail(c, e.status, e.code, e.getMessage());
        } catch (IllegalArgumentException e) {
            fail(c, 400, "invalid-argument", e.getMessage());
        } catch (SQLException e) {
            LOG.log(Level.SEVERE, "Database error on " + req.getMethod() + " " + req.getRequestURI(), e);
            fail(c, 500, "internal", "Something went wrong on our side. Please try again.");
        } catch (Exception e) {
            LOG.log(Level.SEVERE, "Error on " + req.getMethod() + " " + req.getRequestURI(), e);
            fail(c, 500, "internal", "Something went wrong on our side. Please try again.");
        }
    }

    private static void fail(Ctx c, int status, String code, String message) {
        if (c.resp.isCommitted()) return;
        Map<String, Object> o = new LinkedHashMap<>();
        o.put("error", message);
        o.put("code", code);
        c.json(status, o);
    }
}
