package bw.temo.web;

import bw.temo.dao.Courses;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

/** The public pages: home, courses, about. Plain GETs rendered by JSP. */
@WebServlet(name = "PublicPages", urlPatterns = {"", "/index", "/courses", "/about"})
public class PublicPages extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String path = req.getServletPath();
        try {
            switch (path) {
                case "/courses" -> {
                    req.setAttribute("courses", Courses.publicCatalogue());
                    Web.render(req, resp, "public/courses");
                }
                case "/about" -> Web.render(req, resp, "public/about");
                default -> {
                    List<Map<String, Object>> all = Courses.publicCatalogue();
                    req.setAttribute("courses", all.subList(0, Math.min(3, all.size())));
                    req.setAttribute("courseCount", all.size());
                    Web.render(req, resp, "public/index");
                }
            }
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }
}
