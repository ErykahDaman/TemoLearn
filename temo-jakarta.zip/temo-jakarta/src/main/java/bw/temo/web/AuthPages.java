package bw.temo.web;

import bw.temo.db.Db;
import bw.temo.api.CommonApi;
import bw.temo.config.AppConfig;
import bw.temo.dao.Feedback;
import bw.temo.dao.Users;
import bw.temo.security.LoginThrottle;
import bw.temo.security.Sessions;
import bw.temo.util.Passwords;
import bw.temo.util.Text;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Map;

/** Log in, sign up, log out and the contact form. These are ordinary HTML form posts. */
@WebServlet(name = "AuthPages", urlPatterns = {"/login", "/signup", "/logout", "/contact"})
public class AuthPages extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        switch (req.getServletPath()) {
            case "/login" -> {
                Map<String, Object> u = Sessions.current(req);
                if (u != null) { resp.sendRedirect(req.getContextPath() + Sessions.homeFor(u.get("role"))); return; }
                if (req.getParameter("disabled") != null) req.setAttribute("error", "This account has been disabled. Please contact an admin.");
                if (req.getParameter("expired") != null) req.setAttribute("error", "That page was open for too long. Please try again.");
                req.setAttribute("next", Web.param(req, "next"));
                Web.render(req, resp, "public/login");
            }
            case "/signup" -> {
                Map<String, Object> u = Sessions.current(req);
                if (u != null) { resp.sendRedirect(req.getContextPath() + Sessions.homeFor(u.get("role"))); return; }
                if (req.getParameter("expired") != null) req.setAttribute("error", "That page was open for too long. Please try again.");
                req.setAttribute("teachersOpen", AppConfig.getBool("signup.teachers", true));
                req.setAttribute("role", "teacher".equals(req.getParameter("role")) ? "teacher" : "student");
                Web.render(req, resp, "public/signup");
            }
            case "/contact" -> {
                if (req.getParameter("expired") != null) req.setAttribute("error", "That page was open for too long. Please send it again.");
                if (req.getParameter("sent") != null) req.setAttribute("sent", true);
                Web.render(req, resp, "public/contact");
            }
            default -> resp.sendRedirect(req.getContextPath() + "/");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            switch (req.getServletPath()) {
                case "/login" -> login(req, resp);
                case "/signup" -> signup(req, resp);
                case "/logout" -> {
                    Sessions.signOut(req);
                    resp.sendRedirect(req.getContextPath() + "/");
                }
                case "/contact" -> contact(req, resp);
                default -> resp.sendError(404);
            }
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }

    private void login(HttpServletRequest req, HttpServletResponse resp) throws SQLException, ServletException, IOException {
        String email = Text.email(Web.param(req, "email"));
        String password = req.getParameter("password") == null ? "" : req.getParameter("password");
        String ipKey = "ip:" + req.getRemoteAddr();
        String mailKey = "mail:" + email;
        req.setAttribute("email", email);
        req.setAttribute("next", Web.param(req, "next"));

        if (LoginThrottle.blocked(ipKey) || LoginThrottle.blocked(mailKey)) {
            req.setAttribute("error", "Too many tries. Wait a few minutes and try again.");
            resp.setStatus(429);
            Web.render(req, resp, "public/login");
            return;
        }
        Map<String, Object> cred = email.isEmpty() ? null : Users.credential(email);
        // Always do the hashing work, so "no such account" and "wrong password" take the same time.
        boolean ok = false;
        if (cred != null) ok = Passwords.verify(password, (String) cred.get("hash"));
        else Passwords.burn();
        if (!ok) {
            LoginThrottle.fail(ipKey);
            LoginThrottle.fail(mailKey);
            req.setAttribute("error", "Wrong email or password.");
            resp.setStatus(401);
            Web.render(req, resp, "public/login");
            return;
        }
        if (Boolean.TRUE.equals(cred.get("disabled"))) {
            req.setAttribute("error", "This account has been disabled. Please contact an admin.");
            resp.setStatus(403);
            Web.render(req, resp, "public/login");
            return;
        }
        LoginThrottle.clear(mailKey);
        String uid = (String) cred.get("uid");
        Users.touchLogin(uid);
        Sessions.signIn(req, uid);
        Map<String, Object> u = Users.byId(uid);
        String next = Web.safeNext(req, Web.param(req, "next"));
        resp.sendRedirect(next != null ? next : req.getContextPath() + Sessions.homeFor(u.get("role")));
    }

    private void signup(HttpServletRequest req, HttpServletResponse resp) throws SQLException, ServletException, IOException {
        String name = Text.clip(req.getParameter("name"), 100);
        String email = Text.email(Web.param(req, "email"));
        String password = req.getParameter("password") == null ? "" : req.getParameter("password");
        String confirm = req.getParameter("confirm") == null ? "" : req.getParameter("confirm");
        // Only these two roles can be chosen here. Admin accounts are never created from the public form.
        boolean teachersOpen = AppConfig.getBool("signup.teachers", true);
        String role = "teacher".equals(req.getParameter("role")) ? "teacher" : "student";
        req.setAttribute("name", name);
        req.setAttribute("email", email);
        req.setAttribute("role", role);
        req.setAttribute("teachersOpen", teachersOpen);

        String problem = null;
        if (role.equals("teacher") && !teachersOpen) problem = "Teacher accounts are set up by an admin. Please contact us.";
        else if (name.isEmpty()) problem = "Enter your full name.";
        else if (!Text.looksLikeEmail(email)) problem = "That email doesn't look right.";
        else if (!password.equals(confirm)) problem = "Those passwords don't match.";
        else {
            try { CommonApi.checkNewPassword(password); } catch (ApiException e) { problem = e.getMessage(); }
        }
        if (problem == null && Users.emailTaken(email)) problem = "That email already has an account.";
        if (problem == null) {
            try {
                String uid = Users.create(name, email, Passwords.hash(password), role, null);
                Users.touchLogin(uid);
                Sessions.signIn(req, uid);
                resp.sendRedirect(req.getContextPath() + Sessions.homeFor(role));
                return;
            } catch (SQLException e) {
                if (!Db.isDuplicate(e)) throw e;
                problem = "That email already has an account.";
            }
        }
        req.setAttribute("error", problem);
        resp.setStatus(400);
        Web.render(req, resp, "public/signup");
    }

    private void contact(HttpServletRequest req, HttpServletResponse resp) throws SQLException, ServletException, IOException {
        if (!Web.param(req, "website").isEmpty()) {   // hidden field: only bots fill it in
            resp.sendRedirect(req.getContextPath() + "/contact?sent=1");
            return;
        }
        String name = Text.clip(req.getParameter("name"), 100);
        String email = Text.clip(req.getParameter("email"), 150);
        String subject = Text.clip(req.getParameter("subject"), 200);
        String message = Text.clip(req.getParameter("message"), 2000);
        if (name.isEmpty() || !Text.looksLikeEmail(email) || message.isEmpty()) {
            req.setAttribute("error", "Please fill in your name, a valid email and a message.");
            req.setAttribute("name", name);
            req.setAttribute("email", email);
            req.setAttribute("message", message);
            resp.setStatus(400);
            Web.render(req, resp, "public/contact");
            return;
        }
        Feedback.add(null, name, email, "visitor", "contact", subject, message);
        resp.sendRedirect(req.getContextPath() + "/contact?sent=1");
    }
}
