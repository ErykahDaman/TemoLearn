package bw.temo.web;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/** Sets UTF-8 and the security headers on every response. */
public class SecurityFilter implements Filter {
    /*
     * Everything the site runs is served from this origin (no inline scripts), so script-src is 'self'.
     * Inline style attributes are used by the pages, hence style-src 'unsafe-inline'.
     * Games and videos come from other https sites, so frames may load any https page.
     */
    private static final String CSP = String.join("; ",
        "default-src 'self'",
        "script-src 'self'",
        "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
        "font-src 'self' https://fonts.gstatic.com",
        "img-src 'self' data: https:",
        "frame-src https:",
        "connect-src 'self'",
        "object-src 'none'",
        "base-uri 'self'",
        "form-action 'self'",
        "frame-ancestors 'self'");

    @Override
    public void doFilter(ServletRequest rq, ServletResponse rs, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) rq;
        HttpServletResponse resp = (HttpServletResponse) rs;
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        resp.setHeader("Content-Security-Policy", CSP);
        resp.setHeader("X-Content-Type-Options", "nosniff");
        resp.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
        resp.setHeader("X-Frame-Options", "SAMEORIGIN");
        resp.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
        String uri = req.getRequestURI();
        if (uri.contains("/portal/") || uri.contains("/api/") || uri.endsWith("/login") || uri.endsWith("/signup")) {
            resp.setHeader("Cache-Control", "no-store");
        }
        chain.doFilter(rq, rs);
    }
}
