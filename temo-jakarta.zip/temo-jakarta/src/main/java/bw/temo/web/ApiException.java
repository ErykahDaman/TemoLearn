package bw.temo.web;

/** An error the API turns into {"error": "...", "code": "..."} with an HTTP status. */
public class ApiException extends RuntimeException {
    public final int status;
    public final String code;

    public ApiException(int status, String code, String message) {
        super(message);
        this.status = status;
        this.code = code;
    }

    public static ApiException badRequest(String msg) { return new ApiException(400, "invalid-argument", msg); }
    public static ApiException forbidden() { return new ApiException(403, "permission-denied", "You don't have access to that."); }
    public static ApiException notFound() { return new ApiException(404, "not-found", "That doesn't exist (any more)."); }
}
