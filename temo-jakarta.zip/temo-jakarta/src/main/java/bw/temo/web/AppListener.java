package bw.temo.web;

import bw.temo.config.AppConfig;
import bw.temo.dao.Courses;
import bw.temo.dao.Users;
import bw.temo.db.Db;
import bw.temo.util.Json;
import bw.temo.util.Passwords;
import bw.temo.util.Text;
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/** Starts the database, then makes sure there is an admin account and the built-in course syllabus. */
@WebListener
public class AppListener implements ServletContextListener {
    private static final Logger LOG = Logger.getLogger(AppListener.class.getName());

    /** Same emoji and colours as js/avatar.js, so the server-rendered header matches the browser-drawn avatars. */
    private static final Map<String, String> AVATAR_COLORS = Map.ofEntries(
        Map.entry("🌱", "#3f8a48"), Map.entry("🌾", "#9D6612"), Map.entry("🚜", "#6A3E0D"),
        Map.entry("💧", "#4a9fb5"), Map.entry("☀️", "#c9902a"), Map.entry("🐟", "#2f7a8a"),
        Map.entry("🌻", "#b8860b"), Map.entry("🥬", "#2d6a3a"), Map.entry("🍅", "#b5402f"),
        Map.entry("🌽", "#b28641"), Map.entry("🐝", "#8a6a12"), Map.entry("🦎", "#4f7a3a"));

    @Override
    public void contextInitialized(ServletContextEvent e) {
        try {
            e.getServletContext().getSessionCookieConfig().setHttpOnly(true);
            e.getServletContext().getSessionCookieConfig().setSecure(AppConfig.getBool("cookie.secure", false));
            e.getServletContext().setAttribute("avatarColors", AVATAR_COLORS);
            Db.init();
            seedAdmin();
            seedStarters();
        } catch (Exception ex) {
            LOG.log(Level.SEVERE, "Temo-Learn could not start: " + ex.getMessage(), ex);
            throw new IllegalStateException(ex);
        }
    }

    @Override
    public void contextDestroyed(ServletContextEvent e) {
        Db.shutdown();
    }

    private void seedAdmin() throws Exception {
        if (Users.countByRole("admin") > 0) return;
        String email = Text.email(AppConfig.get("admin.email", "admin@temolearn.local"));
        String name = AppConfig.get("admin.name", "Temo Admin");
        String password = AppConfig.get("admin.password", null);
        boolean generated = password == null;
        if (generated) password = randomPassword();
        if (Users.emailTaken(email)) {
            // That email already belongs to a normal account: promote it instead of creating a duplicate.
            Map<String, Object> u = Users.byEmail(email);
            Users.setRole((String) u.get("uid"), "admin");
            LOG.warning("Existing account " + email + " was promoted to admin.");
            return;
        }
        Users.create(name, email, Passwords.hash(password), "admin", null);
        if (generated) {
            LOG.warning("==================================================================");
            LOG.warning(" First administrator created");
            LOG.warning("   email:    " + email);
            LOG.warning("   password: " + password + "   (change it after signing in)");
            LOG.warning("==================================================================");
        } else {
            LOG.info("First administrator created: " + email);
        }
    }

    private static String randomPassword() {
        String chars = "abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        SecureRandom r = new SecureRandom();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 16; i++) sb.append(chars.charAt(r.nextInt(chars.length())));
        return sb.toString();
    }

    @SuppressWarnings("unchecked")
    private void seedStarters() throws Exception {
        if (Courses.countStarters() > 0) return;
        try (InputStream in = AppListener.class.getResourceAsStream("/starter-courses.json")) {
            if (in == null) return;
            Object parsed = Json.parse(new String(in.readAllBytes(), StandardCharsets.UTF_8));
            List<Object> list = (List<Object>) parsed;
            Db.tx(c -> {
                int n = 0;
                for (Object o : list) {
                    Map<String, Object> s = (Map<String, Object>) o;
                    int number = s.get("number") instanceof Number num ? num.intValue() : ++n;
                    Courses.insertStarter(c, number, s);
                }
                return null;
            });
            LOG.info("Loaded " + list.size() + " built-in courses.");
        }
    }
}
