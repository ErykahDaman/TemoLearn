package bw.temo.web;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Maps "METHOD /path/{param}/more" to a handler. Just enough routing for a JSON API. */
public final class Router {
    @FunctionalInterface public interface Handler { void handle(Ctx c) throws Exception; }

    private record Route(String method, String[] parts, Handler handler) {}
    public record Match(Handler handler, Map<String, String> params) {}

    private final List<Route> routes = new ArrayList<>();

    private Router add(String method, String pattern, Handler h) {
        routes.add(new Route(method, split(pattern), h));
        return this;
    }

    public Router get(String pattern, Handler h) { return add("GET", pattern, h); }
    public Router post(String pattern, Handler h) { return add("POST", pattern, h); }
    public Router put(String pattern, Handler h) { return add("PUT", pattern, h); }
    public Router delete(String pattern, Handler h) { return add("DELETE", pattern, h); }

    static String[] split(String path) {
        String p = path == null ? "" : path;
        while (p.startsWith("/")) p = p.substring(1);
        while (p.endsWith("/")) p = p.substring(0, p.length() - 1);
        return p.isEmpty() ? new String[0] : p.split("/");
    }

    /** null: no such path. A Match with a null handler: the path exists but not for this method. */
    public Match find(String method, String path) {
        String[] segs = split(path);
        boolean pathKnown = false;
        for (Route r : routes) {
            if (r.parts.length != segs.length) continue;
            Map<String, String> params = new HashMap<>();
            boolean ok = true;
            for (int i = 0; i < segs.length && ok; i++) {
                String pat = r.parts[i];
                if (pat.startsWith("{") && pat.endsWith("}")) params.put(pat.substring(1, pat.length() - 1), segs[i]);
                else ok = pat.equals(segs[i]);
            }
            if (!ok) continue;
            pathKnown = true;
            if (r.method.equals(method)) return new Match(r.handler, params);
        }
        return pathKnown ? new Match(null, null) : null;
    }
}
