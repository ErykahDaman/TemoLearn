package bw.temo.web;

import bw.temo.security.Sessions;
import bw.temo.util.Json;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Map;

/** One API call: the request, its path parameters and the signed-in user. */
public final class Ctx {
    private static final int MAX_BODY = 1_500_000;

    public final HttpServletRequest req;
    public final HttpServletResponse resp;
    private final Map<String, String> params;
    private Map<String, Object> body;

    Ctx(HttpServletRequest req, HttpServletResponse resp, Map<String, String> params) {
        this.req = req;
        this.resp = resp;
        this.params = params;
    }

    /** A {name} from the route pattern. */
    public String p(String name) {
        return params.get(name);
    }

    public String query(String name) {
        String v = req.getParameter(name);
        return v == null ? "" : v;
    }

    /** The signed-in user's profile map (never null on routes behind the AuthFilter). */
    public Map<String, Object> user() {
        Map<String, Object> u = Sessions.current(req);
        if (u == null) throw new ApiException(401, "unauthenticated", "Please sign in.");
        return u;
    }

    public String uid() {
        return (String) user().get("uid");
    }

    public String role() {
        return (String) user().get("role");
    }

    public boolean isAdmin() {
        return "admin".equals(role());
    }

    /** The JSON request body as an object. An empty body is an empty map. */
    public Map<String, Object> body() {
        if (body != null) return body;
        try (InputStream in = req.getInputStream()) {
            byte[] raw = in.readNBytes(MAX_BODY + 1);
            if (raw.length > MAX_BODY) throw new ApiException(413, "too-large", "That is too much data to send at once.");
            String text = new String(raw, StandardCharsets.UTF_8).trim();
            body = text.isEmpty() ? new java.util.LinkedHashMap<>() : Json.parseObject(text);
        } catch (IOException e) {
            throw ApiException.badRequest("Could not read the request.");
        } catch (IllegalArgumentException e) {
            throw ApiException.badRequest("The request was not valid JSON.");
        }
        return body;
    }

    public void json(int status, Object value) {
        try {
            resp.setStatus(status);
            resp.setContentType("application/json;charset=UTF-8");
            resp.setHeader("Cache-Control", "no-store");
            resp.getWriter().write(Json.stringify(value));
        } catch (IOException e) {
            throw new IllegalStateException(e);
        }
    }

    public void ok(Object value) {
        json(200, value);
    }

    public void ok() {
        json(200, Map.of("ok", true));
    }
}
