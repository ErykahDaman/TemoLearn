package bw.temo.web;

import bw.temo.security.Csrf;
import bw.temo.security.Sessions;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

/** Helpers shared by the page servlets (the ones that show JSP views). */
public final class Web {
    private Web() {}

    /** Forwards to /WEB-INF/views/{view}.jsp with the signed-in user and CSRF token available as ${user} and ${csrf}. */
    public static void render(HttpServletRequest req, HttpServletResponse resp, String view) throws ServletException, IOException {
        Map<String, Object> user = Sessions.current(req);
        req.setAttribute("user", user);
        req.setAttribute("csrf", Csrf.token(req));
        req.setAttribute("year", java.time.Year.now().getValue());
        if (user != null) {
            req.setAttribute("home", req.getContextPath() + Sessions.homeFor(user.get("role")));
            req.setAttribute("homeRel", Sessions.homeFor(user.get("role")).substring(1));
            if (view.startsWith("portal/")) {
                // The page's JavaScript reads this instead of asking the server who is signed in.
                Map<String, Object> me = new java.util.LinkedHashMap<>();
                me.put("uid", user.get("uid"));
                me.put("email", user.get("email"));
                me.put("displayName", user.get("fullName"));
                Map<String, Object> boot = new java.util.LinkedHashMap<>();
                boot.put("user", me);
                boot.put("profile", user);
                boot.put("csrf", req.getAttribute("csrf"));
                req.setAttribute("boot", bw.temo.util.Json.stringify(boot));
            }
        }
        resp.setContentType("text/html;charset=UTF-8");
        req.getRequestDispatcher("/WEB-INF/views/" + view + ".jsp").forward(req, resp);
    }

    public static String param(HttpServletRequest req, String name) {
        String v = req.getParameter(name);
        return v == null ? "" : v.trim();
    }

    /** Only same-site paths are allowed as a post-login destination (stops open redirects). */
    public static String safeNext(HttpServletRequest req, String next) {
        if (next == null || !next.startsWith("/") || next.startsWith("//") || next.contains("\\") || next.contains("\r") || next.contains("\n")) return null;
        if (!next.startsWith("/portal/")) return null;
        return req.getContextPath() + next;
    }
}
