package bw.temo.web;

import bw.temo.security.Csrf;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Set;

/** Every state-changing request (POST, PUT, DELETE) must carry the session's CSRF token. */
public class CsrfFilter implements Filter {
    private static final Set<String> SAFE = Set.of("GET", "HEAD", "OPTIONS");

    @Override
    public void doFilter(ServletRequest rq, ServletResponse rs, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) rq;
        HttpServletResponse resp = (HttpServletResponse) rs;
        if (SAFE.contains(req.getMethod()) || Csrf.valid(req)) { chain.doFilter(rq, rs); return; }

        String path = req.getRequestURI();
        if (path.contains("/api/")) {
            AuthFilter.deny(resp, 403, "csrf", "Your session expired. Refresh the page and try again.");
        } else {
            // A form: send the person back to it with a friendly note.
            String back = path.substring(req.getContextPath().length());
            if (back.isEmpty() || back.equals("/logout")) back = "/";
            resp.sendRedirect(req.getContextPath() + back + (back.contains("?") ? "&" : "?") + "expired=1");
        }
    }
}
