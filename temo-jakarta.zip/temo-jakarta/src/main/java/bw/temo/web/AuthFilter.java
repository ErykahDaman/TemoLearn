package bw.temo.web;

import bw.temo.security.Sessions;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;
import java.util.Set;

/**
 * Guards /portal/* (pages) and /api/* (JSON). The user is reloaded from the database on every
 * request, so disabling an account or changing a role takes effect at once.
 *
 *   /portal/student, /api/student    students only
 *   /portal/teacher, /api/teacher    teachers and admins
 *   /portal/admin,   /api/admin      admins only
 *   anything else under /portal, /api  any signed-in user
 *   /api/public                      open
 */
public class AuthFilter implements Filter {
    @Override
    public void doFilter(ServletRequest rq, ServletResponse rs, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) rq;
        HttpServletResponse resp = (HttpServletResponse) rs;
        String path = req.getRequestURI().substring(req.getContextPath().length());

        if (path.startsWith("/api/public")) { chain.doFilter(rq, rs); return; }

        boolean api = path.startsWith("/api/");
        Map<String, Object> user = Sessions.current(req);
        if (user == null) {
            if (api) deny(resp, 401, "unauthenticated", "Please sign in.");
            else resp.sendRedirect(req.getContextPath() + "/login?next=" + java.net.URLEncoder.encode(path, "UTF-8"));
            return;
        }

        Set<String> allowed = allowedRoles(path, api);
        String role = (String) user.get("role");
        if (!allowed.contains(role)) {
            if (api) deny(resp, 403, "permission-denied", "You don't have access to that.");
            else resp.sendRedirect(req.getContextPath() + Sessions.homeFor(role));
            return;
        }
        chain.doFilter(rq, rs);
    }

    private static Set<String> allowedRoles(String path, boolean api) {
        String area = api ? "/api/" : "/portal/";
        String rest = path.substring(Math.min(path.length(), area.length()));
        String first = rest.contains("/") ? rest.substring(0, rest.indexOf('/')) : rest;
        return switch (first) {
            case "student" -> Set.of("student");
            case "teacher" -> Set.of("teacher", "admin");
            case "admin" -> Set.of("admin");
            default -> Set.of("student", "teacher", "admin");
        };
    }

    static void deny(HttpServletResponse resp, int status, String code, String message) throws IOException {
        resp.setStatus(status);
        resp.setContentType("application/json;charset=UTF-8");
        resp.getWriter().write("{\"error\":\"" + message + "\",\"code\":\"" + code + "\"}");
    }
}
