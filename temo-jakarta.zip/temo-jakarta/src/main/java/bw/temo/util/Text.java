package bw.temo.util;

import java.util.Locale;
import java.util.UUID;

/** Small string helpers shared by the DAOs and servlets. */
public final class Text {
    private Text() {}

    public static String newId() {
        return UUID.randomUUID().toString();
    }

    /** Trims, turns null into "", and cuts to a maximum length. */
    public static String clip(Object value, int max) {
        if (value == null) return "";
        String s = String.valueOf(value).trim();
        return s.length() > max ? s.substring(0, max) : s;
    }

    public static boolean blank(String s) {
        return s == null || s.isBlank();
    }

    public static boolean isHttpUrl(String s) {
        if (s == null) return false;
        String t = s.toLowerCase(Locale.ROOT);
        return t.startsWith("http://") || t.startsWith("https://");
    }

    /** Lower-cases and collapses punctuation, so "Solar-Powered Irrigation" == "solar powered irrigation". */
    public static String norm(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", " ").trim();
    }

    public static String email(String s) {
        return s == null ? "" : s.trim().toLowerCase(Locale.ROOT);
    }

    public static boolean looksLikeEmail(String s) {
        return s != null && s.length() <= 190 && s.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$");
    }
}
