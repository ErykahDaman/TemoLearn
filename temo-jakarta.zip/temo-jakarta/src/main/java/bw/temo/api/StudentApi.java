package bw.temo.api;

import bw.temo.dao.Courses;
import bw.temo.dao.Enrollments;
import bw.temo.dao.Games;
import bw.temo.web.ApiException;
import bw.temo.web.ApiServlet;
import bw.temo.web.Ctx;
import bw.temo.web.Guard;
import bw.temo.web.Router;
import jakarta.servlet.annotation.WebServlet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** The learner's side: what I'm taking, enrolling, progress, quizzes (graded here, never in the browser). */
@WebServlet(name = "StudentApi", urlPatterns = "/api/student/*")
public class StudentApi extends ApiServlet {

    @Override
    protected void routes(Router r) {
        r.get("/learning", this::learning);
        r.get("/catalogue", this::catalogue);
        r.get("/enrollments", c -> c.ok(Enrollments.forUser(c.uid())));
        r.post("/enroll", this::enroll);
        r.get("/courses/{courseId}/outline", this::outline);
        r.post("/courses/{courseId}/items/{itemId}/done", this::done);
        r.post("/courses/{courseId}/items/{itemId}/quiz", this::quiz);
        r.post("/courses/{courseId}/last", this::last);
        r.get("/games", c -> c.ok(Games.visible()));
    }

    /** Every course I'm enrolled in (and that is still published): { enr, course, mods }. */
    private void learning(Ctx c) throws SQLException {
        List<Map<String, Object>> rows = new ArrayList<>();
        for (Map<String, Object> enr : Enrollments.forUser(c.uid())) {
            Map<String, Object> course = Courses.byId((String) enr.get("courseId"));
            if (course == null || !"published".equals(course.get("status"))) continue;
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("enr", enr);
            row.put("course", course);
            row.put("mods", Courses.outline((String) course.get("id"), true));
            rows.add(row);
        }
        c.ok(rows);
    }

    /** Published courses (with section titles) and which ones I'm already in. */
    private void catalogue(Ctx c) throws SQLException {
        List<Map<String, Object>> pub = Courses.published();
        Map<String, Object> out = new LinkedHashMap<>();
        List<Map<String, Object>> list = new ArrayList<>();
        for (Map<String, Object> course : pub) {
            Map<String, Object> copy = new LinkedHashMap<>(course);
            List<Map<String, Object>> mods = Courses.outline((String) course.get("id"), true);
            List<Object> titles = new ArrayList<>();
            int items = 0;
            for (Map<String, Object> m : mods) {
                titles.add(m.get("title"));
                items += ((List<?>) m.get("items")).size();
            }
            copy.put("moduleTitles", titles);
            copy.put("itemCount", (long) items);
            list.add(copy);
        }
        List<String> mine = new ArrayList<>();
        for (Map<String, Object> e : Enrollments.forUser(c.uid())) mine.add((String) e.get("courseId"));
        out.put("courses", list);
        out.put("enrolled", mine);
        c.ok(out);
    }

    private void enroll(Ctx c) throws SQLException {
        String courseId = String.valueOf(c.body().getOrDefault("courseId", ""));
        Map<String, Object> course = Courses.byId(courseId);
        if (course == null || !"published".equals(course.get("status"))) throw ApiException.notFound();
        Enrollments.enrol(c.uid(), courseId, true, null);   // already enrolled: left untouched, progress is kept
        c.ok(Enrollments.one(c.uid(), courseId));
    }

    private void outline(Ctx c) throws SQLException {
        Guard.learnerCourse(c, c.p("courseId"));
        c.ok(Courses.outline(c.p("courseId"), true));
    }

    private void done(Ctx c) throws SQLException {
        Guard.learnerCourse(c, c.p("courseId"));
        Map<String, Object> item = Guard.learnerItem(c.p("courseId"), c.p("itemId"));
        if ("quiz".equals(item.get("type"))) throw ApiException.badRequest("A quiz is completed by passing it.");
        boolean done = !Boolean.FALSE.equals(c.body().get("done"));
        c.ok(Enrollments.setDone(c.uid(), c.p("courseId"), c.p("itemId"), done));
    }

    /** Body: { answers: [index per question] }. The answer key never leaves the server before this call. */
    @SuppressWarnings("unchecked")
    private void quiz(Ctx c) throws SQLException {
        Guard.learnerCourse(c, c.p("courseId"));
        Map<String, Object> item = Guard.learnerItem(c.p("courseId"), c.p("itemId"));
        Map<String, Object> quiz = (Map<String, Object>) item.get("quiz");
        if (!"quiz".equals(item.get("type")) || quiz == null) throw ApiException.notFound();
        List<Object> qs = (List<Object>) quiz.get("questions");
        Object given = c.body().get("answers");
        if (!(given instanceof List<?> answers) || answers.size() != qs.size()) throw ApiException.badRequest("Answer every question first.");

        int right = 0;
        List<Object> correct = new ArrayList<>();
        for (int i = 0; i < qs.size(); i++) {
            Map<String, Object> q = (Map<String, Object>) qs.get(i);
            long key = ((Number) q.get("answer")).longValue();
            correct.add(key);
            if (answers.get(i) instanceof Number n && n.longValue() == key) right++;
        }
        int pct = (int) Math.round(right * 100.0 / qs.size());
        int pass = quiz.get("passMark") instanceof Number n ? n.intValue() : 70;
        boolean passed = pct >= pass;

        Enrollments.saveQuiz(c.uid(), c.p("courseId"), c.p("itemId"), pct);
        Map<String, Object> out = new LinkedHashMap<>();
        if (passed) out.putAll(Enrollments.setDone(c.uid(), c.p("courseId"), c.p("itemId"), true));
        Map<String, Object> enr = Enrollments.one(c.uid(), c.p("courseId"));
        out.put("pct", (long) pct);
        out.put("right", (long) right);
        out.put("total", (long) qs.size());
        out.put("passed", passed);
        out.put("correct", correct);
        out.put("best", ((Map<String, Object>) enr.get("quizScores")).get(c.p("itemId")));
        c.ok(out);
    }

    private void last(Ctx c) throws SQLException {
        Guard.learnerCourse(c, c.p("courseId"));
        String moduleId = bw.temo.util.Text.clip(c.body().get("moduleId"), 36);
        String itemId = String.valueOf(c.body().getOrDefault("itemId", ""));
        Guard.learnerItem(c.p("courseId"), itemId);
        Enrollments.setLast(c.uid(), c.p("courseId"), moduleId, itemId);
        c.ok();
    }
}
