package bw.temo.api;

import bw.temo.dao.Courses;
import bw.temo.dao.Enrollments;
import bw.temo.dao.Games;
import bw.temo.dao.Users;
import bw.temo.util.Text;
import bw.temo.web.ApiException;
import bw.temo.web.ApiServlet;
import bw.temo.web.Ctx;
import bw.temo.web.Guard;
import bw.temo.web.Router;
import jakarta.servlet.annotation.WebServlet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Teachers (and admins): my courses, their sections and activities, my games, my students. */
@WebServlet(name = "TeacherApi", urlPatterns = "/api/teacher/*")
public class TeacherApi extends ApiServlet {

    @Override
    protected void routes(Router r) {
        // courses
        r.get("/courses", c -> c.ok(Courses.byAuthor(c.uid())));
        r.post("/courses", this::createCourse);
        r.get("/starters", c -> c.ok(startersWithModules()));
        r.post("/courses/from-starter", this::fromStarter);
        r.get("/courses/{id}", c -> c.ok(Guard.editableCourse(c, c.p("id"))));
        r.put("/courses/{id}", this::updateCourse);
        r.delete("/courses/{id}", this::deleteCourse);
        r.post("/courses/{id}/status", this::setStatus);
        r.get("/courses/{id}/outline", c -> {
            Guard.editableCourse(c, c.p("id"));
            c.ok(Courses.outline(c.p("id"), false));
        });
        // sections and activities
        r.post("/courses/{id}/modules", this::addModule);
        r.put("/modules/{id}", this::updateModule);
        r.delete("/modules/{id}", this::deleteModule);
        r.post("/modules/{id}/items", this::addItem);
        r.put("/items/{id}", this::replaceItem);
        r.put("/items/{id}/order", c -> {
            Guard.editableItem(c, c.p("id"));
            Courses.setItemOrder(c.p("id"), c.body().get("order") instanceof Number n ? n.intValue() : 0);
            c.ok();
        });
        r.delete("/items/{id}", this::deleteItem);
        // games
        r.get("/games", c -> c.ok(Games.byAuthor(c.uid())));
        r.post("/games", this::createGame);
        r.put("/games/{id}", this::updateGame);
        r.delete("/games/{id}", this::deleteGame);
        // students
        r.get("/students", c -> c.ok(Users.students()));
        r.get("/enrollments", this::myEnrollments);
        r.get("/courses/{id}/enrollments", c -> {
            Guard.editableCourse(c, c.p("id"));
            c.ok(Enrollments.forCourse(c.p("id")));
        });
        r.post("/courses/{id}/enrollments", this::enrolStudents);
        r.delete("/courses/{id}/enrollments/{uid}", c -> {
            Guard.editableCourse(c, c.p("id"));
            Enrollments.unenrol(c.p("uid"), c.p("id"));
            c.ok();
        });
    }

    /* ----------------------------------------------------------------- courses */

    private void createCourse(Ctx c) throws SQLException {
        String id = Courses.create(c.uid(), (String) c.user().get("fullName"), c.body());
        c.ok(Courses.byId(id));
    }

    private List<Map<String, Object>> startersWithModules() throws SQLException {
        List<Map<String, Object>> list = Courses.starters();
        for (Map<String, Object> s : list) {
            List<Map<String, Object>> mods = new ArrayList<>();
            for (Map<String, Object> m : Courses.outline((String) s.get("id"), false)) {
                Map<String, Object> mm = new LinkedHashMap<>();
                mm.put("title", m.get("title"));
                mods.add(mm);
            }
            s.put("modules", mods);
        }
        return list;
    }

    private void fromStarter(Ctx c) throws SQLException {
        String id = Courses.cloneStarter(String.valueOf(c.body().getOrDefault("starterId", "")), c.uid(), (String) c.user().get("fullName"));
        if (id == null) throw ApiException.notFound();
        c.ok(Courses.byId(id));
    }

    private void updateCourse(Ctx c) throws SQLException {
        Guard.editableCourse(c, c.p("id"));
        Map<String, Object> in = c.body();
        in.remove("status");
        Courses.update(c.p("id"), in);
        c.ok(Courses.byId(c.p("id")));
    }

    private void deleteCourse(Ctx c) throws SQLException {
        Guard.editableCourse(c, c.p("id"));
        Courses.delete(c.p("id"));
        c.ok();
    }

    private void setStatus(Ctx c) throws SQLException {
        Guard.editableCourse(c, c.p("id"));
        Courses.setStatus(c.p("id"), String.valueOf(c.body().getOrDefault("status", "")));
        c.ok(Courses.byId(c.p("id")));
    }

    /* ------------------------------------------------------ sections, activities */

    private void addModule(Ctx c) throws SQLException {
        Guard.editableCourse(c, c.p("id"));
        int order = c.body().get("order") instanceof Number n ? n.intValue() : 0;
        String id = Courses.addModule(c.p("id"), Text.clip(c.body().get("title"), 160), order);
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("id", id);
        c.ok(out);
    }

    private void updateModule(Ctx c) throws SQLException {
        Guard.editableModule(c, c.p("id"));
        Courses.updateModule(c.p("id"), c.body());
        c.ok();
    }

    private void deleteModule(Ctx c) throws SQLException {
        Guard.editableModule(c, c.p("id"));
        Courses.deleteModule(c.p("id"));
        c.ok();
    }

    private void addItem(Ctx c) throws SQLException {
        Map<String, Object> mod = Guard.editableModule(c, c.p("id"));
        String id = Courses.addItem(c.p("id"), (String) mod.get("courseId"), c.body());
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("id", id);
        c.ok(out);
    }

    private void replaceItem(Ctx c) throws SQLException {
        Guard.editableItem(c, c.p("id"));
        Courses.replaceItem(c.p("id"), c.body());
        c.ok();
    }

    private void deleteItem(Ctx c) throws SQLException {
        Guard.editableItem(c, c.p("id"));
        Courses.deleteItem(c.p("id"));
        c.ok();
    }

    /* ------------------------------------------------------------------- games */

    private void createGame(Ctx c) throws SQLException {
        String id = Games.create(c.uid(), (String) c.user().get("fullName"), c.body());
        c.ok(Games.byId(id));
    }

    private Map<String, Object> myGame(Ctx c) throws SQLException {
        Map<String, Object> g = Games.byId(c.p("id"));
        if (g == null) throw ApiException.notFound();
        if (!c.isAdmin() && !c.uid().equals(g.get("authorId"))) throw ApiException.forbidden();
        return g;
    }

    private void updateGame(Ctx c) throws SQLException {
        myGame(c);
        Games.update(c.p("id"), c.body());
        c.ok(Games.byId(c.p("id")));
    }

    private void deleteGame(Ctx c) throws SQLException {
        myGame(c);
        Games.delete(c.p("id"));
        c.ok();
    }

    /* ---------------------------------------------------------------- students */

    private void myEnrollments(Ctx c) throws SQLException {
        List<Map<String, Object>> out = new ArrayList<>();
        for (Map<String, Object> course : Courses.byAuthor(c.uid())) out.addAll(Enrollments.forCourse((String) course.get("id")));
        c.ok(out);
    }

    /** Body: { uids: [...] }. Students already enrolled are skipped, so nobody's progress is reset. */
    private void enrolStudents(Ctx c) throws SQLException {
        Guard.editableCourse(c, c.p("id"));
        if (!(c.body().get("uids") instanceof List<?> uids) || uids.isEmpty()) throw ApiException.badRequest("Pick at least one student.");
        if (uids.size() > 500) throw ApiException.badRequest("Enrol at most 500 students at a time.");
        int added = 0, skipped = 0;
        for (Object o : uids) {
            Map<String, Object> u = Users.byId(Text.clip(o, 36));
            if (u == null || !"student".equals(u.get("role")) || Boolean.TRUE.equals(u.get("disabled"))) { skipped++; continue; }
            if (Enrollments.enrol((String) u.get("uid"), c.p("id"), false, c.uid())) added++; else skipped++;
        }
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("added", (long) added);
        out.put("skipped", (long) skipped);
        c.ok(out);
    }
}
