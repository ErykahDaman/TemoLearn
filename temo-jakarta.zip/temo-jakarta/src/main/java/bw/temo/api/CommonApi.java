package bw.temo.api;

import bw.temo.dao.Courses;
import bw.temo.dao.Enrollments;
import bw.temo.dao.Feedback;
import bw.temo.dao.Games;
import bw.temo.dao.Posts;
import bw.temo.dao.Users;
import bw.temo.security.Csrf;
import bw.temo.security.LoginThrottle;
import bw.temo.security.Sessions;
import bw.temo.util.Passwords;
import bw.temo.util.Text;
import bw.temo.web.ApiException;
import bw.temo.web.ApiServlet;
import bw.temo.web.Ctx;
import bw.temo.web.Router;
import jakarta.servlet.annotation.WebServlet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

/** Things every signed-in person can do: who am I, edit my profile, change my password, send feedback, discussions. */
@WebServlet(name = "CommonApi", urlPatterns = "/api/common/*")
public class CommonApi extends ApiServlet {

    @Override
    protected void routes(Router r) {
        r.get("/session", this::session);
        r.put("/profile", this::saveProfile);
        r.post("/password", this::changePassword);
        r.post("/feedback", this::sendFeedback);
        r.get("/feedback/mine", c -> c.ok(Feedback.forUser(c.uid())));
        r.get("/games/{id}", this::game);
        r.get("/courses/{courseId}/items/{itemId}/posts", this::listPosts);
        r.post("/courses/{courseId}/items/{itemId}/posts", this::addPost);
        r.delete("/posts/{id}", this::deletePost);
    }

    private void session(Ctx c) {
        Map<String, Object> u = c.user();
        Map<String, Object> user = new LinkedHashMap<>();
        user.put("uid", u.get("uid"));
        user.put("email", u.get("email"));
        user.put("displayName", u.get("fullName"));
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("user", user);
        out.put("profile", u);
        out.put("csrf", Csrf.token(c.req));
        c.ok(out);
    }

    private void saveProfile(Ctx c) throws SQLException {
        Users.updateOwnProfile(c.uid(), c.body());
        c.ok(Users.byId(c.uid()));
    }

    private void changePassword(Ctx c) throws SQLException {
        String current = Text.clip(c.body().get("current"), 200);
        String next = String.valueOf(c.body().getOrDefault("next", ""));
        String key = "pw:" + c.uid();
        if (LoginThrottle.blocked(key)) throw new ApiException(429, "auth/too-many-requests", "Too many tries. Wait a bit and try again.");
        String stored = Users.passwordHash(c.uid());
        if (stored == null || !Passwords.verify(current, stored)) {
            LoginThrottle.fail(key);
            throw new ApiException(400, "auth/wrong-password", "Your current password isn't right.");
        }
        LoginThrottle.clear(key);
        checkNewPassword(next);
        Users.setPassword(c.uid(), Passwords.hash(next));
        c.ok();
    }

    public static void checkNewPassword(String pw) {
        if (pw == null || pw.length() < 8) throw new ApiException(400, "auth/weak-password", "Password must be at least 8 characters.");
        if (pw.length() > 200) throw new ApiException(400, "auth/weak-password", "That password is too long.");
    }

    private void sendFeedback(Ctx c) throws SQLException {
        Map<String, Object> u = c.user();
        Map<String, Object> b = c.body();
        Feedback.add(c.uid(), (String) u.get("fullName"), (String) u.get("email"), (String) u.get("role"),
            Text.clip(b.get("type"), 60), Text.clip(b.get("subject"), 200), Text.clip(b.get("message"), 5000));
        c.ok();
    }

    private void game(Ctx c) throws SQLException {
        Map<String, Object> g = Games.byId(c.p("id"));
        if (g == null) throw ApiException.notFound();
        boolean mine = c.uid().equals(g.get("authorId"));
        if (!Boolean.TRUE.equals(g.get("visible")) && !mine && !c.isAdmin()) throw ApiException.notFound();
        c.ok(g);
    }

    /* ------------------------------------------------------------ discussions */

    /** Learners (enrolled, course published), the course's teacher and admins may take part. */
    private Map<String, Object> discussionItem(Ctx c) throws SQLException {
        String courseId = c.p("courseId");
        Map<String, Object> course = Courses.byId(courseId);
        if (course == null) throw ApiException.notFound();
        boolean staff = c.isAdmin() || c.uid().equals(course.get("authorId"));
        if (!staff) {
            if (!"published".equals(course.get("status")) || !Enrollments.exists(c.uid(), courseId)) throw ApiException.forbidden();
        }
        Map<String, Object> item = Courses.itemById(c.p("itemId"));
        if (item == null || !courseId.equals(item.get("courseId")) || !"discussion".equals(item.get("type"))) throw ApiException.notFound();
        return item;
    }

    private void listPosts(Ctx c) throws SQLException {
        discussionItem(c);
        c.ok(Posts.list(c.p("courseId"), c.p("itemId")));
    }

    private void addPost(Ctx c) throws SQLException {
        discussionItem(c);
        Posts.add(c.p("courseId"), c.p("itemId"), c.uid(), (String) c.user().get("fullName"), Text.clip(c.body().get("text"), 1000));
        c.ok();
    }

    private void deletePost(Ctx c) throws SQLException {
        Map<String, Object> p = Posts.byId(c.p("id"));
        if (p == null) throw ApiException.notFound();
        boolean staff = c.isAdmin();
        if (!staff && "teacher".equals(c.role())) {
            Map<String, Object> course = Courses.byId((String) p.get("courseId"));
            staff = course != null && c.uid().equals(course.get("authorId"));
        }
        if (!staff && !c.uid().equals(p.get("uid"))) throw ApiException.forbidden();
        Posts.delete(c.p("id"));
        c.ok();
    }
}
