package bw.temo.api;

import bw.temo.db.Db;
import bw.temo.dao.Courses;
import bw.temo.dao.Enrollments;
import bw.temo.dao.Feedback;
import bw.temo.dao.Games;
import bw.temo.dao.Users;
import bw.temo.util.Passwords;
import bw.temo.util.Text;
import bw.temo.web.ApiException;
import bw.temo.web.ApiServlet;
import bw.temo.web.Ctx;
import bw.temo.web.Router;
import jakarta.servlet.annotation.WebServlet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/** Administrators only (enforced by AuthFilter): everyone's users, content and feedback. */
@WebServlet(name = "AdminApi", urlPatterns = "/api/admin/*")
public class AdminApi extends ApiServlet {
    private static final Set<String> ROLES = Set.of("student", "teacher", "admin");

    @Override
    protected void routes(Router r) {
        r.get("/users", c -> c.ok(Users.all()));
        r.put("/users/{uid}", this::updateUser);
        r.post("/teachers", this::createTeacher);
        r.post("/users/{uid}/password", this::resetPassword);
        r.get("/courses", c -> c.ok(Courses.all()));
        r.post("/courses/{id}/status", this::courseStatus);
        r.delete("/courses/{id}", this::deleteCourse);
        r.get("/games", c -> c.ok(Games.all()));
        r.put("/games/{id}/visible", this::gameVisible);
        r.delete("/games/{id}", c -> {
            if (Games.byId(c.p("id")) == null) throw ApiException.notFound();
            Games.delete(c.p("id"));
            c.ok();
        });
        r.get("/enrollments", c -> c.ok(Enrollments.all()));
        r.get("/feedback", c -> c.ok(Feedback.all()));
        r.put("/feedback/{id}", this::replyFeedback);
    }

    /** Body: { role?, disabled? }. An admin can't lock themselves out or remove the last admin. */
    private void updateUser(Ctx c) throws SQLException {
        String uid = c.p("uid");
        Map<String, Object> target = Users.byId(uid);
        if (target == null) throw ApiException.notFound();
        Map<String, Object> b = c.body();
        boolean self = uid.equals(c.uid());
        if (b.containsKey("role")) {
            String role = String.valueOf(b.get("role"));
            if (!ROLES.contains(role)) throw ApiException.badRequest("Unknown role.");
            if (self && !"admin".equals(role)) throw new ApiException(400, "invalid-argument", "You can't remove your own admin access.");
            Users.setRole(uid, role);
        }
        if (b.containsKey("disabled")) {
            boolean disabled = Boolean.TRUE.equals(b.get("disabled"));
            if (self && disabled) throw new ApiException(400, "invalid-argument", "You can't disable your own account.");
            Users.setDisabled(uid, disabled);
        }
        c.ok(Users.byId(uid));
    }

    /** Teachers are created here, never through the public sign-up form. */
    private void createTeacher(Ctx c) throws SQLException {
        Map<String, Object> b = c.body();
        String name = Text.clip(b.get("fullName"), 120);
        String email = Text.email(Text.clip(b.get("email"), 190));
        String password = String.valueOf(b.getOrDefault("password", ""));
        if (name.isEmpty()) throw ApiException.badRequest("Enter the teacher's name.");
        if (!Text.looksLikeEmail(email)) throw new ApiException(400, "auth/invalid-email", "That email doesn't look right.");
        CommonApi.checkNewPassword(password);
        if (Users.emailTaken(email)) throw new ApiException(409, "auth/email-already-in-use", "That email already has an account.");
        String uid;
        try {
            uid = Users.create(name, email, Passwords.hash(password), "teacher", c.uid());
        } catch (SQLException e) {
            if (Db.isDuplicate(e)) throw new ApiException(409, "auth/email-already-in-use", "That email already has an account.");
            throw e;
        }
        String title = Text.clip(b.get("title"), 100);
        if (!title.isEmpty()) {
            Map<String, Object> p = new LinkedHashMap<>();
            p.put("title", title);
            Users.updateOwnProfile(uid, p);
        }
        c.ok(Users.byId(uid));
    }

    /** There is no e-mail service, so an admin sets a new password for someone who is locked out. */
    private void resetPassword(Ctx c) throws SQLException {
        Map<String, Object> target = Users.byId(c.p("uid"));
        if (target == null) throw ApiException.notFound();
        String pw = String.valueOf(c.body().getOrDefault("password", ""));
        CommonApi.checkNewPassword(pw);
        Users.setPassword(c.p("uid"), Passwords.hash(pw));
        c.ok();
    }

    private void courseStatus(Ctx c) throws SQLException {
        Map<String, Object> course = Courses.byId(c.p("id"));
        if (course == null || "starter".equals(course.get("status"))) throw ApiException.notFound();
        Courses.setStatus(c.p("id"), String.valueOf(c.body().getOrDefault("status", "")));
        c.ok(Courses.byId(c.p("id")));
    }

    private void deleteCourse(Ctx c) throws SQLException {
        Map<String, Object> course = Courses.byId(c.p("id"));
        if (course == null || "starter".equals(course.get("status"))) throw ApiException.notFound();
        Courses.delete(c.p("id"));
        c.ok();
    }

    private void gameVisible(Ctx c) throws SQLException {
        if (Games.byId(c.p("id")) == null) throw ApiException.notFound();
        Games.setVisible(c.p("id"), Boolean.TRUE.equals(c.body().get("visible")));
        c.ok();
    }

    private void replyFeedback(Ctx c) throws SQLException {
        Map<String, Object> b = c.body();
        Feedback.reply(c.p("id"), c.uid(), String.valueOf(b.getOrDefault("status", "open")), Text.clip(b.get("reply"), 5000));
        c.ok();
    }
}
