package bw.temo.db;

import bw.temo.config.AppConfig;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;
import org.apache.tomcat.jdbc.pool.DataSource;
import org.apache.tomcat.jdbc.pool.PoolProperties;

/**
 * Connection pool (Tomcat's own tomcat-jdbc pool) plus tiny helpers so the DAOs stay short.
 * Every query uses ? placeholders, never string concatenation.
 */
public final class Db {
    private static final Logger LOG = Logger.getLogger(Db.class.getName());
    private static volatile DataSource pool;
    /** Every timestamp is stored in UTC (DATETIME columns, UTC_TIMESTAMP() defaults), whatever the server's time zone is. */
    private static final java.util.TimeZone UTC = java.util.TimeZone.getTimeZone("UTC");

    private Db() {}

    @FunctionalInterface public interface Row<T> { T map(ResultSet rs) throws SQLException; }
    @FunctionalInterface public interface Work<T> { T run(Connection c) throws SQLException; }

    /* ------------------------------------------------------------------ pool */

    public static synchronized void init() {
        if (pool != null) return;
        PoolProperties p = new PoolProperties();
        p.setUrl(AppConfig.get("db.url", "jdbc:mysql://localhost:3306/temolearn?createDatabaseIfNotExist=true&characterEncoding=UTF-8&useSSL=false&allowPublicKeyRetrieval=true"));
        p.setDriverClassName(AppConfig.get("db.driver", "com.mysql.cj.jdbc.Driver"));
        p.setUsername(AppConfig.get("db.user", "root"));
        p.setPassword(AppConfig.get("db.password", ""));
        p.setInitialSize(2);
        p.setMaxActive(AppConfig.getInt("db.pool.size", 12));
        p.setMaxIdle(6);
        p.setMinIdle(2);
        p.setMaxWait(10_000);
        p.setTestOnBorrow(true);
        p.setValidationQuery("SELECT 1");
        p.setValidationInterval(15_000);
        p.setRemoveAbandoned(true);
        p.setRemoveAbandonedTimeout(60);
        p.setJdbcInterceptors("org.apache.tomcat.jdbc.pool.interceptor.ConnectionState");
        pool = new DataSource(p);
        runSchema();
    }

    public static synchronized void shutdown() {
        if (pool != null) {
            pool.close();
            pool = null;
        }
    }

    public static Connection conn() throws SQLException {
        DataSource ds = pool;
        if (ds == null) throw new SQLException("Database is not initialised");
        return ds.getConnection();
    }

    /** Runs db/schema.sql (all CREATE ... IF NOT EXISTS) so a fresh database sets itself up. */
    private static void runSchema() {
        String sql;
        try (InputStream in = Db.class.getResourceAsStream("/db/schema.sql")) {
            if (in == null) throw new IllegalStateException("db/schema.sql is missing from the WAR");
            sql = new String(in.readAllBytes(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new IllegalStateException("Cannot read db/schema.sql", e);
        }
        try (Connection c = conn(); Statement st = c.createStatement()) {
            for (String stmt : sql.split(";\\s*\\n")) {
                String s = stmt.replaceAll("(?m)^--.*$", "").trim();
                if (!s.isEmpty()) st.execute(s);
            }
            LOG.info("Database schema is ready.");
        } catch (SQLException e) {
            throw new IllegalStateException("Could not prepare the database. Is MySQL running? Check TEMO_DB_URL / TEMO_DB_USER / TEMO_DB_PASSWORD. " + e.getMessage(), e);
        }
    }

    /* --------------------------------------------------------------- helpers */

    private static void bind(PreparedStatement ps, Object[] args) throws SQLException {
        for (int i = 0; i < args.length; i++) {
            Object a = args[i];
            if (a instanceof Instant t) ps.setTimestamp(i + 1, Timestamp.from(t), java.util.Calendar.getInstance(UTC));
            else ps.setObject(i + 1, a);
        }
    }

    public static <T> List<T> list(Connection c, String sql, Row<T> mapper, Object... args) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            bind(ps, args);
            try (ResultSet rs = ps.executeQuery()) {
                List<T> out = new ArrayList<>();
                while (rs.next()) out.add(mapper.map(rs));
                return out;
            }
        }
    }

    public static <T> List<T> list(String sql, Row<T> mapper, Object... args) throws SQLException {
        try (Connection c = conn()) { return list(c, sql, mapper, args); }
    }

    public static <T> T one(Connection c, String sql, Row<T> mapper, Object... args) throws SQLException {
        List<T> l = list(c, sql, mapper, args);
        return l.isEmpty() ? null : l.get(0);
    }

    public static <T> T one(String sql, Row<T> mapper, Object... args) throws SQLException {
        try (Connection c = conn()) { return one(c, sql, mapper, args); }
    }

    public static int update(Connection c, String sql, Object... args) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            bind(ps, args);
            return ps.executeUpdate();
        }
    }

    public static int update(String sql, Object... args) throws SQLException {
        try (Connection c = conn()) { return update(c, sql, args); }
    }

    public static long count(String sql, Object... args) throws SQLException {
        Long n = one(sql, rs -> rs.getLong(1), args);
        return n == null ? 0 : n;
    }

    /** Runs several statements as one all-or-nothing transaction. */
    public static <T> T tx(Work<T> work) throws SQLException {
        try (Connection c = conn()) {
            boolean old = c.getAutoCommit();
            c.setAutoCommit(false);
            try {
                T result = work.run(c);
                c.commit();
                return result;
            } catch (SQLException | RuntimeException e) {
                c.rollback();
                throw e;
            } finally {
                c.setAutoCommit(old);
            }
        }
    }

    /* ------------------------------------------------------- row conversion */

    /** Epoch seconds for a UTC DATETIME column, or null. The browser turns it into a Date. */
    public static Long secs(ResultSet rs, String col) throws SQLException {
        Timestamp t = rs.getTimestamp(col, java.util.Calendar.getInstance(UTC));
        return t == null ? null : t.getTime() / 1000;
    }

    /** True when an INSERT failed because a unique key already exists (MySQL error 1062). */
    public static boolean isDuplicate(SQLException e) {
        return e.getErrorCode() == 1062 || "23505".equals(e.getSQLState());
    }

    public static Map<String, Object> map() {
        return new LinkedHashMap<>();
    }
}
