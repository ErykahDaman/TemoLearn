package bw.temo.dao;

import bw.temo.db.Db;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** A learner's place in a course: completed activities, quiz scores, last position. */
public final class Enrollments {
    private Enrollments() {}

    private static final String SELECT =
        "SELECT e.user_id, e.course_id, e.is_completed, e.started_at, e.last_active, e.completed_at, e.last_module, e.last_item, " +
        "e.self_enrolled, e.enrolled_by, u.full_name, u.email FROM enrollments e JOIN users u ON u.uid = e.user_id ";

    @SuppressWarnings("unchecked")
    private static Map<String, Object> row(ResultSet rs) throws SQLException {
        Map<String, Object> m = Db.map();
        m.put("uid", rs.getString("user_id"));
        m.put("courseId", rs.getString("course_id"));
        m.put("completed", rs.getBoolean("is_completed"));
        m.put("startedAt", Db.secs(rs, "started_at"));
        m.put("lastActive", Db.secs(rs, "last_active"));
        m.put("completedAt", Db.secs(rs, "completed_at"));
        m.put("lastModule", rs.getString("last_module"));
        m.put("lastItem", rs.getString("last_item"));
        m.put("selfEnrolled", rs.getBoolean("self_enrolled"));
        m.put("enrolledBy", rs.getString("enrolled_by"));
        m.put("studentName", rs.getString("full_name"));
        m.put("studentEmail", rs.getString("email"));
        m.put("completedItems", new ArrayList<String>());
        m.put("quizScores", new LinkedHashMap<String, Object>());
        return m;
    }

    /** Fills completedItems and quizScores. filterCol is "user_id" or "course_id" (a constant, never user input). */
    @SuppressWarnings("unchecked")
    private static List<Map<String, Object>> attach(List<Map<String, Object>> list, String filterCol, Object filterVal) throws SQLException {
        if (list.isEmpty()) return list;
        Map<String, Map<String, Object>> idx = new LinkedHashMap<>();
        for (Map<String, Object> m : list) idx.put(m.get("uid") + "|" + m.get("courseId"), m);
        String where = filterCol == null ? "" : " WHERE " + filterCol + " = ?";
        Object[] args = filterCol == null ? new Object[0] : new Object[]{filterVal};
        Db.list("SELECT user_id, course_id, item_id FROM enrollment_items" + where, rs -> {
            Map<String, Object> m = idx.get(rs.getString(1) + "|" + rs.getString(2));
            if (m != null) ((List<String>) m.get("completedItems")).add(rs.getString(3));
            return null;
        }, args);
        Db.list("SELECT user_id, course_id, item_id, pct FROM quiz_scores" + where, rs -> {
            Map<String, Object> m = idx.get(rs.getString(1) + "|" + rs.getString(2));
            if (m != null) ((Map<String, Object>) m.get("quizScores")).put(rs.getString(3), (long) rs.getInt(4));
            return null;
        }, args);
        return list;
    }

    public static List<Map<String, Object>> forUser(String uid) throws SQLException {
        return attach(Db.list(SELECT + "WHERE e.user_id = ? ORDER BY e.last_active DESC", Enrollments::row, uid), "user_id", uid);
    }

    public static List<Map<String, Object>> forCourse(String courseId) throws SQLException {
        return attach(Db.list(SELECT + "WHERE e.course_id = ? ORDER BY lower(u.full_name)", Enrollments::row, courseId), "course_id", courseId);
    }

    public static List<Map<String, Object>> all() throws SQLException {
        return attach(Db.list(SELECT + "ORDER BY e.started_at DESC LIMIT 5000", Enrollments::row), null, null);
    }

    public static Map<String, Object> one(String uid, String courseId) throws SQLException {
        List<Map<String, Object>> l = attach(Db.list(SELECT + "WHERE e.user_id = ? AND e.course_id = ?", Enrollments::row, uid, courseId), "user_id", uid);
        return l.isEmpty() ? null : l.get(0);
    }

    public static boolean exists(String uid, String courseId) throws SQLException {
        return Db.count("SELECT count(*) FROM enrollments WHERE user_id = ? AND course_id = ?", uid, courseId) > 0;
    }

    /** True if a new row was created. An existing enrolment is left exactly as it is, so progress is never reset. */
    public static boolean enrol(String uid, String courseId, boolean self, String enrolledBy) throws SQLException {
        return Db.update("INSERT IGNORE INTO enrollments (user_id, course_id, self_enrolled, enrolled_by) VALUES (?,?,?,?) ",
            uid, courseId, self, enrolledBy) > 0;
    }

    public static void unenrol(String uid, String courseId) throws SQLException {
        Db.update("DELETE FROM enrollments WHERE user_id = ? AND course_id = ?", uid, courseId);
    }

    public static void setLast(String uid, String courseId, String moduleId, String itemId) throws SQLException {
        Db.update("UPDATE enrollments SET last_module = ?, last_item = ?, last_active = UTC_TIMESTAMP() WHERE user_id = ? AND course_id = ?",
            moduleId, itemId, uid, courseId);
    }

    /** Best score wins. */
    public static void saveQuiz(String uid, String courseId, String itemId, int pct) throws SQLException {
        Db.update("INSERT INTO quiz_scores (user_id, course_id, item_id, pct) VALUES (?,?,?,?) " +
            "ON DUPLICATE KEY UPDATE pct = GREATEST(pct, VALUES(pct))", uid, courseId, itemId, pct);
    }

    /**
     * Marks an activity done (or not) and works out whether the course is now complete.
     * Progress counts the "required" activities if the teacher marked any, otherwise all of them,
     * and only in sections that are open.
     * Returns { completedItems, completed, justCompleted }.
     */
    public static Map<String, Object> setDone(String uid, String courseId, String itemId, boolean done) throws SQLException {
        return Db.tx(c -> {
            if (done) {
                Db.update(c, "INSERT IGNORE INTO enrollment_items (user_id, course_id, item_id) VALUES (?,?,?)", uid, courseId, itemId);
            } else {
                Db.update(c, "DELETE FROM enrollment_items WHERE user_id = ? AND course_id = ? AND item_id = ?", uid, courseId, itemId);
            }
            Db.update(c, "UPDATE enrollments SET last_active = UTC_TIMESTAMP() WHERE user_id = ? AND course_id = ?", uid, courseId);
            boolean was = Boolean.TRUE.equals(Db.one(c, "SELECT is_completed FROM enrollments WHERE user_id = ? AND course_id = ?",
                rs -> rs.getBoolean(1), uid, courseId));
            boolean complete = isComplete(c, uid, courseId);
            boolean now = was;
            if (done && complete && !was) {
                Db.update(c, "UPDATE enrollments SET is_completed = TRUE, completed_at = UTC_TIMESTAMP() WHERE user_id = ? AND course_id = ?", uid, courseId);
                now = true;
            } else if (!done && was && !complete) {
                Db.update(c, "UPDATE enrollments SET is_completed = FALSE WHERE user_id = ? AND course_id = ?", uid, courseId);
                now = false;
            }
            List<String> items = Db.list(c, "SELECT item_id FROM enrollment_items WHERE user_id = ? AND course_id = ?", rs -> rs.getString(1), uid, courseId);
            Map<String, Object> out = Db.map();
            out.put("completedItems", items);
            out.put("completed", now);
            out.put("justCompleted", now && !was);
            return out;
        });
    }

    private static boolean isComplete(Connection c, String uid, String courseId) throws SQLException {
        long[] n = Db.one(c,
            "SELECT count(*) AS total, " +
            "COALESCE(SUM(i.is_required), 0) AS req, " +
            "COALESCE(SUM(ei.item_id IS NOT NULL), 0) AS done, " +
            "COALESCE(SUM(i.is_required AND ei.item_id IS NOT NULL), 0) AS req_done " +
            "FROM items i JOIN modules m ON m.id = i.module_id AND NOT m.is_locked " +
            "LEFT JOIN enrollment_items ei ON ei.item_id = i.id AND ei.user_id = ? AND ei.course_id = i.course_id " +
            "WHERE i.course_id = ?",
            rs -> new long[]{rs.getLong("total"), rs.getLong("req"), rs.getLong("done"), rs.getLong("req_done")}, uid, courseId);
        if (n == null || n[0] == 0) return false;
        return n[1] > 0 ? n[3] == n[1] : n[2] == n[0];
    }
}
