package bw.temo.dao;

import bw.temo.db.Db;
import bw.temo.util.Json;
import bw.temo.util.Text;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Courses, their sections (modules) and activities (items). */
public final class Courses {
    private Courses() {}

    public static final Set<String> TYPES = Set.of("page", "video", "link", "quiz", "discussion", "game");

    private static final String CCOLS =
        "id, title, summary, description, category, icon, level, hours, output, game, thumbnail, status, number, " +
        "author_id, author_name, created_at";

    private static Map<String, Object> course(ResultSet rs) throws SQLException {
        Map<String, Object> m = Db.map();
        m.put("id", rs.getString("id"));
        m.put("title", rs.getString("title"));
        m.put("summary", rs.getString("summary"));
        m.put("teaser", rs.getString("summary"));
        m.put("description", rs.getString("description"));
        m.put("category", rs.getString("category"));
        m.put("icon", rs.getString("icon"));
        m.put("level", rs.getString("level"));
        m.put("hours", rs.getString("hours"));
        m.put("output", rs.getString("output"));
        m.put("game", rs.getString("game"));
        m.put("thumbnail", rs.getString("thumbnail"));
        m.put("status", rs.getString("status"));
        int n = rs.getInt("number");
        m.put("number", rs.wasNull() ? null : n);
        m.put("authorId", rs.getString("author_id"));
        m.put("authorName", rs.getString("author_name"));
        m.put("createdAt", Db.secs(rs, "created_at"));
        return m;
    }

    /* ----------------------------------------------------------- course reads */

    public static Map<String, Object> byId(String id) throws SQLException {
        return Db.one("SELECT " + CCOLS + " FROM courses WHERE id = ?", Courses::course, id);
    }

    public static List<Map<String, Object>> published() throws SQLException {
        return Db.list("SELECT " + CCOLS + " FROM courses WHERE status = 'published' ORDER BY lower(title)", Courses::course);
    }

    public static List<Map<String, Object>> byAuthor(String uid) throws SQLException {
        return Db.list("SELECT " + CCOLS + " FROM courses WHERE author_id = ? AND status <> 'starter' ORDER BY created_at DESC",
            Courses::course, uid);
    }

    public static List<Map<String, Object>> all() throws SQLException {
        return Db.list("SELECT " + CCOLS + " FROM courses WHERE status <> 'starter' ORDER BY created_at DESC", Courses::course);
    }

    public static List<Map<String, Object>> starters() throws SQLException {
        return Db.list("SELECT " + CCOLS + " FROM courses WHERE status = 'starter' ORDER BY number IS NULL, number, lower(title)", Courses::course);
    }

    public static long countStarters() throws SQLException {
        return Db.count("SELECT count(*) FROM courses WHERE status = 'starter'");
    }

    /**
     * The public catalogue: published courses, plus the built-in starter syllabus entries
     * that no published course has replaced (matched by title). Each carries its section titles.
     */
    public static List<Map<String, Object>> publicCatalogue() throws SQLException {
        List<Map<String, Object>> list = new ArrayList<>();
        List<Map<String, Object>> pub = published();
        java.util.HashSet<String> taken = new java.util.HashSet<>();
        for (Map<String, Object> c : pub) taken.add(Text.norm((String) c.get("title")));
        list.addAll(pub);
        for (Map<String, Object> s : starters()) {
            if (!taken.contains(Text.norm((String) s.get("title")))) list.add(s);
        }
        // Order: numbered starters keep their syllabus order, everything else follows by title
        list.sort((a, b) -> {
            Integer na = (Integer) a.get("number"), nb = (Integer) b.get("number");
            if (na != null && nb != null) return na - nb;
            if (na != null) return -1;
            if (nb != null) return 1;
            return ((String) a.get("title")).compareToIgnoreCase((String) b.get("title"));
        });
        Map<String, List<Map<String, Object>>> mods = publicModules();
        for (Map<String, Object> c : list) {
            List<Map<String, Object>> ms = mods.getOrDefault((String) c.get("id"), List.of());
            c.put("modules", ms);
        }
        return list;
    }

    /** Section titles (and syllabus bullet points for starters) for every course. */
    private static Map<String, List<Map<String, Object>>> publicModules() throws SQLException {
        Map<String, List<Map<String, Object>>> out = new LinkedHashMap<>();
        Db.list("SELECT course_id, title, points_json FROM modules ORDER BY course_id, sort_order", rs -> {
            Map<String, Object> m = Db.map();
            m.put("title", rs.getString("title"));
            m.put("points", parseList(rs.getString("points_json")));
            out.computeIfAbsent(rs.getString("course_id"), k -> new ArrayList<>()).add(m);
            return null;
        });
        return out;
    }

    private static List<Object> parseList(String json) {
        try {
            Object o = Json.parse(json == null || json.isBlank() ? "[]" : json);
            return o instanceof List<?> l ? new ArrayList<>(l) : new ArrayList<>();
        } catch (RuntimeException e) {
            return new ArrayList<>();
        }
    }

    /* ---------------------------------------------------------- course writes */

    private static String str(Map<String, Object> in, String key, int max) {
        return Text.clip(in.get(key), max);
    }

    private static String thumb(Object v) {
        String s = v == null ? "" : String.valueOf(v);
        if (s.isEmpty()) return "";
        if (s.startsWith("data:image/") && s.length() <= 400_000) return s;
        throw new IllegalArgumentException("That course picture is not valid or is too large.");
    }

    public static String create(String authorId, String authorName, Map<String, Object> in) throws SQLException {
        String title = str(in, "title", 160);
        if (title.isEmpty()) throw new IllegalArgumentException("The course needs a title.");
        String id = Text.newId();
        Db.update("INSERT INTO courses (id, title, summary, description, category, icon, level, hours, output, game, thumbnail, " +
                "status, author_id, author_name) VALUES (?,?,?,?,?,?,?,?,?,?,?,'draft',?,?)",
            id, title, str(in, "summary", 300), str(in, "description", 20_000),
            or(str(in, "category", 60), "Growing Systems"), or(str(in, "icon", 16), "📜"),
            str(in, "level", 60), str(in, "hours", 40), str(in, "output", 500), str(in, "game", 160),
            thumb(in.get("thumbnail")), authorId, Text.clip(authorName, 120));
        return id;
    }

    private static String or(String s, String fallback) {
        return s.isEmpty() ? fallback : s;
    }

    /** Partial update: only the keys present in the map change. Status is handled by setStatus. */
    public static void update(String id, Map<String, Object> in) throws SQLException {
        Map<String, Object> cur = byId(id);
        if (cur == null) return;
        String title = in.containsKey("title") ? str(in, "title", 160) : (String) cur.get("title");
        if (title.isEmpty()) throw new IllegalArgumentException("The course needs a title.");
        Db.update("UPDATE courses SET title=?, summary=?, description=?, category=?, icon=?, level=?, hours=?, output=?, game=?, thumbnail=? WHERE id=?",
            title,
            keep(in, cur, "summary", 300), keep(in, cur, "description", 20_000),
            or(keep(in, cur, "category", 60), "General"), or(keep(in, cur, "icon", 16), "📜"),
            keep(in, cur, "level", 60), keep(in, cur, "hours", 40), keep(in, cur, "output", 500), keep(in, cur, "game", 160),
            in.containsKey("thumbnail") ? thumb(in.get("thumbnail")) : (String) cur.get("thumbnail"), id);
    }

    private static String keep(Map<String, Object> in, Map<String, Object> cur, String key, int max) {
        return in.containsKey(key) ? str(in, key, max) : (String) cur.get(key);
    }

    public static void setStatus(String id, String status) throws SQLException {
        if (!status.equals("draft") && !status.equals("published")) throw new IllegalArgumentException("Status must be draft or published.");
        Db.update("UPDATE courses SET status = ? WHERE id = ? AND status <> 'starter'", status, id);
    }

    public static void delete(String id) throws SQLException {
        Db.update("DELETE FROM courses WHERE id = ?", id);
    }

    /** Copies a starter syllabus entry (with its sections and a starter page in each) into a new draft. */
    public static String cloneStarter(String starterId, String authorId, String authorName) throws SQLException {
        Map<String, Object> s = byId(starterId);
        if (s == null || !"starter".equals(s.get("status"))) return null;
        return Db.tx(c -> {
            String id = Text.newId();
            Db.update(c, "INSERT INTO courses (id, title, summary, description, category, icon, level, hours, output, game, thumbnail, " +
                    "status, author_id, author_name) VALUES (?,?,?,?,?,?,?,?,?,?,?,'draft',?,?)",
                id, s.get("title"), s.get("summary"), s.get("description"), s.get("category"), s.get("icon"), s.get("level"),
                s.get("hours"), s.get("output"), s.get("game"), s.get("thumbnail"), authorId, Text.clip(authorName, 120));
            List<Map<String, Object>> mods = Db.list(c, "SELECT id, title, sort_order, points_json FROM modules WHERE course_id = ? ORDER BY sort_order", rs -> {
                Map<String, Object> m = Db.map();
                m.put("title", rs.getString("title"));
                m.put("order", rs.getInt("sort_order"));
                m.put("points", parseList(rs.getString("points_json")));
                return m;
            }, starterId);
            for (Map<String, Object> m : mods) {
                String mid = Text.newId();
                Db.update(c, "INSERT INTO modules (id, course_id, title, sort_order) VALUES (?,?,?,?)", mid, id, m.get("title"), m.get("order"));
                StringBuilder body = new StringBuilder("What you'll cover in this module:\n\n");
                for (Object p : (List<?>) m.get("points")) body.append("- ").append(p).append('\n');
                Db.update(c, "INSERT INTO items (id, module_id, course_id, type, title, sort_order, is_required, content) VALUES (?,?,?,'page',?,0,TRUE,?)",
                    Text.newId(), mid, id, m.get("title") + ": overview", body.toString().trim());
            }
            return id;
        });
    }

    /* --------------------------------------------------------------- outline */

    public static Map<String, Object> module(ResultSet rs) throws SQLException {
        Map<String, Object> m = Db.map();
        m.put("id", rs.getString("id"));
        m.put("title", rs.getString("title"));
        m.put("order", rs.getInt("sort_order"));
        m.put("locked", rs.getBoolean("is_locked"));
        m.put("items", new ArrayList<Map<String, Object>>());
        return m;
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> item(ResultSet rs, boolean forLearner) throws SQLException {
        Map<String, Object> m = Db.map();
        m.put("id", rs.getString("id"));
        m.put("type", rs.getString("type"));
        m.put("title", rs.getString("title"));
        m.put("order", rs.getInt("sort_order"));
        m.put("required", rs.getBoolean("is_required"));
        m.put("content", rs.getString("content"));
        m.put("url", rs.getString("url"));
        m.put("gameSource", rs.getString("game_source"));
        m.put("gameId", rs.getString("game_id"));
        m.put("gameName", rs.getString("game_name"));
        m.put("moduleId", rs.getString("module_id"));
        String quiz = rs.getString("quiz_json");
        if (quiz != null && !quiz.isBlank()) {
            Map<String, Object> q = Json.parseObject(quiz);
            if (forLearner && q.get("questions") instanceof List<?> qs) {
                // Learners get the questions but never the answer key: grading happens on the server.
                List<Object> safe = new ArrayList<>();
                for (Object o : qs) {
                    Map<String, Object> copy = new LinkedHashMap<>((Map<String, Object>) o);
                    copy.remove("answer");
                    safe.add(copy);
                }
                q.put("questions", safe);
            }
            m.put("quiz", q);
        }
        return m;
    }

    /**
     * Sections with their activities, in order.
     * forLearner = true: locked sections come back with no activities, and quiz answers are removed.
     */
    @SuppressWarnings("unchecked")
    public static List<Map<String, Object>> outline(String courseId, boolean forLearner) throws SQLException {
        List<Map<String, Object>> mods = Db.list("SELECT id, title, sort_order, is_locked FROM modules WHERE course_id = ? ORDER BY sort_order, title",
            Courses::module, courseId);
        Map<String, Map<String, Object>> byId = new LinkedHashMap<>();
        for (Map<String, Object> m : mods) byId.put((String) m.get("id"), m);
        Db.list("SELECT id, module_id, type, title, sort_order, is_required, content, url, game_source, game_id, game_name, quiz_json " +
                "FROM items WHERE course_id = ? ORDER BY sort_order, title", rs -> {
            Map<String, Object> m = byId.get(rs.getString("module_id"));
            if (m != null && !(forLearner && Boolean.TRUE.equals(m.get("locked")))) {
                ((List<Map<String, Object>>) m.get("items")).add(item(rs, forLearner));
            }
            return null;
        }, courseId);
        return mods;
    }

    /** A single activity, with the answer key (server use only). */
    public static Map<String, Object> itemById(String itemId) throws SQLException {
        return Db.one("SELECT id, module_id, course_id, type, title, sort_order, is_required, content, url, game_source, game_id, game_name, quiz_json " +
            "FROM items WHERE id = ?", rs -> {
            Map<String, Object> m = item(rs, false);
            m.put("courseId", rs.getString("course_id"));
            return m;
        }, itemId);
    }

    public static Map<String, Object> moduleById(String moduleId) throws SQLException {
        return Db.one("SELECT id, title, sort_order, is_locked, course_id FROM modules WHERE id = ?", rs -> {
            Map<String, Object> m = module(rs);
            m.put("courseId", rs.getString("course_id"));
            return m;
        }, moduleId);
    }

    /* ------------------------------------------------------- module writes */

    public static String addModule(String courseId, String title, int order) throws SQLException {
        String id = Text.newId();
        Db.update("INSERT INTO modules (id, course_id, title, sort_order) VALUES (?,?,?,?)", id, courseId,
            or(Text.clip(title, 160), "New section"), order);
        return id;
    }

    public static void updateModule(String id, Map<String, Object> in) throws SQLException {
        if (in.containsKey("title")) {
            String t = Text.clip(in.get("title"), 160);
            if (t.isEmpty()) throw new IllegalArgumentException("A section needs a title.");
            Db.update("UPDATE modules SET title = ? WHERE id = ?", t, id);
        }
        if (in.get("order") instanceof Number n) Db.update("UPDATE modules SET sort_order = ? WHERE id = ?", n.intValue(), id);
        if (in.get("locked") instanceof Boolean b) Db.update("UPDATE modules SET is_locked = ? WHERE id = ?", b, id);
    }

    public static void deleteModule(String id) throws SQLException {
        Db.update("DELETE FROM modules WHERE id = ?", id);
    }

    /* --------------------------------------------------------- item writes */

    /** Validates and normalises an activity coming from the editor. Throws IllegalArgumentException with a friendly message. */
    @SuppressWarnings("unchecked")
    private static Object[] cleanItem(Map<String, Object> in) {
        String type = Text.clip(in.get("type"), 20);
        if (!TYPES.contains(type)) throw new IllegalArgumentException("Unknown activity type.");
        String title = Text.clip(in.get("title"), 200);
        if (title.isEmpty()) throw new IllegalArgumentException("Give the activity a title.");
        String content = Text.clip(in.get("content"), 50_000);
        String url = Text.clip(in.get("url"), 600);
        if ((type.equals("video") || type.equals("link")) && !Text.isHttpUrl(url)) {
            throw new IllegalArgumentException("Enter a full link starting with http:// or https://");
        }
        if (!type.equals("video") && !type.equals("link")) url = "";
        String gameSource = "", gameId = "", gameName = "";
        if (type.equals("game")) {
            gameSource = Text.clip(in.get("gameSource"), 12);
            if (!gameSource.equals("builtin") && !gameSource.equals("custom")) throw new IllegalArgumentException("Pick a game.");
            gameId = Text.clip(in.get("gameId"), 64);
            gameName = Text.clip(in.get("gameName"), 160);
            if (gameId.isEmpty()) throw new IllegalArgumentException("Pick a game.");
        }
        String quizJson = null;
        if (type.equals("quiz")) {
            Object q = in.get("quiz");
            if (!(q instanceof Map<?, ?> qm) || !(((Map<String, Object>) qm).get("questions") instanceof List<?> qs) || qs.isEmpty()) {
                throw new IllegalArgumentException("A quiz needs at least one question.");
            }
            if (qs.size() > 50) throw new IllegalArgumentException("A quiz can have at most 50 questions.");
            List<Object> clean = new ArrayList<>();
            int i = 0;
            for (Object o : qs) {
                i++;
                Map<String, Object> qq = (Map<String, Object>) o;
                String text = Text.clip(qq.get("q"), 500);
                if (text.isEmpty()) throw new IllegalArgumentException("Question " + i + " needs some text.");
                List<Object> opts = new ArrayList<>();
                if (qq.get("options") instanceof List<?> ol) for (Object x : ol) {
                    String ot = Text.clip(x, 300);
                    if (!ot.isEmpty()) opts.add(ot);
                }
                if (opts.size() < 2 || opts.size() > 8) throw new IllegalArgumentException("Question " + i + " needs between two and eight options.");
                int ans = qq.get("answer") instanceof Number n ? n.intValue() : -1;
                if (ans < 0 || ans >= opts.size()) throw new IllegalArgumentException("Pick a correct answer for question " + i + ".");
                Map<String, Object> cq = new LinkedHashMap<>();
                cq.put("q", text);
                cq.put("options", opts);
                cq.put("answer", (long) ans);
                clean.add(cq);
            }
            int pass = ((Map<String, Object>) q).get("passMark") instanceof Number n ? n.intValue() : 70;
            Map<String, Object> out = new LinkedHashMap<>();
            out.put("passMark", (long) Math.min(100, Math.max(1, pass)));
            out.put("questions", clean);
            quizJson = Json.stringify(out);
        }
        return new Object[]{type, title, Boolean.TRUE.equals(in.get("required")), content, url, gameSource, gameId, gameName, quizJson};
    }

    public static String addItem(String moduleId, String courseId, Map<String, Object> in) throws SQLException {
        Object[] v = cleanItem(in);
        String id = Text.newId();
        int order = in.get("order") instanceof Number n ? n.intValue() : 0;
        Db.update("INSERT INTO items (id, module_id, course_id, type, title, sort_order, is_required, content, url, game_source, game_id, game_name, quiz_json) " +
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)", id, moduleId, courseId, v[0], v[1], order, v[2], v[3], v[4], v[5], v[6], v[7], v[8]);
        return id;
    }

    public static void replaceItem(String itemId, Map<String, Object> in) throws SQLException {
        Object[] v = cleanItem(in);
        int order = in.get("order") instanceof Number n ? n.intValue() : 0;
        Db.update("UPDATE items SET type=?, title=?, sort_order=?, is_required=?, content=?, url=?, game_source=?, game_id=?, game_name=?, quiz_json=? WHERE id=?",
            v[0], v[1], order, v[2], v[3], v[4], v[5], v[6], v[7], v[8], itemId);
    }

    public static void setItemOrder(String itemId, int order) throws SQLException {
        Db.update("UPDATE items SET sort_order = ? WHERE id = ?", order, itemId);
    }

    public static void deleteItem(String itemId) throws SQLException {
        Db.update("DELETE FROM items WHERE id = ?", itemId);
    }

    /** Seeding helper: inserts a starter syllabus entry. */
    public static void insertStarter(Connection c, int number, Map<String, Object> s) throws SQLException {
        String id = Text.newId();
        Db.update(c, "INSERT INTO courses (id, title, summary, description, category, icon, level, hours, output, game, status, number, author_name) " +
                "VALUES (?,?,?,?,?,?,?,?,?,?,'starter',?,?)",
            id, Text.clip(s.get("title"), 160), Text.clip(s.get("summary"), 300), Text.clip(s.get("description"), 20_000),
            Text.clip(s.get("category"), 60), Text.clip(s.get("icon"), 16), Text.clip(s.get("level"), 60), Text.clip(s.get("hours"), 40),
            Text.clip(s.get("output"), 500), Text.clip(s.get("game"), 160), number, "Temo-Learn");
        int order = 0;
        if (s.get("modules") instanceof List<?> ms) for (Object o : ms) {
            Map<?, ?> m = (Map<?, ?>) o;
            Db.update(c, "INSERT INTO modules (id, course_id, title, sort_order, points_json) VALUES (?,?,?,?,?)",
                Text.newId(), id, Text.clip(m.get("title"), 160), order++, Json.stringify(m.get("points") == null ? List.of() : m.get("points")));
        }
    }
}
