package bw.temo.dao;

import bw.temo.db.Db;
import bw.temo.util.Json;
import bw.temo.util.Text;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Accounts. The password hash is never part of the maps returned here. */
public final class Users {
    private Users() {}

    private static final String COLS =
        "uid, full_name, email, role, is_disabled, photo, avatar, school, grade, location, interests, bio, " +
        "title, organisation, phone, subjects, theme_mode, badges, created_at, last_login";

    /** The map is shaped like the profile object the browser code already expects. */
    private static Map<String, Object> row(ResultSet rs) throws SQLException {
        Map<String, Object> m = Db.map();
        m.put("uid", rs.getString("uid"));
        m.put("fullName", rs.getString("full_name"));
        m.put("email", rs.getString("email"));
        m.put("role", rs.getString("role"));
        m.put("disabled", rs.getBoolean("is_disabled"));
        m.put("photo", rs.getString("photo"));
        m.put("avatar", rs.getString("avatar"));
        m.put("school", rs.getString("school"));
        m.put("grade", rs.getString("grade"));
        m.put("location", rs.getString("location"));
        m.put("interests", rs.getString("interests"));
        m.put("bio", rs.getString("bio"));
        m.put("title", rs.getString("title"));
        m.put("organisation", rs.getString("organisation"));
        m.put("phone", rs.getString("phone"));
        m.put("subjects", rs.getString("subjects"));
        m.put("themeMode", rs.getString("theme_mode"));
        m.put("badges", badges(rs.getString("badges")));
        m.put("createdAt", Db.secs(rs, "created_at"));
        m.put("lastLogin", Db.secs(rs, "last_login"));
        return m;
    }

    private static List<Object> badges(String json) {
        try {
            Object o = Json.parse(json == null || json.isBlank() ? "[]" : json);
            return o instanceof List<?> l ? new ArrayList<>(l) : new ArrayList<>();
        } catch (RuntimeException e) {
            return new ArrayList<>();
        }
    }

    public static Map<String, Object> byId(String uid) throws SQLException {
        return Db.one("SELECT " + COLS + " FROM users WHERE uid = ?", Users::row, uid);
    }

    public static Map<String, Object> byEmail(String email) throws SQLException {
        return Db.one("SELECT " + COLS + " FROM users WHERE lower(email) = ?", Users::row, Text.email(email));
    }

    /** uid + stored hash + disabled flag, for the login check only. */
    public static Map<String, Object> credential(String email) throws SQLException {
        return Db.one("SELECT uid, password_hash, is_disabled FROM users WHERE lower(email) = ?", rs -> {
            Map<String, Object> m = Db.map();
            m.put("uid", rs.getString("uid"));
            m.put("hash", rs.getString("password_hash"));
            m.put("disabled", rs.getBoolean("is_disabled"));
            return m;
        }, Text.email(email));
    }

    public static String passwordHash(String uid) throws SQLException {
        return Db.one("SELECT password_hash FROM users WHERE uid = ?", rs -> rs.getString(1), uid);
    }

    public static boolean emailTaken(String email) throws SQLException {
        return Db.count("SELECT count(*) FROM users WHERE lower(email) = ?", Text.email(email)) > 0;
    }

    /** Returns the new uid. Throws SQLException (unique violation) if the email already exists. */
    public static String create(String fullName, String email, String hash, String role, String createdBy) throws SQLException {
        String uid = Text.newId();
        Db.update("INSERT INTO users (uid, full_name, email, password_hash, role, created_by) VALUES (?,?,?,?,?,?)",
            uid, Text.clip(fullName, 120), Text.email(email), hash, role, createdBy);
        return uid;
    }

    public static void touchLogin(String uid) throws SQLException {
        Db.update("UPDATE users SET last_login = UTC_TIMESTAMP() WHERE uid = ?", uid);
    }

    public static List<Map<String, Object>> all() throws SQLException {
        return Db.list("SELECT " + COLS + " FROM users ORDER BY created_at DESC LIMIT 2000", Users::row);
    }

    /** What a teacher may see about students: enough to enrol them, nothing private. */
    public static List<Map<String, Object>> students() throws SQLException {
        return Db.list("SELECT uid, full_name, email, photo, avatar FROM users WHERE role = 'student' AND NOT is_disabled " +
            "ORDER BY lower(full_name) LIMIT 1000", rs -> {
            Map<String, Object> m = Db.map();
            m.put("uid", rs.getString("uid"));
            m.put("fullName", rs.getString("full_name"));
            m.put("email", rs.getString("email"));
            m.put("photo", rs.getString("photo"));
            m.put("avatar", rs.getString("avatar"));
            return m;
        });
    }

    public static long countByRole(String role) throws SQLException {
        return Db.count("SELECT count(*) FROM users WHERE role = ?", role);
    }

    private static final Set<String> THEMES = Set.of("dark", "light", "auto");

    /**
     * Self-service profile edit. Only these fields can ever be changed here:
     * role, email, disabled and password are deliberately not on the list.
     */
    public static void updateOwnProfile(String uid, Map<String, Object> in) throws SQLException {
        Map<String, Object> cur = byId(uid);
        if (cur == null) return;
        String photo = in.containsKey("photo") ? String.valueOf(in.get("photo") == null ? "" : in.get("photo")) : (String) cur.get("photo");
        if (!photo.isEmpty() && (!photo.startsWith("data:image/") || photo.length() > 400_000)) {
            throw new IllegalArgumentException("That photo is not valid or is too large. Try a smaller image.");
        }
        String theme = in.containsKey("themeMode") ? String.valueOf(in.get("themeMode")) : (String) cur.get("themeMode");
        if (!THEMES.contains(theme)) theme = "dark";
        String fullName = in.containsKey("fullName") ? Text.clip(in.get("fullName"), 120) : (String) cur.get("fullName");
        if (fullName.isEmpty()) throw new IllegalArgumentException("Your name can't be empty.");

        Db.update("UPDATE users SET full_name=?, photo=?, avatar=?, school=?, grade=?, location=?, interests=?, bio=?, " +
                "title=?, organisation=?, phone=?, subjects=?, theme_mode=? WHERE uid=?",
            fullName, photo,
            pick(in, cur, "avatar", 16), pick(in, cur, "school", 120), pick(in, cur, "grade", 60),
            pick(in, cur, "location", 100), pick(in, cur, "interests", 200), pick(in, cur, "bio", 600),
            pick(in, cur, "title", 100), pick(in, cur, "organisation", 120), pick(in, cur, "phone", 40),
            pick(in, cur, "subjects", 200), theme, uid);
    }

    private static String pick(Map<String, Object> in, Map<String, Object> cur, String key, int max) {
        return in.containsKey(key) ? Text.clip(in.get(key), max) : (String) cur.get(key);
    }

    public static void setPassword(String uid, String hash) throws SQLException {
        Db.update("UPDATE users SET password_hash = ? WHERE uid = ?", hash, uid);
    }

    public static void setRole(String uid, String role) throws SQLException {
        Db.update("UPDATE users SET role = ? WHERE uid = ?", role, uid);
    }

    public static void setDisabled(String uid, boolean disabled) throws SQLException {
        Db.update("UPDATE users SET is_disabled = ? WHERE uid = ?", disabled, uid);
    }
}
