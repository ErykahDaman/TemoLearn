package bw.temo.dao;

import bw.temo.db.Db;
import bw.temo.util.Text;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Help & feedback from signed-in users, and messages from the public contact form. */
public final class Feedback {
    private Feedback() {}

    private static final String COLS = "id, user_id, user_name, email, role, type, subject, message, status, reply, replied_at, created_at";

    private static Map<String, Object> row(ResultSet rs) throws SQLException {
        Map<String, Object> m = Db.map();
        m.put("id", rs.getString("id"));
        m.put("uid", rs.getString("user_id"));
        m.put("name", rs.getString("user_name"));
        m.put("email", rs.getString("email"));
        m.put("role", rs.getString("role"));
        m.put("type", rs.getString("type"));
        m.put("subject", rs.getString("subject"));
        m.put("message", rs.getString("message"));
        m.put("status", rs.getString("status"));
        m.put("reply", rs.getString("reply"));
        m.put("repliedAt", Db.secs(rs, "replied_at"));
        m.put("createdAt", Db.secs(rs, "created_at"));
        return m;
    }

    /** uid may be null for the public contact form. */
    public static String add(String uid, String name, String email, String role, String type, String subject, String message) throws SQLException {
        String msg = Text.clip(message, 5000);
        if (msg.isEmpty()) throw new IllegalArgumentException("Write your message first.");
        String id = Text.newId();
        Db.update("INSERT INTO feedback (id, user_id, user_name, email, role, type, subject, message) VALUES (?,?,?,?,?,?,?,?)",
            id, uid, Text.clip(name, 120), Text.clip(email, 190), Text.clip(role, 20), Text.clip(type, 60), Text.clip(subject, 200), msg);
        return id;
    }

    public static List<Map<String, Object>> forUser(String uid) throws SQLException {
        return Db.list("SELECT " + COLS + " FROM feedback WHERE user_id = ? ORDER BY created_at DESC LIMIT 200", Feedback::row, uid);
    }

    public static List<Map<String, Object>> all() throws SQLException {
        return Db.list("SELECT " + COLS + " FROM feedback ORDER BY created_at DESC LIMIT 2000", Feedback::row);
    }

    private static final Set<String> STATUSES = Set.of("new", "open", "resolved");

    public static void reply(String id, String adminUid, String status, String reply) throws SQLException {
        if (!STATUSES.contains(status)) throw new IllegalArgumentException("Unknown status.");
        Db.update("UPDATE feedback SET status = ?, reply = ?, replied_by = ?, replied_at = UTC_TIMESTAMP() WHERE id = ?",
            status, Text.clip(reply, 5000), adminUid, id);
    }
}
