package bw.temo.dao;

import bw.temo.db.Db;
import bw.temo.util.Text;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

/** Discussion replies on a "discussion" activity. */
public final class Posts {
    private Posts() {}

    public static List<Map<String, Object>> list(String courseId, String itemId) throws SQLException {
        return Db.list("SELECT id, user_id, user_name, body, created_at FROM posts WHERE course_id = ? AND item_id = ? ORDER BY created_at LIMIT 500", rs -> {
            Map<String, Object> m = Db.map();
            m.put("id", rs.getString("id"));
            m.put("uid", rs.getString("user_id"));
            m.put("name", rs.getString("user_name"));
            m.put("text", rs.getString("body"));
            m.put("createdAt", Db.secs(rs, "created_at"));
            return m;
        }, courseId, itemId);
    }

    public static String add(String courseId, String itemId, String uid, String name, String text) throws SQLException {
        String body = Text.clip(text, 1000);
        if (body.isEmpty()) throw new IllegalArgumentException("Write something first.");
        String id = Text.newId();
        Db.update("INSERT INTO posts (id, course_id, item_id, user_id, user_name, body) VALUES (?,?,?,?,?,?)",
            id, courseId, itemId, uid, Text.clip(name, 120), body);
        return id;
    }

    public static Map<String, Object> byId(String id) throws SQLException {
        return Db.one("SELECT id, course_id, user_id FROM posts WHERE id = ?", rs -> {
            Map<String, Object> m = Db.map();
            m.put("id", rs.getString(1));
            m.put("courseId", rs.getString(2));
            m.put("uid", rs.getString(3));
            return m;
        }, id);
    }

    public static void delete(String id) throws SQLException {
        Db.update("DELETE FROM posts WHERE id = ?", id);
    }
}
