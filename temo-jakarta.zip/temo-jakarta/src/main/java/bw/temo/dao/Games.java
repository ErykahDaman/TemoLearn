package bw.temo.dao;

import bw.temo.db.Db;
import bw.temo.util.Text;
import java.net.URI;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

/** Games that teachers embed from outside sites. Only https links are accepted. */
public final class Games {
    private Games() {}

    private static final String COLS = "id, title, description, embed_url, height, instructions, is_visible, author_id, author_name, created_at";

    private static Map<String, Object> row(ResultSet rs) throws SQLException {
        Map<String, Object> m = Db.map();
        m.put("id", rs.getString("id"));
        m.put("title", rs.getString("title"));
        m.put("description", rs.getString("description"));
        m.put("embedUrl", rs.getString("embed_url"));
        m.put("height", (long) rs.getInt("height"));
        m.put("instructions", rs.getString("instructions"));
        m.put("visible", rs.getBoolean("is_visible"));
        m.put("authorId", rs.getString("author_id"));
        m.put("authorName", rs.getString("author_name"));
        m.put("createdAt", Db.secs(rs, "created_at"));
        return m;
    }

    public static Map<String, Object> byId(String id) throws SQLException {
        return Db.one("SELECT " + COLS + " FROM games WHERE id = ?", Games::row, id);
    }

    public static List<Map<String, Object>> visible() throws SQLException {
        return Db.list("SELECT " + COLS + " FROM games WHERE is_visible ORDER BY lower(title)", Games::row);
    }

    public static List<Map<String, Object>> byAuthor(String uid) throws SQLException {
        return Db.list("SELECT " + COLS + " FROM games WHERE author_id = ? ORDER BY created_at DESC", Games::row, uid);
    }

    public static List<Map<String, Object>> all() throws SQLException {
        return Db.list("SELECT " + COLS + " FROM games ORDER BY created_at DESC LIMIT 2000", Games::row);
    }

    /** Throws IllegalArgumentException with a friendly message when the link is not acceptable. */
    private static String checkEmbed(Object raw) {
        String url = Text.clip(raw, 700);
        try {
            URI u = new URI(url);
            if (!"https".equalsIgnoreCase(u.getScheme()) || u.getHost() == null) throw new IllegalArgumentException("Only secure (https) game links can be used.");
            if (u.getUserInfo() != null) throw new IllegalArgumentException("That game link isn't valid.");
        } catch (java.net.URISyntaxException e) {
            throw new IllegalArgumentException("That doesn't look like a valid link.");
        }
        return url;
    }

    private static int height(Object v) {
        int h = v instanceof Number n ? n.intValue() : 560;
        return Math.min(1000, Math.max(300, h));
    }

    public static String create(String authorId, String authorName, Map<String, Object> in) throws SQLException {
        String title = Text.clip(in.get("title"), 120);
        if (title.isEmpty()) throw new IllegalArgumentException("Give the game a title.");
        String id = Text.newId();
        Db.update("INSERT INTO games (id, title, description, embed_url, height, instructions, is_visible, author_id, author_name) VALUES (?,?,?,?,?,?,?,?,?)",
            id, title, Text.clip(in.get("description"), 300), checkEmbed(in.get("embedUrl")), height(in.get("height")),
            Text.clip(in.get("instructions"), 1000), !Boolean.FALSE.equals(in.get("visible")), authorId, Text.clip(authorName, 120));
        return id;
    }

    public static void update(String id, Map<String, Object> in) throws SQLException {
        String title = Text.clip(in.get("title"), 120);
        if (title.isEmpty()) throw new IllegalArgumentException("Give the game a title.");
        Db.update("UPDATE games SET title=?, description=?, embed_url=?, height=?, instructions=?, is_visible=? WHERE id=?",
            title, Text.clip(in.get("description"), 300), checkEmbed(in.get("embedUrl")), height(in.get("height")),
            Text.clip(in.get("instructions"), 1000), !Boolean.FALSE.equals(in.get("visible")), id);
    }

    public static void setVisible(String id, boolean visible) throws SQLException {
        Db.update("UPDATE games SET is_visible = ? WHERE id = ?", visible, id);
    }

    public static void delete(String id) throws SQLException {
        Db.update("DELETE FROM games WHERE id = ?", id);
    }
}
