package bw.temo.security;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;

/** One random token per session. Forms send it as _csrf, fetch() sends it as the X-CSRF-Token header. */
public final class Csrf {
    private Csrf() {}

    public static final String ATTR = "csrf";
    public static final String HEADER = "X-CSRF-Token";
    public static final String FIELD = "_csrf";
    private static final SecureRandom RNG = new SecureRandom();

    /** Returns the session's token, creating the session and token if needed. */
    public static String token(HttpServletRequest req) {
        HttpSession s = req.getSession(true);
        String t = (String) s.getAttribute(ATTR);
        if (t == null) {
            byte[] b = new byte[32];
            RNG.nextBytes(b);
            t = Base64.getUrlEncoder().withoutPadding().encodeToString(b);
            s.setAttribute(ATTR, t);
        }
        return t;
    }

    public static boolean valid(HttpServletRequest req) {
        HttpSession s = req.getSession(false);
        if (s == null) return false;
        String expected = (String) s.getAttribute(ATTR);
        if (expected == null) return false;
        String sent = req.getHeader(HEADER);
        if (sent == null || sent.isEmpty()) sent = req.getParameter(FIELD);
        if (sent == null) return false;
        return MessageDigest.isEqual(expected.getBytes(java.nio.charset.StandardCharsets.UTF_8), sent.getBytes(java.nio.charset.StandardCharsets.UTF_8));
    }
}
