package bw.temo.security;

import bw.temo.dao.Users;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import java.sql.SQLException;
import java.util.Map;

/** Signing in and out, and finding the signed-in user. */
public final class Sessions {
    private Sessions() {}

    public static final String UID = "uid";
    public static final String USER_ATTR = "temo.user";

    /** Starts a fresh session (new id: protects against session fixation) for this user. */
    public static void signIn(HttpServletRequest req, String uid) {
        HttpSession old = req.getSession(false);
        if (old != null) old.invalidate();
        HttpSession s = req.getSession(true);
        s.setMaxInactiveInterval(60 * 60 * 8);
        s.setAttribute(UID, uid);
        Csrf.token(req);
    }

    public static void signOut(HttpServletRequest req) {
        HttpSession s = req.getSession(false);
        if (s != null) s.invalidate();
    }

    /**
     * The current user, re-read from the database on every request so a disabled account or
     * a changed role takes effect immediately. null if nobody is signed in.
     */
    @SuppressWarnings("unchecked")
    public static Map<String, Object> current(HttpServletRequest req) {
        Object cached = req.getAttribute(USER_ATTR);
        if (cached != null) return (Map<String, Object>) cached;
        HttpSession s = req.getSession(false);
        if (s == null) return null;
        String uid = (String) s.getAttribute(UID);
        if (uid == null) return null;
        try {
            Map<String, Object> u = Users.byId(uid);
            if (u == null || Boolean.TRUE.equals(u.get("disabled"))) {
                s.invalidate();
                return null;
            }
            req.setAttribute(USER_ATTR, u);
            return u;
        } catch (SQLException e) {
            throw new IllegalStateException("Could not load the signed-in user", e);
        }
    }

    public static String homeFor(Object role) {
        return switch (String.valueOf(role)) {
            case "admin" -> "/portal/admin";
            case "teacher" -> "/portal/teacher";
            default -> "/portal/student";
        };
    }
}
