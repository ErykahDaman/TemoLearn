package bw.temo.security;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Slows down password guessing: 8 failures per key (email or address) lock that key for 10 minutes. */
public final class LoginThrottle {
    private LoginThrottle() {}

    private static final int MAX = 8;
    private static final long WINDOW_MS = 10 * 60_000L;
    private record Entry(int fails, long first) {}
    private static final Map<String, Entry> MAP = new ConcurrentHashMap<>();

    public static boolean blocked(String key) {
        Entry e = MAP.get(key);
        if (e == null) return false;
        if (System.currentTimeMillis() - e.first > WINDOW_MS) { MAP.remove(key); return false; }
        return e.fails >= MAX;
    }

    public static void fail(String key) {
        long now = System.currentTimeMillis();
        MAP.merge(key, new Entry(1, now), (old, n) -> now - old.first > WINDOW_MS ? n : new Entry(old.fails + 1, old.first));
        if (MAP.size() > 20_000) MAP.entrySet().removeIf(en -> now - en.getValue().first > WINDOW_MS);
    }

    public static void clear(String key) {
        MAP.remove(key);
    }
}
