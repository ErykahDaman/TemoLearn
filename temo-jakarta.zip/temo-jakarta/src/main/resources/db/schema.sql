-- Temo-Learn schema for MySQL 8.0.13+ (MariaDB 10.5+ also works).
-- Safe to run on every start: everything is CREATE TABLE IF NOT EXISTS.
-- Statements end with a semicolon at the end of a line.
-- Times are stored in UTC. The default collation is case-insensitive, so emails are unique regardless of case.

CREATE TABLE IF NOT EXISTS users (
    uid           VARCHAR(36)  NOT NULL PRIMARY KEY,
    full_name     VARCHAR(120) NOT NULL,
    email         VARCHAR(190) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role          VARCHAR(20)  NOT NULL,
    is_disabled   BOOLEAN      NOT NULL DEFAULT FALSE,
    photo         MEDIUMTEXT   NOT NULL DEFAULT (''),
    avatar        VARCHAR(16)  NOT NULL DEFAULT '',
    school        VARCHAR(120) NOT NULL DEFAULT '',
    grade         VARCHAR(60)  NOT NULL DEFAULT '',
    location      VARCHAR(100) NOT NULL DEFAULT '',
    interests     VARCHAR(200) NOT NULL DEFAULT '',
    bio           VARCHAR(600) NOT NULL DEFAULT '',
    title         VARCHAR(100) NOT NULL DEFAULT '',
    organisation  VARCHAR(120) NOT NULL DEFAULT '',
    phone         VARCHAR(40)  NOT NULL DEFAULT '',
    subjects      VARCHAR(200) NOT NULL DEFAULT '',
    theme_mode    VARCHAR(10)  NOT NULL DEFAULT 'dark',
    badges        TEXT         NOT NULL DEFAULT ('[]'),
    created_by    VARCHAR(36)  NULL,
    created_at    DATETIME     NOT NULL DEFAULT (UTC_TIMESTAMP()),
    last_login    DATETIME     NULL,
    UNIQUE KEY users_email_uq (email),
    CONSTRAINT users_role_chk CHECK (role IN ('student', 'teacher', 'admin'))
) DEFAULT CHARSET = utf8mb4;

CREATE TABLE IF NOT EXISTS courses (
    id          VARCHAR(36)  NOT NULL PRIMARY KEY,
    title       VARCHAR(160) NOT NULL,
    summary     VARCHAR(300) NOT NULL DEFAULT '',
    description MEDIUMTEXT   NOT NULL DEFAULT (''),
    category    VARCHAR(60)  NOT NULL DEFAULT 'General',
    icon        VARCHAR(16)  NOT NULL DEFAULT '',
    level       VARCHAR(60)  NOT NULL DEFAULT '',
    hours       VARCHAR(40)  NOT NULL DEFAULT '',
    output      VARCHAR(500) NOT NULL DEFAULT '',
    game        VARCHAR(160) NOT NULL DEFAULT '',
    thumbnail   MEDIUMTEXT   NOT NULL DEFAULT (''),
    -- draft = teacher is still working, published = learners can enrol,
    -- starter = built-in syllabus entry shown on the public site (a template teachers can copy)
    status      VARCHAR(12)  NOT NULL DEFAULT 'draft',
    number      INT          NULL,
    author_id   VARCHAR(36)  NULL,
    author_name VARCHAR(120) NOT NULL DEFAULT '',
    created_at  DATETIME     NOT NULL DEFAULT (UTC_TIMESTAMP()),
    KEY courses_author_idx (author_id),
    KEY courses_status_idx (status),
    CONSTRAINT courses_status_chk CHECK (status IN ('draft', 'published', 'starter'))
) DEFAULT CHARSET = utf8mb4;

CREATE TABLE IF NOT EXISTS modules (
    id          VARCHAR(36)  NOT NULL PRIMARY KEY,
    course_id   VARCHAR(36)  NOT NULL,
    title       VARCHAR(160) NOT NULL,
    sort_order  INT          NOT NULL DEFAULT 0,
    is_locked   BOOLEAN      NOT NULL DEFAULT FALSE,
    points_json TEXT         NOT NULL DEFAULT ('[]'),
    KEY modules_course_idx (course_id),
    CONSTRAINT modules_course_fk FOREIGN KEY (course_id) REFERENCES courses (id) ON DELETE CASCADE
) DEFAULT CHARSET = utf8mb4;

CREATE TABLE IF NOT EXISTS items (
    id          VARCHAR(36)  NOT NULL PRIMARY KEY,
    module_id   VARCHAR(36)  NOT NULL,
    course_id   VARCHAR(36)  NOT NULL,
    type        VARCHAR(20)  NOT NULL,
    title       VARCHAR(200) NOT NULL,
    sort_order  INT          NOT NULL DEFAULT 0,
    is_required BOOLEAN      NOT NULL DEFAULT FALSE,
    content     MEDIUMTEXT   NOT NULL DEFAULT (''),
    url         VARCHAR(600) NOT NULL DEFAULT '',
    game_source VARCHAR(12)  NOT NULL DEFAULT '',
    game_id     VARCHAR(64)  NOT NULL DEFAULT '',
    game_name   VARCHAR(160) NOT NULL DEFAULT '',
    quiz_json   MEDIUMTEXT   NULL,
    KEY items_module_idx (module_id),
    KEY items_course_idx (course_id),
    CONSTRAINT items_module_fk FOREIGN KEY (module_id) REFERENCES modules (id) ON DELETE CASCADE,
    CONSTRAINT items_course_fk FOREIGN KEY (course_id) REFERENCES courses (id) ON DELETE CASCADE,
    CONSTRAINT items_type_chk CHECK (type IN ('page', 'video', 'link', 'quiz', 'discussion', 'game'))
) DEFAULT CHARSET = utf8mb4;

CREATE TABLE IF NOT EXISTS enrollments (
    user_id       VARCHAR(36) NOT NULL,
    course_id     VARCHAR(36) NOT NULL,
    is_completed  BOOLEAN     NOT NULL DEFAULT FALSE,
    started_at    DATETIME    NOT NULL DEFAULT (UTC_TIMESTAMP()),
    last_active   DATETIME    NOT NULL DEFAULT (UTC_TIMESTAMP()),
    completed_at  DATETIME    NULL,
    last_module   VARCHAR(36) NULL,
    last_item     VARCHAR(36) NULL,
    self_enrolled BOOLEAN     NOT NULL DEFAULT FALSE,
    enrolled_by   VARCHAR(36) NULL,
    PRIMARY KEY (user_id, course_id),
    KEY enrollments_course_idx (course_id),
    CONSTRAINT enrollments_user_fk   FOREIGN KEY (user_id)   REFERENCES users (uid)  ON DELETE CASCADE,
    CONSTRAINT enrollments_course_fk FOREIGN KEY (course_id) REFERENCES courses (id) ON DELETE CASCADE
) DEFAULT CHARSET = utf8mb4;

CREATE TABLE IF NOT EXISTS enrollment_items (
    user_id   VARCHAR(36) NOT NULL,
    course_id VARCHAR(36) NOT NULL,
    item_id   VARCHAR(36) NOT NULL,
    PRIMARY KEY (user_id, course_id, item_id),
    KEY enrollment_items_item_idx (item_id),
    CONSTRAINT enrollment_items_item_fk FOREIGN KEY (item_id) REFERENCES items (id) ON DELETE CASCADE,
    CONSTRAINT enrollment_items_enr_fk  FOREIGN KEY (user_id, course_id) REFERENCES enrollments (user_id, course_id) ON DELETE CASCADE
) DEFAULT CHARSET = utf8mb4;

CREATE TABLE IF NOT EXISTS quiz_scores (
    user_id   VARCHAR(36) NOT NULL,
    course_id VARCHAR(36) NOT NULL,
    item_id   VARCHAR(36) NOT NULL,
    pct       INT         NOT NULL,
    PRIMARY KEY (user_id, course_id, item_id),
    KEY quiz_scores_item_idx (item_id),
    CONSTRAINT quiz_scores_item_fk FOREIGN KEY (item_id) REFERENCES items (id) ON DELETE CASCADE,
    CONSTRAINT quiz_scores_enr_fk  FOREIGN KEY (user_id, course_id) REFERENCES enrollments (user_id, course_id) ON DELETE CASCADE,
    CONSTRAINT quiz_scores_pct_chk CHECK (pct BETWEEN 0 AND 100)
) DEFAULT CHARSET = utf8mb4;

CREATE TABLE IF NOT EXISTS games (
    id           VARCHAR(36)   NOT NULL PRIMARY KEY,
    title        VARCHAR(120)  NOT NULL,
    description  VARCHAR(300)  NOT NULL DEFAULT '',
    embed_url    VARCHAR(700)  NOT NULL,
    height       INT           NOT NULL DEFAULT 560,
    instructions VARCHAR(1000) NOT NULL DEFAULT '',
    is_visible   BOOLEAN       NOT NULL DEFAULT TRUE,
    author_id    VARCHAR(36)   NULL,
    author_name  VARCHAR(120)  NOT NULL DEFAULT '',
    created_at   DATETIME      NOT NULL DEFAULT (UTC_TIMESTAMP())
) DEFAULT CHARSET = utf8mb4;

CREATE TABLE IF NOT EXISTS posts (
    id         VARCHAR(36)   NOT NULL PRIMARY KEY,
    course_id  VARCHAR(36)   NOT NULL,
    item_id    VARCHAR(36)   NOT NULL,
    user_id    VARCHAR(36)   NOT NULL,
    user_name  VARCHAR(120)  NOT NULL,
    body       VARCHAR(1000) NOT NULL,
    created_at DATETIME      NOT NULL DEFAULT (UTC_TIMESTAMP()),
    KEY posts_item_idx (course_id, item_id),
    CONSTRAINT posts_course_fk FOREIGN KEY (course_id) REFERENCES courses (id) ON DELETE CASCADE,
    CONSTRAINT posts_item_fk   FOREIGN KEY (item_id)   REFERENCES items (id)   ON DELETE CASCADE,
    CONSTRAINT posts_user_fk   FOREIGN KEY (user_id)   REFERENCES users (uid)  ON DELETE CASCADE
) DEFAULT CHARSET = utf8mb4;

-- Help & feedback from signed-in users AND messages from the public contact form (user_id is NULL for those).
CREATE TABLE IF NOT EXISTS feedback (
    id         VARCHAR(36)  NOT NULL PRIMARY KEY,
    user_id    VARCHAR(36)  NULL,
    user_name  VARCHAR(120) NOT NULL DEFAULT '',
    email      VARCHAR(190) NOT NULL DEFAULT '',
    role       VARCHAR(20)  NOT NULL DEFAULT '',
    type       VARCHAR(60)  NOT NULL DEFAULT '',
    subject    VARCHAR(200) NOT NULL DEFAULT '',
    message    MEDIUMTEXT   NOT NULL,
    status     VARCHAR(12)  NOT NULL DEFAULT 'new',
    reply      MEDIUMTEXT   NOT NULL DEFAULT (''),
    replied_by VARCHAR(36)  NULL,
    replied_at DATETIME     NULL,
    created_at DATETIME     NOT NULL DEFAULT (UTC_TIMESTAMP()),
    KEY feedback_user_idx (user_id),
    KEY feedback_status_idx (status),
    CONSTRAINT feedback_user_fk FOREIGN KEY (user_id) REFERENCES users (uid) ON DELETE SET NULL,
    CONSTRAINT feedback_status_chk CHECK (status IN ('new', 'open', 'resolved'))
) DEFAULT CHARSET = utf8mb4;
