/* The course viewer: outline -> activity, with progress saved to the student's enrolment.
   openCourse() is used by My Learning and by the dashboard's "Continue" button. */
import { openModal, toast } from "./ui.js";
import { renderMarkdown, youtubeId } from "./render.js";
import { makeGameFrame } from "./embed.js";
import {
    loadLearnerOutline, courseProgress, setDone, submitQuiz, setLastItem,
    getGame, listPosts, addPost, deletePost
} from "./student-api.js";
import { GAMES } from "./games-data.js";
import { esc, ACTIVITY_ICONS, plural } from "./student-shared.js";

const TYPE_LABEL = { page: "Page", video: "Video", link: "File or link", quiz: "Quiz", discussion: "Discussion", game: "Game" };
const isHttp = (u) => /^https?:\/\//i.test(String(u || ""));

export async function openCourse({ user, profile, course, enr, onChange, startItemId }) {
    const m = openModal(`<div class="viewer" id="lv"><p class="muted">Loading the course…</p></div>`, { wide: true });
    const box = m.$("#lv");
    let mods = [];
    enr.completedItems = enr.completedItems || [];

    try {
        mods = await loadLearnerOutline(course.id);
    } catch (err) {
        console.error(err);
        box.innerHTML = `<h2>${esc(course.title)}</h2><p class="muted">Couldn't load this course. Check your connection and try again.</p>`;
        return;
    }

    const flat = () => mods.filter((x) => !x.locked).flatMap((x) => x.items.map((i) => ({ mod: x, item: i })));
    const isDone = (id) => enr.completedItems.includes(id);

    /* ---------- Outline ---------- */
    function showOutline() {
        const prog = courseProgress(enr, mods);
        const sections = mods.map((sec, si) => {
            if (sec.locked) {
                return `<section class="o-sec"><header>${si + 1}. ${esc(sec.title)}<small>🔒 Locked</small></header>
                  <div class="o-locked">Your teacher hasn't opened this section yet.</div></section>`;
            }
            const done = sec.items.filter((i) => isDone(i.id)).length;
            const items = sec.items.length ? sec.items.map((i) => `
              <li><button class="o-item${isDone(i.id) ? " done" : ""}" data-item="${esc(i.id)}" data-mod="${esc(sec.id)}" type="button">
                <span class="o-dot">${isDone(i.id) ? "✓" : ""}</span>
                <span class="o-title">${ACTIVITY_ICONS[i.type] || "📄"} ${esc(i.title)}</span>
                <span class="o-type">${esc(TYPE_LABEL[i.type] || "")}${i.required ? " · required" : ""}</span>
              </button></li>`).join("") : `<li class="o-locked">No activities in this section yet.</li>`;
            return `<section class="o-sec"><header>${si + 1}. ${esc(sec.title)}<small>${done}/${sec.items.length} done</small></header>
              <ul class="o-items">${items}</ul></section>`;
        }).join("");

        box.innerHTML = `
          <span class="hud-chip">${esc(course.category || "Course")}</span>
          <h2>${esc(course.icon || "📜")} ${esc(course.title)}</h2>
          <div class="quest-top"><span>${plural(prog.done, "activity")} of ${prog.total} done</span><span>${prog.pct}%</span></div>
          <div class="meter" style="--pct:${prog.pct}%"><span></span></div>
          ${enr.completed ? `<p class="quiz-result pass">🎉 You've completed this course.</p>` : ""}
          <div class="outline">${sections || `<p class="muted">This course has no content yet. Check back soon.</p>`}</div>`;
    }

    /* ---------- One activity ---------- */
    async function showItem(sec, item) {
        setLastItem(user, course.id, sec.id, item.id).catch(() => {});
        enr.lastItem = item.id;

        const list = flat();
        const idx = list.findIndex((x) => x.item.id === item.id);
        const next = list[idx + 1];

        box.innerHTML = `
          <button class="btn btn-ghost btn-sm" data-back type="button">← Course outline</button>
          <h2 style="margin-top:16px">${ACTIVITY_ICONS[item.type] || "📄"} ${esc(item.title)}</h2>
          <p class="item-meta">${esc(TYPE_LABEL[item.type] || "Activity")} · ${esc(sec.title)}</p>
          <div id="body"><p class="muted">Loading…</p></div>
          <div class="btn-row section-gap" id="foot"></div>`;
        const body = box.querySelector("#body");
        const foot = box.querySelector("#foot");

        const paintFoot = () => {
            foot.innerHTML = `
              ${item.type === "quiz" ? "" : `<button class="btn ${isDone(item.id) ? "btn-ghost" : "btn-gold"}" data-done type="button">${isDone(item.id) ? "✓ Completed (undo)" : "Mark as complete"}</button>`}
              ${next ? `<button class="btn btn-ghost" data-next type="button">Next: ${esc(next.item.title.slice(0, 28))} →</button>` : ""}`;
        };
        paintFoot();

        foot.addEventListener("click", async (e) => {
            if (e.target.closest("[data-next]")) return showItem(next.mod, next.item);
            const b = e.target.closest("[data-done]");
            if (!b) return;
            b.disabled = true;
            await toggleDone(item, !isDone(item.id));
            paintFoot();
        });

        if (item.type === "page") {
            body.innerHTML = `<div class="prose">${renderMarkdown(item.content || "")}</div>`;
        } else if (item.type === "video") {
            const id = youtubeId(item.url);
            body.innerHTML = id
                ? `<div class="video-wrap"><iframe src="https://www.youtube-nocookie.com/embed/${id}" title="${esc(item.title)}" loading="lazy" allowfullscreen referrerpolicy="strict-origin-when-cross-origin"></iframe></div>`
                : (isHttp(item.url) ? `<p><a class="btn btn-gold" href="${esc(item.url)}" target="_blank" rel="noopener noreferrer">▶ Watch the video</a></p>` : `<p class="muted">The video link is missing.</p>`);
            if (item.content) body.innerHTML += `<div class="prose">${renderMarkdown(item.content)}</div>`;
        } else if (item.type === "link") {
            body.innerHTML = (isHttp(item.url)
                ? `<p><a class="btn btn-gold" href="${esc(item.url)}" target="_blank" rel="noopener noreferrer">🔗 Open the link</a></p>`
                : `<p class="muted">The link is missing.</p>`)
                + (item.content ? `<div class="prose">${renderMarkdown(item.content)}</div>` : "");
        } else if (item.type === "game") {
            await showGame(item, body);
        } else if (item.type === "quiz") {
            showQuiz(item, body, paintFoot);
        } else if (item.type === "discussion") {
            await showDiscussion(item, body);
        } else {
            body.innerHTML = `<p class="muted">This kind of activity can't be shown here yet.</p>`;
        }
    }

    async function showGame(item, body) {
        const intro = item.content ? `<div class="prose">${renderMarkdown(item.content)}</div>` : "";
        if (item.gameSource === "custom") {
            let g = null;
            try { g = await getGame(item.gameId); } catch (err) { console.warn(err); }
            if (!g || g.visible === false) {
                body.innerHTML = `${intro}<p class="muted">This game isn't available right now.</p>`;
                return;
            }
            body.innerHTML = `${intro}${g.instructions ? `<p>${esc(g.instructions)}</p>` : ""}<div class="embed-wrap" id="slot"></div>
              <p class="hint">If nothing loads, the game's website may not allow embedding.</p>`;
            body.querySelector("#slot").appendChild(makeGameFrame(g.embedUrl, g.height || 560, g.title));
        } else {
            const g = GAMES.find((x) => x.id === item.gameId);
            body.innerHTML = `${intro}<div class="panel-dark"><h3>🎮 ${esc(g ? g.name : item.gameName || "Game")}</h3>
              <p class="muted" style="margin:0">This Temo-Learn game is still being built. It will play right here as soon as it's ready.</p></div>`;
        }
    }

    function showQuiz(item, body, paintFoot) {
        const qs = (item.quiz && item.quiz.questions) || [];
        const pass = (item.quiz && item.quiz.passMark) || 70;
        if (!qs.length) { body.innerHTML = `<p class="muted">This quiz has no questions yet.</p>`; return; }
        let best = enr.quizScores && enr.quizScores[item.id];

        const paint = (answers = null, key = null) => {
            body.innerHTML = `
              <p class="muted">Pass mark: ${pass}%.${best != null ? ` Your best score so far: <strong>${best}%</strong>.` : ""}</p>
              <form id="qz">
                ${qs.map((q, qi) => `
                  <div class="quiz-q"><p>${qi + 1}. ${esc(q.q)}</p>
                    ${q.options.map((o, oi) => {
                        const cls = answers ? (oi === key[qi] ? "right" : (answers[qi] === oi ? "wrong" : "")) : "";
                        return `<label class="${cls}"><input type="radio" name="q${qi}" value="${oi}"${answers && answers[qi] === oi ? " checked" : ""}${answers ? " disabled" : ""}> ${esc(o)}</label>`;
                    }).join("")}
                  </div>`).join("")}
                <div id="qres"></div>
                ${answers ? `<button class="btn btn-ghost" type="button" data-retry>Try again</button>` : `<button class="btn btn-gold" type="submit">Submit answers</button>`}
              </form>`;
        };
        paint();

        body.addEventListener("click", (e) => { if (e.target.closest("[data-retry]")) paint(); });
        body.addEventListener("submit", async (e) => {
            e.preventDefault();
            const form = e.target;
            const answers = qs.map((_, qi) => {
                const c = form.querySelector(`input[name="q${qi}"]:checked`);
                return c ? Number(c.value) : -1;
            });
            if (answers.includes(-1)) { toast("Answer every question first.", true); return; }
            const btn = form.querySelector('button[type="submit"]');
            if (btn) btn.disabled = true;
            let res;
            try {
                res = await submitQuiz(user, course.id, item.id, answers);
            } catch (err) {
                console.error(err);
                if (btn) btn.disabled = false;
                toast(err.message || "Couldn't mark your quiz.", true);
                return;
            }
            // The server has marked it; only now does the browser learn which answers were right.
            paint(answers, res.correct);
            body.querySelector("#qres").innerHTML =
                `<p class="quiz-result ${res.passed ? "pass" : "fail"}">${res.passed ? "✓ Passed" : "✗ Not yet"}: ${res.right} of ${res.total} correct (${res.pct}%)</p>`;
            best = res.best;
            enr.quizScores = { ...(enr.quizScores || {}), [item.id]: res.best };
            if (res.completedItems) applyProgress(res);
            paintFoot();
        });
    }

    async function showDiscussion(item, body) {
        body.innerHTML = `<div class="prose">${renderMarkdown(item.content || "")}</div>
          <h3 style="margin-top:20px">Discussion</h3><div id="posts"><p class="muted">Loading…</p></div>
          <form id="pf" class="section-gap"><div class="field"><label for="pt">Add your reply</label>
            <textarea id="pt" rows="3" maxlength="1000" required style="min-height:90px"></textarea></div>
            <button class="btn btn-gold btn-sm" type="submit">Post reply</button></form>`;
        const slot = body.querySelector("#posts");
        let posts = [];
        const paint = () => {
            slot.innerHTML = posts.length ? posts.map((p) => `
              <div class="post"><strong>${esc(p.name)}</strong>
                <span class="hint"> · ${p.createdAt && p.createdAt.toDate ? esc(p.createdAt.toDate().toLocaleString("en-GB")) : "just now"}</span>
                ${p.uid === user.uid ? ` <button class="link-btn" data-del="${esc(p.id)}" type="button">delete</button>` : ""}
                <p>${esc(p.text)}</p></div>`).join("") : `<p class="muted">No replies yet. Be the first.</p>`;
        };
        try { posts = await listPosts(course.id, item.id); paint(); }
        catch (err) { console.warn(err); slot.innerHTML = `<p class="muted">Couldn't load the discussion.</p>`; }

        body.querySelector("#pf").addEventListener("submit", async (e) => {
            e.preventDefault();
            const ta = body.querySelector("#pt");
            const text = ta.value.trim();
            if (!text) return;
            try {
                await addPost(user, profile, course.id, item.id, text);
                ta.value = "";
                posts = await listPosts(course.id, item.id); paint();
            } catch (err) { console.error(err); toast("Couldn't post your reply.", true); }
        });
        slot.addEventListener("click", async (e) => {
            const d = e.target.closest("[data-del]");
            if (!d || !confirm("Delete your reply?")) return;
            try { await deletePost(d.dataset.del); posts = posts.filter((p) => p.id !== d.dataset.del); paint(); }
            catch (err) { console.error(err); toast("Couldn't delete that reply.", true); }
        });
    }

    /* ---------- Progress ---------- */
    function applyProgress(res) {
        enr.completedItems = res.completedItems;
        enr.completed = res.completed;
        if (res.justCompleted) toast("🎉 Course complete. Well done!");
        onChange && onChange();
    }

    async function toggleDone(item, done) {
        try {
            applyProgress(await setDone(user, course.id, item.id, done));
        } catch (err) {
            console.error(err);
            toast(err.message || "Couldn't save your progress. Please try again.", true);
        }
    }

    /* ---------- Clicks ---------- */
    box.addEventListener("click", (e) => {
        if (e.target.closest("[data-back]")) return showOutline();
        const b = e.target.closest("[data-item]");
        if (!b) return;
        const sec = mods.find((x) => x.id === b.dataset.mod);
        const item = sec && sec.items.find((x) => x.id === b.dataset.item);
        if (item) showItem(sec, item);
    });

    const start = startItemId && flat().find((x) => x.item.id === startItemId);
    if (start) showItem(start.mod, start.item); else showOutline();
}
