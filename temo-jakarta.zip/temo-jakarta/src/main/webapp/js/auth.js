/* Who is signed in. The server puts the answer in the page (the #boot data block), and it has
   already refused anyone who shouldn't be here, so this only has to hand it over. */
import { boot, postForm } from "./api.js";

export function homeFor(role) {
    return {
        admin: "portal/admin",
        teacher: "portal/teacher",
        student: "portal/student"
    }[role] || "portal/student";
}

export function requireRole(allowed) {
    if (!boot || !boot.profile) {
        location.href = "login";
        return new Promise(() => {});
    }
    if (!allowed.includes(boot.profile.role)) {
        location.href = homeFor(boot.profile.role);
        return new Promise(() => {});
    }
    return Promise.resolve({ user: boot.user, profile: boot.profile });
}

export async function logOut() {
    try { await postForm("logout"); } catch { /* leaving anyway */ }
}

export const friendlyError = (err) => (err && err.message) || "Something went wrong. Please try again.";
