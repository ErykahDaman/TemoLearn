import { get, post, put, del } from "./api.js";

const enc = encodeURIComponent;

/* ---------- Games ---------- */
export const listMyGames = () => get("teacher/games");

export async function saveGame(user, id, data) {
    if (id) { await put(`teacher/games/${enc(id)}`, data); return id; }
    const g = await post("teacher/games", data);
    return g.id;
}

export const deleteGameDoc = (id) => del(`teacher/games/${enc(id)}`);

/* ---------- Students + enrolments ---------- */
export const listAllStudents = () => get("teacher/students");
export const listEnrollments = (courseId) => get(`teacher/courses/${enc(courseId)}/enrollments`);
export const listMyEnrollmentsAll = () => get("teacher/enrollments");

/* The server skips students who are already enrolled, so progress is never reset. */
export const enrolStudent = (teacher, courseId, s) =>
    post(`teacher/courses/${enc(courseId)}/enrollments`, { uids: [s.uid] });

export const enrolStudents = (courseId, uids) =>
    post(`teacher/courses/${enc(courseId)}/enrollments`, { uids });

export const unenrolStudent = (uid, courseId) => del(`teacher/courses/${enc(courseId)}/enrollments/${enc(uid)}`);

/* ---------- Profile ---------- */
export const saveMyProfile = (user, patch) => put("common/profile", patch);

export const changePassword = (currentPassword, newPassword) =>
    post("common/password", { current: currentPassword, next: newPassword });

/* ---------- Help & feedback ---------- */
export const sendFeedback = (user, profile, { type, subject, message }) =>
    post("common/feedback", { type, subject, message });

export const listMyFeedback = () => get("common/feedback/mine");
