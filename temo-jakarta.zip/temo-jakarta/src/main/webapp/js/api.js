/* The one place that talks to the Java servlets under /api.
   Relative URLs on purpose: every page has <base href="{context path}/">, so this works
   whether the app is deployed at /temo-learn/ or at the root. */

const bootEl = document.getElementById("boot");
export const boot = bootEl ? JSON.parse(bootEl.textContent) : null;
const csrf = boot ? boot.csrf : "";

/* The servers sends times as epoch seconds. The pages expect {seconds, toDate()}. */
const TIME_KEYS = new Set(["createdAt", "startedAt", "lastActive", "completedAt", "repliedAt", "lastLogin"]);
const toTime = (s) => ({ seconds: s, toDate: () => new Date(s * 1000) });

function revive(v) {
    if (Array.isArray(v)) return v.map(revive);
    if (v && typeof v === "object") {
        const out = {};
        for (const [k, x] of Object.entries(v)) {
            out[k] = TIME_KEYS.has(k) && typeof x === "number" ? toTime(x) : revive(x);
        }
        return out;
    }
    return v;
}

export class ApiError extends Error {
    constructor(message, code, status) {
        super(message);
        this.code = code;
        this.status = status;
    }
}

async function call(method, path, body) {
    const opts = { method, credentials: "same-origin", headers: { Accept: "application/json", "X-CSRF-Token": csrf } };
    if (body !== undefined) {
        opts.headers["Content-Type"] = "application/json";
        opts.body = JSON.stringify(body);
    }
    let res;
    try {
        res = await fetch("api/" + path, opts);
    } catch {
        throw new ApiError("Couldn't reach the server. Check your connection and try again.", "network", 0);
    }
    let data = null;
    try { data = await res.json(); } catch { /* empty or not JSON */ }
    if (res.status === 401) {
        location.href = "login";
        throw new ApiError("Please sign in again.", "unauthenticated", 401);
    }
    if (!res.ok) {
        throw new ApiError((data && data.error) || "Something went wrong. Please try again.", (data && data.code) || "error", res.status);
    }
    return revive(data);
}

export const get = (path) => call("GET", path);
export const post = (path, body = {}) => call("POST", path, body);
export const put = (path, body = {}) => call("PUT", path, body);
export const del = (path) => call("DELETE", path);

export async function postForm(path) {
    return fetch(path, { method: "POST", credentials: "same-origin", headers: { "X-CSRF-Token": csrf } });
}
