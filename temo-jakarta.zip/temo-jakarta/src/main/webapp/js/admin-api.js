/* Everything the admin console reads and writes. The server only lets admins call these. */
import { get, post, put, del } from "./api.js";

const enc = encodeURIComponent;

/* ---------- Reads ---------- */
export const listUsers = () => get("admin/users");
export const listAllCourses = () => get("admin/courses");
export const listAllGames = () => get("admin/games");
export const listAllEnrollments = () => get("admin/enrollments");
export const listAllFeedback = () => get("admin/feedback");

/* ---------- Users ---------- */
export const setUserRole = (uid, role) => put(`admin/users/${enc(uid)}`, { role });
export const setUserDisabled = (uid, disabled) => put(`admin/users/${enc(uid)}`, { disabled: !!disabled });
export const resetUserPassword = (uid, password) => post(`admin/users/${enc(uid)}/password`, { password });

/* Teachers are created here, never through the public sign-up form. */
export async function createTeacher({ fullName, email, password, title }) {
    const u = await post("admin/teachers", { fullName, email, password, title });
    return u.uid;
}

/* ---------- Content ---------- */
export const setCourseStatus = (id, status) => post(`admin/courses/${enc(id)}/status`, { status });
export const deleteCourse = (id) => del(`admin/courses/${enc(id)}`);
export const setGameVisible = (id, visible) => put(`admin/games/${enc(id)}/visible`, { visible: !!visible });
export const deleteGame = (id) => del(`admin/games/${enc(id)}`);

/* ---------- Feedback ---------- */
export const saveFeedbackReply = (id, adminUid, { status, reply }) =>
    put(`admin/feedback/${enc(id)}`, { status, reply: reply || "" });
