import { get, post, put, del } from "./api.js";

const enc = encodeURIComponent;

/* ---------- Courses ---------- */
export async function createCourseDoc(user, data) {
    const c = await post("teacher/courses", data);
    return c.id;
}

export const getCourseDoc = (id) => get(`teacher/courses/${enc(id)}`);

export async function updateCourseDoc(id, data) {
    const { status, ...rest } = data;
    if (Object.keys(rest).length) await put(`teacher/courses/${enc(id)}`, rest);
    if (status) await post(`teacher/courses/${enc(id)}/status`, { status });
}

/* ---------- Sections (modules) + activities (items) ---------- */
export const loadOutline = (courseId) => get(`teacher/courses/${enc(courseId)}/outline`);

export async function addModule(courseId, title, order) {
    const r = await post(`teacher/courses/${enc(courseId)}/modules`, { title, order });
    return r.id;
}
export const updateModule = (courseId, moduleId, data) => put(`teacher/modules/${enc(moduleId)}`, data);

export async function addItem(courseId, moduleId, data) {
    const r = await post(`teacher/modules/${enc(moduleId)}/items`, data);
    return r.id;
}
export const replaceItem = (courseId, moduleId, itemId, data) => put(`teacher/items/${enc(itemId)}`, data);
export const updateItem = (courseId, moduleId, itemId, data) =>
    put(`teacher/items/${enc(itemId)}/order`, { order: data.order });
export const removeItem = (courseId, moduleId, itemId) => del(`teacher/items/${enc(itemId)}`);
export const removeModule = (courseId, moduleId) => del(`teacher/modules/${enc(moduleId)}`);
export const removeCourse = (courseId) => del(`teacher/courses/${enc(courseId)}`);

/* ---------- Start from the built-in syllabus ---------- */
export const listStarters = () => get("teacher/starters");

export async function createFromSyllabus(user, starter) {
    const c = await post("teacher/courses/from-starter", { starterId: starter.id });
    return c.id;
}

/* Enrolments in the courses I teach: [{ uid, courseId, completed, ... }] */
export const listMyEnrollments = () => get("teacher/enrollments");
