/* Runs before the page paints (teacher pages), so there is no flash of the wrong colours. */
(function () {
    var m = "dark";
    try { m = localStorage.getItem("tl-mode") || document.documentElement.getAttribute("data-mode") || "dark"; } catch (e) { /* ignore */ }
    if (m === "auto") m = matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark";
    document.documentElement.setAttribute("data-mode", m);
})();
