import { get, post } from "./api.js";

/* Published courses, each with moduleTitles and itemCount. For the student pages. */
export async function listPublishedCourses() {
    const cat = await get("student/catalogue");
    return cat.courses;
}

export const listMyCourses = () => get("teacher/courses");

export const setCourseStatus = (courseId, status) => post(`teacher/courses/${encodeURIComponent(courseId)}/status`, { status });
