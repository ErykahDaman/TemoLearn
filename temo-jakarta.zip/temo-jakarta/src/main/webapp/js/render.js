const esc = (s = "") =>
    String(s).replace(/[&<>"']/g, (ch) => (
        { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch]
    ));

/* Tiny, safe markdown: # headings, - bullets, 1. numbers, **bold**, *italic*, [text](https://link) */
export function renderMarkdown(src = "") {
    const inline = (t) => t
        .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
        .replace(/(^|[\s(])\*([^*\s][^*]*?)\*(?=[\s).,!?:;]|$)/g, "$1<em>$2</em>")
        .replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');

    const out = [];
    let list = null;
    const closeList = () => { if (list) { out.push(`</${list}>`); list = null; } };

    esc(src).split(/\r?\n/).forEach((raw) => {
        const line = raw.trim();
        let m;
        if (!line) { closeList(); return; }
        if ((m = line.match(/^(#{1,3})\s+(.*)$/))) {
            closeList();
            const level = m[1].length + 1;                // # -> h2, ## -> h3, ### -> h4
            out.push(`<h${level}>${inline(m[2])}</h${level}>`);
        } else if ((m = line.match(/^[-*]\s+(.*)$/))) {
            if (list !== "ul") { closeList(); out.push("<ul>"); list = "ul"; }
            out.push(`<li>${inline(m[1])}</li>`);
        } else if ((m = line.match(/^\d+\.\s+(.*)$/))) {
            if (list !== "ol") { closeList(); out.push("<ol>"); list = "ol"; }
            out.push(`<li>${inline(m[1])}</li>`);
        } else {
            closeList();
            out.push(`<p>${inline(line)}</p>`);
        }
    });
    closeList();
    return out.join("\n");
}

/* Pull the video id out of the usual YouTube link shapes. */
export function youtubeId(url) {
    try {
        const u = new URL(url);
        const host = u.hostname.replace(/^www\./, "");
        let id = "";
        if (host === "youtu.be") id = u.pathname.slice(1).split("/")[0];
        else if (host === "youtube.com" || host === "m.youtube.com") {
            if (u.pathname === "/watch") id = u.searchParams.get("v") || "";
            else {
                const m = u.pathname.match(/^\/(embed|shorts|live)\/([\w-]+)/);
                if (m) id = m[2];
            }
        }
        return /^[\w-]{6,20}$/.test(id) ? id : "";
    } catch { return ""; }
}