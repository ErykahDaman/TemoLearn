/* The header itself is drawn by the server (portal.tag). This adds the bits that need JavaScript:
   the mobile menu button and, on teacher pages, the light/dark mode. */

/* mode: "dark" | "light" | "auto" (teacher pages only) */
export function applyMode(mode) {
    if (!mode) return;
    try { localStorage.setItem("tl-mode", mode); } catch { /* private window */ }
    const m = mode === "auto"
        ? (matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark")
        : mode;
    document.documentElement.setAttribute("data-mode", m);
}

export function mountPortal({ profile, area } = {}) {
    if (profile && profile.role !== "student" && area !== "admin") applyMode(profile.themeMode);
    const toggle = document.getElementById("navToggle");
    const nav = document.getElementById("navLinks");
    toggle?.addEventListener("click", () => {
        const open = nav.classList.toggle("open");
        toggle.setAttribute("aria-expanded", String(open));
    });
}
