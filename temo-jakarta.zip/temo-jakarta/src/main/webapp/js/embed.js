/* Safe handling of pasted game embeds. */
export function parseEmbed(input) {
    const raw = String(input || "").trim();
    if (!raw) return { error: "Paste the embed code or the game link." };

    let url = raw;
    let height = 0;
    if (raw.startsWith("<")) {
        // DOMParser builds an inert document: nothing in it runs or loads.
        const doc = new DOMParser().parseFromString(raw, "text/html");
        const frame = doc.querySelector("iframe");
        if (!frame) return { error: "Couldn't find an <iframe> in that code." };
        url = (frame.getAttribute("src") || "").trim();
        height = parseInt(frame.getAttribute("height"), 10) || 0;
    }
    if (url.startsWith("//")) url = "https:" + url;

    let u;
    try { u = new URL(url); } catch { return { error: "That doesn't look like a valid link." }; }
    if (u.protocol !== "https:") return { error: "Only secure (https) game links can be used." };
    if (u.origin === location.origin) {
        return { error: "Games hosted on this site can't be added this way. Use an outside link." };
    }
    return { url: u.href, host: u.hostname, height: Math.min(Math.max(height || 560, 300), 1000) };
}

export function makeGameFrame(url, height = 560, title = "Game") {
    const f = document.createElement("iframe");
    f.src = url;
    f.title = title;
    f.height = String(height);
    f.loading = "lazy";
    f.setAttribute("sandbox", "allow-scripts allow-same-origin allow-popups allow-forms allow-pointer-lock");
    f.setAttribute("allow", "fullscreen; autoplay; gamepad");
    f.setAttribute("allowfullscreen", "");
    f.setAttribute("referrerpolicy", "no-referrer");
    return f;
}