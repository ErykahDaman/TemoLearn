import { get, post, del } from "./api.js";

const enc = encodeURIComponent;

/* ---------- Enrolments ---------- */
export const listMyEnrollments = () => get("student/enrollments");

export async function getEnrollment(user, courseId) {
    const all = await listMyEnrollments();
    return all.find((e) => e.courseId === courseId) || null;
}

/* Safe to call twice: an existing enrolment is left exactly as it is, so progress is never reset. */
export const enrolSelf = (user, profile, courseId) => post("student/enroll", { courseId });

/* Everything the dashboard and My Learning need in one call: [{ enr, course, mods }] */
export const loadLearningRows = () => get("student/learning");

/* ---------- Outline (locked sections come back without their activities) ---------- */
export const loadLearnerOutline = (courseId) => get(`student/courses/${enc(courseId)}/outline`);

/* Progress counts the "required" activities if the teacher marked any, otherwise all of them. */
export function courseProgress(enr, mods) {
    const all = mods.flatMap((m) => m.items || []);
    const required = all.filter((i) => i.required);
    const counted = required.length ? required : all;
    const done = new Set((enr && enr.completedItems) || []);
    const d = counted.filter((i) => done.has(i.id)).length;
    const pct = counted.length ? Math.round((d * 100) / counted.length) : 0;
    return {
        pct: enr && enr.completed ? 100 : pct,
        done: d, total: counted.length,
        complete: counted.length > 0 && d === counted.length
    };
}

/* ---------- Progress writes ---------- */
/* Returns { completedItems, completed, justCompleted }: the server decides when a course is complete. */
export const setDone = (user, courseId, itemId, done) =>
    post(`student/courses/${enc(courseId)}/items/${enc(itemId)}/done`, { done });

/* Quizzes are marked on the server, so the answers are never in the browser until you've tried.
   Returns { pct, right, total, passed, correct: [answer index per question], best, ... } */
export const submitQuiz = (user, courseId, itemId, answers) =>
    post(`student/courses/${enc(courseId)}/items/${enc(itemId)}/quiz`, { answers });

export const setLastItem = (user, courseId, moduleId, itemId) =>
    post(`student/courses/${enc(courseId)}/last`, { moduleId, itemId });

/* ---------- Games ---------- */
export const getGame = (id) => get(`common/games/${enc(id)}`);
export const listVisibleGames = () => get("student/games");

/* ---------- Discussions ---------- */
export const listPosts = (courseId, itemId) => get(`common/courses/${enc(courseId)}/items/${enc(itemId)}/posts`);
export const addPost = (user, profile, courseId, itemId, text) =>
    post(`common/courses/${enc(courseId)}/items/${enc(itemId)}/posts`, { text });
export const deletePost = (id) => del(`common/posts/${enc(id)}`);
