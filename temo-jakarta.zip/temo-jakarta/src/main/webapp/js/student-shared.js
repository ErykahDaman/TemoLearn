/* Shared pieces for the student portal pages. */
import { requireRole } from "./auth.js";
import { mountPortal } from "./portal-layout.js";
import { loadLearningRows, courseProgress } from "./student-api.js";

export const esc = (s = "") =>
    String(s).replace(/[&<>"']/g, (ch) => (
        { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch]
    ));

export const plural = (n, word) => `${n} ${word}${n === 1 ? "" : "s"}`;

export async function boot(active) {
    const { user, profile } = await requireRole(["student"]);
    mountPortal({ profile, active });
    return { user, profile };
}

export const ACTIVITY_ICONS = { page: "📄", video: "▶️", link: "🔗", quiz: "❓", discussion: "💬", game: "🎮" };

/* The course thumbnail: uploaded picture if there is one, otherwise the emoji icon. */
export function thumbHTML(c) {
    const img = typeof c.thumbnail === "string" && /^(https:|data:image\/)/.test(c.thumbnail)
        ? `<img src="${esc(c.thumbnail)}" alt="" loading="lazy">`
        : `<span class="course-icon">${esc(c.icon || "📜")}</span>`;
    return `<div class="l-thumb">${img}<span class="hud-chip">${esc(c.category || "General")}</span></div>`;
}

/* Everything the dashboard and My Learning need, loaded in one call:
   [{ enr, course, mods, prog }] for every course the student is enrolled in.
   Courses that were unpublished or removed are left out by the server. */
export async function loadLearning(user) {
    const rows = (await loadLearningRows()).map((r) => ({
        enr: r.enr, course: r.course, mods: r.mods, prog: courseProgress(r.enr, r.mods)
    }));
    const lastActive = (r) => r.enr.lastActive?.seconds || r.enr.startedAt?.seconds || 0;
    return rows.sort((a, b) => lastActive(b) - lastActive(a));
}

/* Badges are worked out from progress, so they can't drift out of sync. */
export function computeBadges(rows, profile) {
    const done = rows.reduce((n, r) => n + ((r.enr.completedItems || []).length), 0);
    const finished = rows.filter((r) => r.prog.pct === 100 || r.enr.completed).length;
    const scores = rows.flatMap((r) => Object.values(r.enr.quizScores || {}));
    const list = [
        { icon: "🌱", name: "Seedling", hint: "Enrol in your first course", on: rows.length > 0 },
        { icon: "🌿", name: "Sprout", hint: "Complete 5 activities", on: done >= 5 },
        { icon: "🌾", name: "Harvest", hint: "Finish a course", on: finished > 0 },
        { icon: "🧠", name: "Sharp mind", hint: "Score 80% or more on a quiz", on: scores.some((s) => s >= 80) },
        { icon: "🏆", name: "Grand harvest", hint: "Finish 3 courses", on: finished >= 3 }
    ];
    (profile.badges || []).forEach((b) => {
        const name = typeof b === "string" ? b : (b && b.name);
        if (name) list.push({ icon: "⭐", name, hint: "Awarded by your teacher", on: true });
    });
    return list;
}

export const badgeHTML = (b) =>
    `<span class="badge${b.on ? "" : " locked"}" title="${esc(b.hint)}">${b.icon} ${esc(b.name)}</span>`;

export function fmtDate(ts) {
    return ts && ts.toDate
        ? ts.toDate().toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" }) : "—";
}
