const esc = (s = "") =>
    String(s).replace(/[&<>"']/g, (ch) => (
        { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch]
    ));

export const AVATARS = [
    { e: "🌱", c: "#3f8a48" }, { e: "🌾", c: "#9D6612" }, { e: "🚜", c: "#6A3E0D" },
    { e: "💧", c: "#4a9fb5" }, { e: "☀️", c: "#c9902a" }, { e: "🐟", c: "#2f7a8a" },
    { e: "🌻", c: "#b8860b" }, { e: "🥬", c: "#2d6a3a" }, { e: "🍅", c: "#b5402f" },
    { e: "🌽", c: "#b28641" }, { e: "🐝", c: "#8a6a12" }, { e: "🦎", c: "#4f7a3a" }
];

/* A round profile picture: uploaded photo, else the chosen avatar, else the first letter. */
export function avatarHTML(p = {}, size = 40) {
    const base = `width:${size}px;height:${size}px;font-size:${Math.round(size * 0.5)}px`;
    if (typeof p.photo === "string" && p.photo.startsWith("data:image/")) {
        return `<span class="avatar" style="${base}"><img src="${esc(p.photo)}" alt=""></span>`;
    }
    const a = AVATARS.find((x) => x.e === p.avatar);
    const letter = (p.fullName || "?").trim().charAt(0).toUpperCase() || "?";
    return `<span class="avatar" style="${base};background:${a ? a.c : "#6A3E0D"}">${esc(a ? a.e : letter)}</span>`;
}