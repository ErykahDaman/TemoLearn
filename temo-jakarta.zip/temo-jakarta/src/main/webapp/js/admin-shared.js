/* Shared helpers for the admin console pages. */
import { requireRole } from "./auth.js";
import { mountPortal } from "./portal-layout.js";

export const esc = (s = "") =>
    String(s).replace(/[&<>"']/g, (ch) => (
        { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch]
    ));

export const plural = (n, word) => `${n} ${word}${n === 1 ? "" : "s"}`;

export async function boot(active) {
    const { user, profile } = await requireRole(["admin"]);
    mountPortal({ profile, active, area: "admin" });
    return { user, profile };
}

export const fmtDate = (ts) => ts && ts.toDate
    ? ts.toDate().toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" }) : "—";

export function ago(ts) {
    if (!ts || !ts.seconds) return "—";
    const s = Math.max(0, Math.floor(Date.now() / 1000) - ts.seconds);
    if (s < 3600) return Math.max(1, Math.floor(s / 60)) + " min ago";
    if (s < 86400) return Math.floor(s / 3600) + " h ago";
    if (s < 86400 * 30) return Math.floor(s / 86400) + " d ago";
    return fmtDate(ts);
}

export const ROLE_LABEL = { student: "Student", teacher: "Teacher", admin: "Admin" };
export const roleChip = (r) => `<span class="status-chip role-${esc(r)}">${esc(ROLE_LABEL[r] || r || "—")}</span>`;

/* Count rows by a key: { key: n } */
export function tally(list, keyFn) {
    const out = {};
    list.forEach((x) => { const k = keyFn(x); out[k] = (out[k] || 0) + 1; });
    return out;
}

export const hostOf = (u) => { try { return new URL(u).hostname; } catch { return ""; } };

export function authMessage(err) {
    return ({
        "auth/email-already-in-use": "That email already has an account.",
        "auth/invalid-email": "That email doesn't look right.",
        "auth/weak-password": "The password must be at least 8 characters.",
        "permission-denied": "You don't have permission to do that."
    })[err && err.code] || (err && err.message) || "Something went wrong. Please try again.";
}
