import { boot, esc, ago, roleChip, authMessage } from "../admin-shared.js";
import { listAllFeedback, saveFeedbackReply } from "../admin-api.js";
import { toast } from "../ui.js";

const { user: me } = await boot("Feedback");
const app = document.getElementById("app");
const seg = document.getElementById("seg");
const search = document.getElementById("q");

let items = [];
let filter = "new";
const st = (f) => f.status || "new";
const STATUS = { new: ["New", "draft"], open: ["In progress", "warn"], resolved: ["Resolved", "published"] };

try { items = await listAllFeedback(); }
catch (err) {
    console.error(err);
    app.innerHTML = `<div class="panel-dark portal-card empty">Couldn't load feedback. Please refresh and try again.</div>`;
    throw err;
}
if (!items.some((f) => st(f) === "new")) filter = "all";

function render() {
    const n = (s) => items.filter((f) => st(f) === s).length;
    seg.innerHTML = [["new", "New", n("new")], ["open", "In progress", n("open")], ["resolved", "Resolved", n("resolved")], ["all", "All", items.length]]
        .map(([id, label, c]) => `<button type="button" data-f="${id}" class="${id === filter ? "on" : ""}">${label} ${c}</button>`).join("");

    const term = search.value.trim().toLowerCase();
    const list = items.filter((f) =>
        (filter === "all" || st(f) === filter) &&
        (!term || `${f.subject} ${f.message} ${f.name} ${f.email}`.toLowerCase().includes(term)));

    if (!list.length) {
        app.innerHTML = `<div class="panel-dark portal-card empty">${items.length ? "Nothing in this view." : "No feedback has been sent yet."}</div>`;
        return;
    }
    app.innerHTML = list.map((f) => {
        const [label, cls] = STATUS[st(f)] || STATUS.new;
        return `<article class="panel-dark fb-card" data-id="${esc(f.id)}">
          <div class="fb-head">
            <div><h3>${esc(f.subject || "(no subject)")}</h3>
              <span class="item-meta">${esc(f.type || "Message")} · ${esc(f.name || "Unknown")} · ${esc(f.email || "")} · ${esc(ago(f.createdAt))}</span></div>
            <div class="btn-row">${f.role ? roleChip(f.role) : ""}<span class="status-chip ${cls}">${label}</span></div>
          </div>
          <div class="fb-msg">${esc(f.message)}</div>
          ${f.reply ? `<div class="fb-prev"><strong>Your reply:</strong> ${esc(f.reply)}</div>` : ""}
          <form class="fb-reply-form" style="margin-top:14px">
            <textarea name="reply" maxlength="2000" placeholder="Write a reply. The sender sees it under Help &amp; feedback." aria-label="Reply">${esc(f.reply || "")}</textarea>
            <div class="btn-row">
              <select class="a-select sm" name="status" aria-label="Status">
                ${Object.entries(STATUS).map(([v, [l]]) => `<option value="${v}"${v === st(f) ? " selected" : ""}>${l}</option>`).join("")}
              </select>
              <button class="btn btn-gold btn-sm" type="submit">${f.reply ? "Update reply" : "Save"}</button>
            </div>
          </form>
        </article>`;
    }).join("");
}

app.addEventListener("submit", async (e) => {
    e.preventDefault();
    const card = e.target.closest(".fb-card");
    const f = items.find((x) => x.id === card.dataset.id);
    const reply = e.target.reply.value.trim();
    let status = e.target.status.value;
    // Sending a reply to something still marked "new" moves it along on its own.
    if (reply && reply !== (f.reply || "") && status === "new") status = "open";
    const btn = e.target.querySelector("button");
    btn.disabled = true;
    try {
        await saveFeedbackReply(f.id, me.uid, { status, reply });
        f.status = status; f.reply = reply;
        toast(reply ? "Reply saved." : "Status updated.");
    } catch (err) { console.error(err); toast(authMessage(err), true); }
    render();
});

seg.addEventListener("click", (e) => {
    const b = e.target.closest("[data-f]");
    if (b) { filter = b.dataset.f; render(); }
});
search.addEventListener("input", render);

render();
