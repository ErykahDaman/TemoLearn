import { requireRole } from "../auth.js";
import { mountPortal } from "../portal-layout.js";
import { listMyGames, saveGame, deleteGameDoc } from "../teacher-tools.js";
import { parseEmbed, makeGameFrame } from "../embed.js";
import { GAMES } from "../games-data.js";
import { esc } from "../util.js";
import { openModal, toast } from "../ui.js";

const { user, profile } = await requireRole(["teacher", "admin"]);
mountPortal({ profile, active: "My Games" });

const mineEl = document.getElementById("mine");
let games = [];

document.getElementById("builtin").innerHTML = GAMES.map((g) => `
    <div class="builtin">
      <span class="num">${g.course}</span>
      <span>${esc(g.name)}</span>
      <span class="status-chip draft">Planned</span>
    </div>`).join("");

const hostOf = (u) => { try { return new URL(u).hostname; } catch { return ""; } };

function cardHTML(g) {
  return `
      <article class="panel-dark game-card" data-id="${esc(g.id)}">
        <div class="game-top">
          <span class="game-icon">🎮</span>
          <div><h3>${esc(g.title)}</h3><span class="item-meta">${esc(hostOf(g.embedUrl))}</span></div>
        </div>
        <p>${esc(g.description || "No description yet.")}</p>
        <div><span class="status-chip ${g.visible ? "published" : "draft"}">${g.visible ? "Visible to learners" : "Hidden"}</span></div>
        <div class="btn-row">
          <button class="btn btn-gold btn-sm" data-act="play" type="button">▶ Play</button>
          <button class="btn btn-ghost btn-sm" data-act="edit" type="button">Edit</button>
          <button class="btn btn-ghost btn-sm" data-act="del" type="button">Delete</button>
        </div>
      </article>`;
}

function render() {
  if (!games.length) {
    mineEl.innerHTML = `
        <div class="panel-dark portal-card empty">
          <p>You haven't added a game yet.</p>
          <button class="btn btn-gold" id="emptyAdd" type="button">＋ Add your first game</button>
        </div>`;
    document.getElementById("emptyAdd").onclick = () => openGameModal(null);
    return;
  }
  mineEl.innerHTML = `<div class="game-grid">${games.map(cardHTML).join("")}</div>`;
}

async function load() {
  try {
    games = await listMyGames(user);
    render();
  } catch (err) {
    console.error(err);
    mineEl.innerHTML = `<div class="panel-dark portal-card empty"><p>Couldn't load your games. Please refresh and try again.</p></div>`;
  }
}

function playGame(g) {
  const m = openModal(`
      <h2>${esc(g.title)}</h2>
      ${g.instructions ? `<p>${esc(g.instructions)}</p>` : ""}
      <div class="embed-wrap" id="slot"></div>
      <p class="hint">If nothing loads, the game's website may not allow embedding. Check its sharing settings.</p>`, { wide: true });
  m.$("#slot").appendChild(makeGameFrame(g.embedUrl, g.height || 560, g.title));
}

function openGameModal(game) {
  const isEdit = !!game;
  let heightTouched = isEdit;
  const m = openModal(`
      <h2>${isEdit ? "Edit game" : "Add a game"}</h2>
      <form id="gf">
        <div class="field"><label for="g-title">Game title</label>
          <input id="g-title" maxlength="120" required value="${esc(game ? game.title : "")}"></div>
        <div class="field"><label for="g-desc">Short description</label>
          <input id="g-desc" maxlength="200" value="${esc(game ? game.description : "")}"></div>
        <div class="field"><label for="g-embed">Embed code or game link</label>
          <textarea id="g-embed" rows="4" placeholder="Paste the &lt;iframe ...&gt; code, or just the https link">${esc(game ? game.embedUrl : "")}</textarea>
          <p class="hint">Look for a "Share" or "Embed" button on the game's page. We only use the link inside the code.</p>
          <p class="detected" id="g-detect"></p></div>
        <div class="grid-2">
          <div class="field"><label for="g-height">Frame height (px)</label>
            <input id="g-height" type="number" min="300" max="1000" value="${esc(game && game.height ? game.height : 560)}"></div>
        </div>
        <div class="field"><label for="g-inst">Instructions for learners (optional)</label>
          <textarea id="g-inst" rows="3">${esc(game ? game.instructions : "")}</textarea></div>
        <label class="check-row"><input type="checkbox" id="g-visible"${!game || game.visible ? " checked" : ""}> Visible to learners</label>
        <p class="form-msg" id="g-msg"></p>
        <div class="modal-actions">
          <button class="btn btn-gold" id="g-save">${isEdit ? "Save changes" : "Add game"}</button>
          <button class="btn btn-ghost" data-x type="button">Cancel</button>
        </div>
      </form>`, { wide: true });

  const detect = () => {
    const r = parseEmbed(m.$("#g-embed").value);
    const el = m.$("#g-detect");
    if (!m.$("#g-embed").value.trim()) { el.textContent = ""; el.className = "detected"; return r; }
    if (r.error) { el.textContent = r.error; el.className = "detected bad"; }
    else {
      el.textContent = "✓ Found: " + r.url;
      el.className = "detected";
      if (!heightTouched) m.$("#g-height").value = r.height;
    }
    return r;
  };
  m.$("#g-embed").addEventListener("input", detect);
  m.$("#g-height").addEventListener("input", () => { heightTouched = true; });
  if (isEdit) detect();

  m.$("#gf").addEventListener("submit", async (e) => {
    e.preventDefault();
    const say = (t) => { m.$("#g-msg").className = "form-msg error"; m.$("#g-msg").textContent = t; };
    const r = parseEmbed(m.$("#g-embed").value);
    if (r.error) return say(r.error);
    const title = m.$("#g-title").value.trim();
    if (!title) return say("Give the game a title.");

    const btn = m.$("#g-save");
    btn.disabled = true;
    try {
      await saveGame(user, game ? game.id : null, {
        title,
        description: m.$("#g-desc").value.trim(),
        embedUrl: r.url,
        height: Math.min(1000, Math.max(300, Number(m.$("#g-height").value) || r.height)),
        instructions: m.$("#g-inst").value.trim(),
        visible: m.$("#g-visible").checked
      });
      m.close();
      await load();
      toast(isEdit ? "Game updated." : "Game added. You can now attach it to a course.");
    } catch (err) {
      console.error(err);
      btn.disabled = false;
      say("Couldn't save the game. Please try again.");
    }
  });
}

mineEl.addEventListener("click", async (e) => {
  const btn = e.target.closest("button[data-act]");
  if (!btn) return;
  const g = games.find((x) => x.id === btn.closest(".game-card").dataset.id);
  if (!g) return;
  if (btn.dataset.act === "play") return playGame(g);
  if (btn.dataset.act === "edit") return openGameModal(g);
  if (btn.dataset.act === "del") {
    if (!confirm(`Delete "${g.title}"? Courses that use it will show the game as unavailable.`)) return;
    try {
      await deleteGameDoc(g.id);
      games = games.filter((x) => x.id !== g.id);
      render();
      toast("Game deleted.");
    } catch (err) {
      console.error(err);
      toast("Couldn't delete that game.", true);
    }
  }
});

document.getElementById("addBtn").onclick = () => openGameModal(null);
await load();
