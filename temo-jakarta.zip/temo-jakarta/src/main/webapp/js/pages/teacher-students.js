import { requireRole } from "../auth.js";
import { mountPortal } from "../portal-layout.js";
import { listMyCourses } from "../courses.js";
import { loadOutline } from "../teacher-api.js";
import { listAllStudents, listEnrollments, enrolStudent, unenrolStudent } from "../teacher-tools.js";
import { avatarHTML } from "../avatar.js";
import { esc } from "../util.js";
import { openModal, toast } from "../ui.js";

const { user, profile } = await requireRole(["teacher", "admin"]);
mountPortal({ profile, active: "My Students" });

const app = document.getElementById("app");
let courses = [];
let courseId = "";
let enrollments = [];
let students = [];
let studentMap = new Map();
let studentsError = false;
let itemIds = new Set();

const byName = (a, b) => (a.fullName || "").localeCompare(b.fullName || "");
const fmtDate = (ts) => ts && ts.toDate
    ? ts.toDate().toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" }) : "—";
const course = () => courses.find((c) => c.id === courseId);

function progressOf(e) {
    if (e.completed) return 100;
    const total = itemIds.size;
    if (!total) return 0;
    const done = (e.completedItems || []).filter((id) => itemIds.has(id)).length;
    return Math.min(100, Math.round((done * 100) / total));
}

function who(e) {
    const s = studentMap.get(e.uid);
    return {
        name: (s && s.fullName) || e.studentName || "Unknown student",
        email: (s && s.email) || e.studentEmail || "",
        photo: s ? s.photo : "", avatar: s ? s.avatar : ""
    };
}

function render() {
    const c = course();
    const rows = enrollments
        .map((e) => ({ e, w: who(e), pct: progressOf(e) }))
        .sort((a, b) => a.w.name.localeCompare(b.w.name));
    const completed = rows.filter((r) => r.e.completed || r.pct === 100).length;
    const avg = rows.length ? Math.round(rows.reduce((n, r) => n + r.pct, 0) / rows.length) : 0;

    const table = rows.length ? `
    <div class="table-wrap">
      <table class="tbl">
        <thead><tr><th>Student</th><th>Enrolled</th><th>Progress</th><th>Status</th><th></th></tr></thead>
        <tbody>
          ${rows.map(({ e, w, pct }) => `
            <tr>
              <td><div class="stu">${avatarHTML({ fullName: w.name, photo: w.photo, avatar: w.avatar }, 38)}
                <div><strong>${esc(w.name)}</strong><span class="mail">${esc(w.email)}</span></div></div></td>
              <td>${esc(fmtDate(e.startedAt))}</td>
              <td><div class="prog"><div class="progress"><span style="width:${pct}%"></span></div><span class="pct">${pct}%</span></div></td>
              <td><span class="status-chip ${pct === 100 ? "published" : "draft"}">${pct === 100 ? "Completed" : "In progress"}</span></td>
              <td><button class="btn btn-ghost btn-sm" data-remove="${esc(e.uid)}" type="button">Remove</button></td>
            </tr>`).join("")}
        </tbody>
      </table>
    </div>`
        : `<div class="empty"><p>No students are enrolled in this course yet.</p>
         <button class="btn btn-gold" data-act="enrol" type="button">＋ Enrol students</button></div>`;

    app.innerHTML = `
    <div class="toolbar">
      <select class="select" id="courseSel" aria-label="Choose a course">
        ${courses.map((x) => `<option value="${esc(x.id)}"${x.id === courseId ? " selected" : ""}>${esc(x.title)}</option>`).join("")}
      </select>
      <span class="status-chip ${c.status === "published" ? "published" : "draft"}">${c.status === "published" ? "Published" : "Draft"}</span>
      <span class="spacer"></span>
      <button class="btn btn-ghost btn-sm" data-act="csv" type="button"${rows.length ? "" : " disabled"}>⬇ Download CSV</button>
      <button class="btn btn-gold" data-act="enrol" type="button">＋ Enrol students</button>
    </div>
    ${c.status === "published" ? "" : `<div class="notice">This course is still a draft, so enrolled students can't open it until you publish it.</div>`}
    <div class="mini-stats">
      <div class="panel-dark stat"><div class="num">${rows.length}</div><div class="lbl">Enrolled</div></div>
      <div class="panel-dark stat"><div class="num">${completed}</div><div class="lbl">Completed</div></div>
      <div class="panel-dark stat"><div class="num">${avg}%</div><div class="lbl">Average progress</div></div>
    </div>
    <div class="panel-dark portal-card">${table}</div>`;
}

async function loadCourse() {
    try {
        const [enr, outline] = await Promise.all([listEnrollments(courseId), loadOutline(courseId)]);
        enrollments = enr;
        itemIds = new Set(outline.flatMap((m) => (m.items || []).map((i) => i.id)));
        render();
    } catch (err) {
        console.error(err);
        app.innerHTML = `<div class="panel-dark portal-card empty"><p>Couldn't load this course's students. Please refresh and try again.</p></div>`;
    }
}

/* ---------- Enrol popup ---------- */
function openEnrol() {
    const enrolled = new Set(enrollments.map((e) => e.uid));
    const available = students.filter((s) => !enrolled.has(s.uid)).sort(byName);
    const picked = new Set();

    const m = openModal(`
    <h2>Enrol students</h2>
    <p class="hint">Students need to have signed up first. Tick the ones to add, or paste emails below.</p>
    <input class="search" id="en-q" placeholder="Search by name or email">
    <div class="pick-list" id="en-list"></div>
    <div class="field"><label for="en-emails">Or paste emails (one per line, or separated by commas)</label>
      <textarea id="en-emails" rows="3"></textarea></div>
    <p class="form-msg" id="en-msg"></p>
    <div class="modal-actions">
      <button class="btn btn-gold" id="en-go" type="button">Enrol</button>
      <button class="btn btn-ghost" data-x type="button">Cancel</button>
    </div>`, { wide: true });

    const list = m.$("#en-list");
    const say = (t) => { m.$("#en-msg").className = "form-msg error"; m.$("#en-msg").textContent = t; };

    function drawList() {
        const q = m.$("#en-q").value.trim().toLowerCase();
        const shown = available.filter((s) =>
            !q || (s.fullName || "").toLowerCase().includes(q) || (s.email || "").toLowerCase().includes(q));
        if (studentsError) {
            list.innerHTML = `<p class="hint">Couldn't load the student list. Please refresh, or paste emails below.</p>`;
            return;
        }
        list.innerHTML = shown.length ? shown.map((s) => `
      <label class="pick">
        <input type="checkbox" data-uid="${esc(s.uid)}"${picked.has(s.uid) ? " checked" : ""}>
        ${avatarHTML(s, 34)}
        <span><strong>${esc(s.fullName || "Unnamed")}</strong><span class="mail">${esc(s.email || "")}</span></span>
      </label>`).join("") : `<p class="hint">No students to show.</p>`;
    }
    drawList();
    m.$("#en-q").addEventListener("input", drawList);
    list.addEventListener("change", (e) => {
        const uid = e.target.dataset.uid;
        if (!uid) return;
        e.target.checked ? picked.add(uid) : picked.delete(uid);
    });

    m.$("#en-go").addEventListener("click", async () => {
        const typed = m.$("#en-emails").value.split(/[\s,;]+/).map((s) => s.trim().toLowerCase()).filter(Boolean);
        const byEmail = new Map(students.map((s) => [(s.email || "").toLowerCase(), s]));
        const toAdd = new Map();
        const missing = [];
        picked.forEach((uid) => { const s = studentMap.get(uid); if (s) toAdd.set(uid, s); });
        typed.forEach((em) => {
            const s = byEmail.get(em);
            if (!s) missing.push(em);
            else if (!enrolled.has(s.uid)) toAdd.set(s.uid, s);
        });
        if (!toAdd.size) {
            return say(missing.length
                ? `No matching students. They need to sign up first: ${missing.join(", ")}`
                : "Pick at least one student, or paste an email.");
        }

        const btn = m.$("#en-go");
        btn.disabled = true;
        btn.textContent = "Enrolling...";
        const results = await Promise.allSettled([...toAdd.values()].map((s) => enrolStudent(user, courseId, s)));
        const ok = results.filter((r) => r.status === "fulfilled").length;
        const failed = results.length - ok;
        m.close();
        await loadCourse();
        let msg = `Enrolled ${ok} student${ok === 1 ? "" : "s"}.`;
        if (missing.length) msg += ` Not found: ${missing.join(", ")}.`;
        toast(msg + (failed ? ` ${failed} failed.` : ""), failed > 0);
    });
}

/* ---------- CSV ---------- */
function downloadCsv() {
    const c = course();
    const cell = (v) => `"${String(v ?? "").replace(/"/g, '""')}"`;
    const lines = [["Name", "Email", "Enrolled", "Progress %", "Status"].map(cell).join(",")];
    enrollments.forEach((e) => {
        const w = who(e);
        const pct = progressOf(e);
        lines.push([w.name, w.email, fmtDate(e.startedAt), pct, pct === 100 ? "Completed" : "In progress"].map(cell).join(","));
    });
    const blob = new Blob([lines.join("\n")], { type: "text/csv;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = (c.title || "students").replace(/[^a-z0-9]+/gi, "-").toLowerCase() + "-students.csv";
    a.click();
    URL.revokeObjectURL(a.href);
}

/* ---------- Events ---------- */
app.addEventListener("change", (e) => {
    if (e.target.id !== "courseSel") return;
    courseId = e.target.value;
    history.replaceState(null, "", "?course=" + encodeURIComponent(courseId));
    loadCourse();
});

app.addEventListener("click", async (e) => {
    const act = e.target.closest("[data-act]");
    if (act && act.dataset.act === "enrol") return openEnrol();
    if (act && act.dataset.act === "csv") return downloadCsv();

    const rm = e.target.closest("[data-remove]");
    if (!rm) return;
    const uid = rm.dataset.remove;
    const w = who(enrollments.find((x) => x.uid === uid) || { uid });
    if (!confirm(`Remove ${w.name} from this course? Their progress will be deleted.`)) return;
    rm.disabled = true;
    try {
        await unenrolStudent(uid, courseId);
        enrollments = enrollments.filter((x) => x.uid !== uid);
        render();
        toast("Student removed.");
    } catch (err) {
        console.error(err);
        rm.disabled = false;
        toast("Couldn't remove that student.", true);
    }
});

/* ---------- Start ---------- */
try {
    courses = await listMyCourses(user);
} catch (err) {
    console.error(err);
    app.innerHTML = `<div class="panel-dark portal-card empty"><p>Couldn't load your courses. Check your connection and refresh.</p></div>`;
    throw err;
}

if (!courses.length) {
    app.innerHTML = `
    <div class="panel-dark portal-card empty">
      <p>Create a course first, then you can enrol students in it.</p>
      <a class="btn btn-gold" href="portal/teacher/courses?new=1">＋ New course</a>
    </div>`;
} else {
    courses.sort((a, b) => (a.title || "").localeCompare(b.title || ""));
    const wanted = new URLSearchParams(location.search).get("course");
    courseId = courses.some((c) => c.id === wanted) ? wanted : courses[0].id;

    listAllStudents()
        .then((list) => { students = list; studentMap = new Map(list.map((s) => [s.uid, s])); render(); })
        .catch((err) => { console.warn("Could not load students", err); studentsError = true; });

    await loadCourse();
}
