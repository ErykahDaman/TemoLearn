import { boot, esc } from "../student-shared.js";
import { listVisibleGames } from "../student-api.js";
import { makeGameFrame } from "../embed.js";
import { GAMES } from "../games-data.js";
import { openModal } from "../ui.js";

await boot("Games");
const slot = document.getElementById("playable");
let games = [];

document.getElementById("builtin").innerHTML = GAMES.map((g) => `
  <div class="panel-dark game-card soon">
    <div class="game-top"><span class="game-icon">🎮</span>
      <div><h3>${esc(g.name)}</h3><span class="item-meta">Course ${g.course}</span></div></div>
    <div><span class="status-chip draft">Coming soon</span></div>
  </div>`).join("");

const hostOf = (u) => { try { return new URL(u).hostname; } catch { return ""; } };

function render() {
    if (!games.length) {
        slot.innerHTML = `<div class="panel-dark portal-card empty"><p>No games are available yet. Your teachers will add some soon.</p></div>`;
        return;
    }
    slot.innerHTML = `<div class="game-grid">${games.map((g) => `
      <article class="panel-dark game-card" data-id="${esc(g.id)}">
        <div class="game-top"><span class="game-icon">🎮</span>
          <div><h3>${esc(g.title)}</h3><span class="item-meta">${esc(hostOf(g.embedUrl))}</span></div></div>
        <p>${esc(g.description || "Jump in and play.")}</p>
        ${g.authorName ? `<span class="hint">By ${esc(g.authorName)}</span>` : ""}
        <div class="btn-row"><button class="btn btn-gold btn-sm" data-play type="button">▶ Play</button></div>
      </article>`).join("")}</div>`;
}

slot.addEventListener("click", (e) => {
    const b = e.target.closest("[data-play]");
    if (!b) return;
    const g = games.find((x) => x.id === b.closest(".game-card").dataset.id);
    if (!g) return;
    const m = openModal(`
      <h2>${esc(g.title)}</h2>
      ${g.instructions ? `<p>${esc(g.instructions)}</p>` : ""}
      <div class="embed-wrap" id="frame"></div>
      <p class="hint">If nothing loads, the game's website may not allow embedding.</p>`, { wide: true });
    m.$("#frame").appendChild(makeGameFrame(g.embedUrl, g.height || 560, g.title));
});

try { games = await listVisibleGames(); render(); }
catch (err) {
    console.error(err);
    slot.innerHTML = `<div class="panel-dark portal-card empty"><p>Couldn't load the games. Refresh to try again.</p></div>`;
}
