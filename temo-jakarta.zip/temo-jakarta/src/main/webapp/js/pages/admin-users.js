import { boot, esc, roleChip, fmtDate, tally, authMessage, ROLE_LABEL } from "../admin-shared.js";
import { listUsers, listAllEnrollments, listAllCourses, setUserRole, setUserDisabled, createTeacher } from "../admin-api.js";
import { avatarHTML } from "../avatar.js";
import { openModal, toast } from "../ui.js";

const { user: me } = await boot("Users");
const app = document.getElementById("app");
const roleSeg = document.getElementById("roleSeg");
const search = document.getElementById("q");

let users = [], enrolCount = {}, authored = {};
let roleFilter = "all";

async function load() {
    try {
        const [u, e, c] = await Promise.all([listUsers(), listAllEnrollments().catch(() => []), listAllCourses().catch(() => [])]);
        users = u;
        enrolCount = tally(e, (x) => x.uid);
        authored = tally(c, (x) => x.authorId);
        render();
    } catch (err) {
        console.error(err);
        app.innerHTML = `<p class="empty">Couldn't load users. Please refresh and try again.</p>`;
    }
}

function render() {
    const counts = tally(users, (u) => u.role || "student");
    roleSeg.innerHTML = [["all", "All", users.length], ["student", "Students", counts.student || 0],
        ["teacher", "Teachers", counts.teacher || 0], ["admin", "Admins", counts.admin || 0]]
        .map(([id, label, n]) => `<button type="button" data-role="${id}" class="${id === roleFilter ? "on" : ""}">${label} ${n}</button>`).join("");

    const term = search.value.trim().toLowerCase();
    const list = users.filter((u) =>
        (roleFilter === "all" || (u.role || "student") === roleFilter) &&
        (!term || `${u.fullName || ""} ${u.email || ""}`.toLowerCase().includes(term)));

    if (!list.length) { app.innerHTML = `<p class="empty">No users match.</p>`; return; }

    app.innerHTML = `<table class="tbl"><thead><tr>
      <th>User</th><th>Role</th><th>Joined</th><th>Activity</th><th>Status</th><th></th></tr></thead><tbody>
      ${list.map((u) => {
          const self = u.uid === me.uid;
          const role = u.role || "student";
          const activity = role === "teacher" ? `${authored[u.uid] || 0} courses`
              : role === "student" ? `${enrolCount[u.uid] || 0} enrolled` : "—";
          return `<tr class="${u.disabled ? "off" : ""}" data-uid="${esc(u.uid)}">
            <td><div class="person">${avatarHTML(u, 38)}<div><strong>${esc(u.fullName || "Unnamed")}${self ? " (you)" : ""}</strong><span class="mail">${esc(u.email || "")}</span></div></div></td>
            <td><select class="a-select sm" data-act="role" aria-label="Role for ${esc(u.fullName || "user")}"${self ? " disabled title=\"You can't change your own role\"" : ""}>
              ${["student", "teacher", "admin"].map((r) => `<option value="${r}"${r === role ? " selected" : ""}>${ROLE_LABEL[r]}</option>`).join("")}</select></td>
            <td class="num">${esc(fmtDate(u.createdAt))}</td>
            <td class="num">${esc(activity)}</td>
            <td>${u.disabled ? `<span class="status-chip bad">Disabled</span>` : `<span class="status-chip ok">Active</span>`}</td>
            <td><div class="acts">${self ? "" : `<button class="btn btn-ghost btn-sm${u.disabled ? "" : " danger"}" data-act="toggle" type="button">${u.disabled ? "Enable" : "Disable"}</button>`}</div></td>
          </tr>`;
      }).join("")}</tbody></table>`;
}

app.addEventListener("change", async (e) => {
    const sel = e.target.closest('[data-act="role"]');
    if (!sel) return;
    const u = users.find((x) => x.uid === sel.closest("tr").dataset.uid);
    const next = sel.value;
    if (!u || next === (u.role || "student")) return;
    if (!confirm(`Change ${u.fullName || u.email} from ${ROLE_LABEL[u.role || "student"]} to ${ROLE_LABEL[next]}?`)) { sel.value = u.role || "student"; return; }
    sel.disabled = true;
    try { await setUserRole(u.uid, next); u.role = next; toast("Role updated."); }
    catch (err) { console.error(err); toast(authMessage(err), true); }
    render();
});

app.addEventListener("click", async (e) => {
    const b = e.target.closest('[data-act="toggle"]');
    if (!b) return;
    const u = users.find((x) => x.uid === b.closest("tr").dataset.uid);
    if (!u) return;
    const to = !u.disabled;
    if (to && !confirm(`Disable ${u.fullName || u.email}? They will be signed out and can't log in.`)) return;
    b.disabled = true;
    try { await setUserDisabled(u.uid, to); u.disabled = to; toast(to ? "Account disabled." : "Account enabled."); }
    catch (err) { console.error(err); toast(authMessage(err), true); }
    render();
});

roleSeg.addEventListener("click", (e) => {
    const b = e.target.closest("[data-role]");
    if (b) { roleFilter = b.dataset.role; render(); }
});
search.addEventListener("input", render);

function openCreate() {
    const m = openModal(`
      <h2>Create a teacher account</h2>
      <p class="muted" style="margin-top:0">They can log in straight away. Share the temporary password with them and ask them to change it under Profile → Security.</p>
      <form id="tf">
        <div class="field"><label for="t-name">Full name</label><input id="t-name" maxlength="100" required></div>
        <div class="grid-2">
          <div class="field"><label for="t-email">Email</label><input id="t-email" type="email" autocomplete="off" required></div>
          <div class="field"><label for="t-title">Job title (optional)</label><input id="t-title" maxlength="80" placeholder="e.g. Lecturer"></div>
        </div>
        <div class="field"><label for="t-pw">Temporary password</label><input id="t-pw" type="text" minlength="6" autocomplete="off" required>
          <p class="hint">At least 6 characters.</p></div>
        <p class="form-msg" id="t-msg"></p>
        <div class="modal-actions">
          <button class="btn btn-gold" id="t-save">Create teacher</button>
          <button class="btn btn-ghost" data-x type="button">Cancel</button>
        </div>
      </form>`);
    m.$("#tf").addEventListener("submit", async (e) => {
        e.preventDefault();
        const msg = m.$("#t-msg"), btn = m.$("#t-save");
        btn.disabled = true; msg.textContent = "";
        try {
            await createTeacher({
                fullName: m.$("#t-name").value.trim(), email: m.$("#t-email").value.trim(),
                password: m.$("#t-pw").value, title: m.$("#t-title").value.trim()
            });
            m.close();
            toast("Teacher account created.");
            await load();
        } catch (err) {
            console.error(err);
            msg.className = "form-msg error"; msg.textContent = authMessage(err);
            btn.disabled = false;
        }
    });
}
document.getElementById("newTeacher").onclick = openCreate;

await load();
if (new URLSearchParams(location.search).get("new") === "teacher") openCreate();
