import { boot, esc, tally, hostOf, authMessage } from "../admin-shared.js";
import { listAllCourses, listAllGames, listAllEnrollments, setCourseStatus, deleteCourse, setGameVisible, deleteGame } from "../admin-api.js";
import { makeGameFrame } from "../embed.js";
import { openModal, toast } from "../ui.js";

await boot("Content");
const app = document.getElementById("app");
const tabsEl = document.getElementById("tabs");
const search = document.getElementById("q");

let courses = [], games = [], enrols = [];
let tab = location.hash === "#games" ? "games" : "courses";

try {
    const [c, g, e] = await Promise.all([listAllCourses(), listAllGames(), listAllEnrollments().catch(() => [])]);
    courses = c; games = g; enrols = e;
} catch (err) {
    console.error(err);
    app.innerHTML = `<p class="empty">Couldn't load content. Please refresh and try again.</p>`;
    throw err;
}

function render() {
    tabsEl.innerHTML = [["courses", `Courses (${courses.length})`], ["games", `Games (${games.length})`]]
        .map(([id, label]) => `<button class="tab${id === tab ? " active" : ""}" data-tab="${id}" type="button">${label}</button>`).join("");
    search.placeholder = tab === "courses" ? "Search courses by title, category or teacher…" : "Search games…";
    const term = search.value.trim().toLowerCase();
    (tab === "courses" ? renderCourses : renderGames)(term);
}

function renderCourses(term) {
    const learners = tally(enrols, (e) => e.courseId);
    const finished = tally(enrols.filter((e) => e.completed), (e) => e.courseId);
    const list = courses.filter((c) => !term || `${c.title} ${c.category} ${c.authorName}`.toLowerCase().includes(term));
    if (!list.length) { app.innerHTML = `<p class="empty">${courses.length ? "No courses match." : "No courses have been created yet."}</p>`; return; }
    app.innerHTML = `<table class="tbl"><thead><tr><th>Course</th><th>Teacher</th><th>Status</th><th>Learners</th><th>Finished</th><th></th></tr></thead><tbody>
      ${list.map((c) => {
          const pub = c.status === "published";
          return `<tr data-id="${esc(c.id)}">
            <td><div class="title-cell"><span class="ico">${esc(c.icon || "📜")}</span><div><strong>${esc(c.title)}</strong><br><span class="item-meta">${esc(c.category || "General")}</span></div></div></td>
            <td>${esc(c.authorName || "—")}</td>
            <td><span class="status-chip ${pub ? "published" : "draft"}">${pub ? "Published" : "Draft"}</span></td>
            <td class="num">${learners[c.id] || 0}</td><td class="num">${finished[c.id] || 0}</td>
            <td><div class="acts">
              <button class="btn btn-ghost btn-sm" data-act="${pub ? "unpublish" : "publish"}" type="button">${pub ? "Unpublish" : "Publish"}</button>
              <button class="btn btn-ghost btn-sm danger" data-act="del-course" type="button">Delete</button>
            </div></td></tr>`;
      }).join("")}</tbody></table>`;
}

function renderGames(term) {
    const list = games.filter((g) => !term || `${g.title} ${g.authorName} ${g.description}`.toLowerCase().includes(term));
    if (!list.length) { app.innerHTML = `<p class="empty">${games.length ? "No games match." : "No teacher has added a game yet."}</p>`; return; }
    app.innerHTML = `<table class="tbl"><thead><tr><th>Game</th><th>Teacher</th><th>Source</th><th>Visibility</th><th></th></tr></thead><tbody>
      ${list.map((g) => `<tr data-id="${esc(g.id)}">
        <td><div class="title-cell"><span class="ico">🎮</span><div><strong>${esc(g.title)}</strong><br><span class="item-meta">${esc(g.description || "No description")}</span></div></div></td>
        <td>${esc(g.authorName || "—")}</td>
        <td class="num">${esc(hostOf(g.embedUrl))}</td>
        <td><span class="status-chip ${g.visible ? "published" : "draft"}">${g.visible ? "Visible" : "Hidden"}</span></td>
        <td><div class="acts">
          <button class="btn btn-ghost btn-sm" data-act="preview" type="button">▶ Preview</button>
          <button class="btn btn-ghost btn-sm" data-act="${g.visible ? "hide" : "show"}" type="button">${g.visible ? "Hide" : "Show"}</button>
          <button class="btn btn-ghost btn-sm danger" data-act="del-game" type="button">Delete</button>
        </div></td></tr>`).join("")}</tbody></table>`;
}

async function run(btn, job, okMsg) {
    btn.disabled = true;
    try { await job(); toast(okMsg); }
    catch (err) { console.error(err); toast(authMessage(err), true); }
    render();
}

app.addEventListener("click", (e) => {
    const btn = e.target.closest("[data-act]");
    if (!btn) return;
    const id = btn.closest("tr").dataset.id;
    const act = btn.dataset.act;
    const c = courses.find((x) => x.id === id);
    const g = games.find((x) => x.id === id);

    if (act === "publish" || act === "unpublish") {
        const status = act === "publish" ? "published" : "draft";
        return run(btn, async () => { await setCourseStatus(id, status); c.status = status; },
            status === "published" ? "Course published." : "Course unpublished.");
    }
    if (act === "del-course") {
        if (!confirm(`Delete "${c.title}" and all its sections and activities? Learner enrolments stay but the course disappears. This can't be undone.`)) return;
        return run(btn, async () => { await deleteCourse(id); courses = courses.filter((x) => x.id !== id); }, "Course deleted.");
    }
    if (act === "show" || act === "hide") {
        const vis = act === "show";
        return run(btn, async () => { await setGameVisible(id, vis); g.visible = vis; }, vis ? "Game is now visible." : "Game hidden.");
    }
    if (act === "del-game") {
        if (!confirm(`Delete "${g.title}"? Courses that use it will show the game as unavailable.`)) return;
        return run(btn, async () => { await deleteGame(id); games = games.filter((x) => x.id !== id); }, "Game deleted.");
    }
    if (act === "preview") {
        const m = openModal(`<h2>${esc(g.title)}</h2>${g.instructions ? `<p>${esc(g.instructions)}</p>` : ""}<div class="embed-wrap" id="slot"></div>
          <p class="hint">If nothing loads, the game's website may not allow embedding.</p>`, { wide: true });
        m.$("#slot").appendChild(makeGameFrame(g.embedUrl, g.height || 560, g.title));
    }
});

tabsEl.addEventListener("click", (e) => {
    const t = e.target.closest("[data-tab]");
    if (t) { tab = t.dataset.tab; history.replaceState(null, "", "#" + tab); search.value = ""; render(); }
});
search.addEventListener("input", render);

render();
