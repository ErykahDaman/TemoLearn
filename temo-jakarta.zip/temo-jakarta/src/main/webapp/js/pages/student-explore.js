import { boot, esc, thumbHTML } from "../student-shared.js";
import { listPublishedCourses } from "../courses.js";
import { listMyEnrollments, getEnrollment, enrolSelf } from "../student-api.js";
import { openModal, toast } from "../ui.js";

const { user, profile } = await boot("Explore");
const app = document.getElementById("app");
const filtersEl = document.getElementById("filters");
const searchEl = document.getElementById("q");

let courses = [];
const enrolled = new Set();
let cat = "All";

try {
    const [list, mine] = await Promise.all([listPublishedCourses(), listMyEnrollments(user)]);
    courses = list.sort((a, b) => (a.title || "").localeCompare(b.title || ""));
    mine.forEach((e) => enrolled.add(e.courseId));
} catch (err) {
    console.error(err);
    app.innerHTML = `<div class="panel-dark portal-card empty"><p>Couldn't load the courses. Check your connection and refresh.</p></div>`;
    throw err;
}

const categories = ["All", ...new Set(courses.map((c) => c.category || "General"))];

function render() {
    filtersEl.innerHTML = categories.map((c) =>
        `<button class="filter-btn${c === cat ? " active" : ""}" data-cat="${esc(c)}" type="button">${esc(c)}</button>`).join("");

    const term = searchEl.value.trim().toLowerCase();
    const list = courses.filter((c) =>
        (cat === "All" || (c.category || "General") === cat) &&
        (!term || [c.title, c.teaser, c.summary, c.category, c.description].join(" ").toLowerCase().includes(term)));

    if (!courses.length) {
        app.innerHTML = `<div class="panel-dark portal-card empty"><p>No courses have been published yet. Check back soon.</p></div>`;
        return;
    }
    if (!list.length) {
        app.innerHTML = `<div class="panel-dark portal-card empty"><p>No courses match your search.</p></div>`;
        return;
    }
    app.innerHTML = `<div class="learn-grid">${list.map((c) => `
      <article class="panel-dark l-card">
        ${thumbHTML(c)}
        <div class="l-body">
          <h3>${esc(c.title)}</h3>
          <p>${esc(c.teaser || c.summary || "")}</p>
          <div class="l-foot">
            <span class="l-pct">${[c.level, c.hours && c.hours + " hrs"].filter(Boolean).map(esc).join(" · ") || "&nbsp;"}</span>
            <span class="btn-row">
              <button class="btn btn-ghost btn-sm" data-info="${esc(c.id)}" type="button">Details</button>
              ${enrolled.has(c.id)
                ? `<a class="btn btn-olive btn-sm" href="portal/student/courses?open=${encodeURIComponent(c.id)}">Open</a>`
                : `<button class="btn btn-gold btn-sm" data-enrol="${esc(c.id)}" type="button">Enrol</button>`}
            </span>
          </div>
        </div>
      </article>`).join("")}</div>`;
}

async function enrol(id, btn) {
    const c = courses.find((x) => x.id === id);
    if (!c || enrolled.has(id)) return;
    if (btn) btn.disabled = true;
    try {
        // Never overwrite an existing enrolment: that would reset progress.
        if (!(await getEnrollment(user, id))) await enrolSelf(user, profile, id);
        enrolled.add(id);
        toast(`You're enrolled in ${c.title}.`);
        render();
    } catch (err) {
        console.error(err);
        if (btn) btn.disabled = false;
        toast("Couldn't enrol you. Please try again.", true);
    }
}

function details(id) {
    const c = courses.find((x) => x.id === id);
    if (!c) return;
    const chips = [c.category, c.level, c.hours && c.hours + " hours"].filter(Boolean)
        .map((t) => `<span class="meta-chip">${esc(t)}</span>`).join("");
    const m = openModal(`
      <span class="hud-chip">${esc(c.category || "Course")}</span>
      <h2>${esc(c.icon || "📜")} ${esc(c.title)}</h2>
      <div class="meta-row">${chips}</div>
      <p>${esc(c.description || c.summary || c.teaser || "No description yet.")}</p>
      ${c.output ? `<div class="detail-box"><h4>What you'll make</h4><p>${esc(c.output)}</p></div>` : ""}
      ${c.game ? `<div class="detail-box"><h4>Game</h4><p>${esc(c.game)}</p></div>` : ""}
      ${c.authorName ? `<p class="hint">Taught by ${esc(c.authorName)}</p>` : ""}
      <div class="modal-actions" id="act"></div>`);
    const act = m.$("#act");
    const paint = () => {
        act.innerHTML = enrolled.has(id)
            ? `<a class="btn btn-olive" href="portal/student/courses?open=${encodeURIComponent(id)}">Open course</a>`
            : `<button class="btn btn-gold" data-go type="button">Enrol in this course</button>`;
        act.innerHTML += `<button class="btn btn-ghost" data-x type="button">Close</button>`;
    };
    paint();
    act.addEventListener("click", async (e) => {
        if (!e.target.closest("[data-go]")) return;
        await enrol(id, e.target);
        paint();
    });
}

document.addEventListener("click", (e) => {
    const f = e.target.closest("[data-cat]");
    if (f) { cat = f.dataset.cat; render(); return; }
    const i = e.target.closest("[data-info]");
    if (i) { details(i.dataset.info); return; }
    const n = e.target.closest("[data-enrol]");
    if (n) enrol(n.dataset.enrol, n);
});
searchEl.addEventListener("input", render);

render();
const want = new URLSearchParams(location.search).get("course");
if (want) details(want);
