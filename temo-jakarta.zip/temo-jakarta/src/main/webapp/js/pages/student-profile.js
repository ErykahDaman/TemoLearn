import { boot, esc, fmtDate, loadLearning, computeBadges, badgeHTML } from "../student-shared.js";
import { saveMyProfile, changePassword, sendFeedback, listMyFeedback } from "../teacher-tools.js";
import { logOut } from "../auth.js";
import { avatarHTML, AVATARS } from "../avatar.js";
import { resizeImage } from "../images.js";
import { toast } from "../ui.js";

const { user, profile } = await boot("Profile");
const app = document.getElementById("app");

const TABS = [["profile", "Profile"], ["achievements", "Achievements"], ["security", "Security"], ["help", "Help & feedback"]];
let tab = TABS.some(([id]) => "#" + id === location.hash) ? location.hash.slice(1) : "profile";
let pending = { photo: profile.photo || "", avatar: profile.avatar || "" };
let rows = null;   // loaded the first time Achievements opens

const say = (id, text, kind = "") => {
    const el = document.getElementById(id);
    if (el) { el.className = "form-msg " + kind; el.textContent = text; }
};
const refreshChip = () => {
    const chip = document.querySelector(".who-chip");
    if (chip) chip.innerHTML = avatarHTML(profile, 32) + `<span class="who">${esc(profile.fullName)}</span>`;
};
const avatarGrid = () => AVATARS.map((a) =>
    `<button class="avatar-pick${!pending.photo && pending.avatar === a.e ? " on" : ""}" data-av="${a.e}" style="background:${a.c}" type="button" aria-label="Avatar ${a.e}">${a.e}</button>`).join("");
const bigAvatar = () => { document.getElementById("bigAvatar").innerHTML = avatarHTML({ ...profile, ...pending }, 96); };

/* ---------- Tabs ---------- */
function profileTab() {
    return `
    <div class="panel">
      <div class="profile-head">
        <div id="bigAvatar">${avatarHTML({ ...profile, ...pending }, 96)}</div>
        <div>
          <h2 style="margin:0 0 4px">${esc(profile.fullName)}</h2>
          <p style="margin:0 0 8px">${esc(user.email)}</p>
          <span class="status-chip published">Student</span>
          <span class="hint" style="margin-left:8px">Member since ${esc(fmtDate(profile.createdAt))}</span>
        </div>
      </div>

      <h3 style="margin-top:26px">Profile picture</h3>
      <div class="btn-row">
        <label class="btn btn-ghost btn-sm" for="pf-file" style="cursor:pointer">📷 Upload a photo</label>
        <input id="pf-file" type="file" accept="image/*" hidden>
        <button class="btn btn-ghost btn-sm" data-act="rm-photo" type="button">Remove photo</button>
      </div>
      <p class="hint">Or pick an avatar:</p>
      <div class="avatar-grid" id="avatarGrid">${avatarGrid()}</div>

      <h3>About you</h3>
      <form id="pf-form">
        <div class="grid-2">
          <div class="field"><label for="pf-name">Full name</label><input id="pf-name" maxlength="100" required value="${esc(profile.fullName)}"></div>
          <div class="field"><label for="pf-email">Email</label><input id="pf-email" value="${esc(user.email)}" disabled>
            <p class="hint">To change your email, send an account request under Help &amp; feedback.</p></div>
          <div class="field"><label for="pf-school">School or college</label><input id="pf-school" maxlength="100" placeholder="e.g. Botswana Accountancy College" value="${esc(profile.school || "")}"></div>
          <div class="field"><label for="pf-grade">Year or level</label><input id="pf-grade" maxlength="60" placeholder="e.g. Year 2, Form 5" value="${esc(profile.grade || "")}"></div>
          <div class="field"><label for="pf-loc">Location</label><input id="pf-loc" maxlength="80" placeholder="e.g. Gaborone, Botswana" value="${esc(profile.location || "")}"></div>
          <div class="field"><label for="pf-int">Interests</label><input id="pf-int" maxlength="160" placeholder="e.g. Hydroponics, soil health" value="${esc(profile.interests || "")}"></div>
        </div>
        <div class="field"><label for="pf-bio">Tell us about you</label><textarea id="pf-bio" rows="4" maxlength="500" style="min-height:100px">${esc(profile.bio || "")}</textarea></div>
        <p class="form-msg" id="pf-msg"></p>
        <button class="btn btn-gold" id="pf-save">Save profile</button>
      </form>
    </div>`;
}

function achievementsTab() {
    if (!rows) return `<div class="panel"><p class="hint">Loading your achievements…</p></div>`;
    const finished = rows.filter((r) => r.prog.pct === 100 || r.enr.completed).length;
    const acts = rows.reduce((n, r) => n + (r.enr.completedItems || []).length, 0);
    const scores = rows.flatMap((r) => Object.values(r.enr.quizScores || {}));
    const avg = scores.length ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length) : null;
    const badges = computeBadges(rows, profile);
    return `
    <div class="panel">
      <h2>Your badges</h2>
      <div class="badge-row">${badges.map(badgeHTML).join("")}</div>
      <p class="hint">Hover a locked badge to see how to earn it.</p>
      <div class="mini-stats">
        <div class="panel-dark stat"><div class="num">${finished}</div><div class="lbl">Courses finished</div></div>
        <div class="panel-dark stat"><div class="num">${acts}</div><div class="lbl">Activities done</div></div>
        <div class="panel-dark stat"><div class="num">${avg == null ? "—" : avg + "%"}</div><div class="lbl">Average quiz score</div></div>
      </div>
    </div>`;
}

function securityTab() {
    const last = user.metadata && user.metadata.lastSignInTime
        ? new Date(user.metadata.lastSignInTime).toLocaleString("en-GB") : "—";
    return `
    <div class="panel">
      <h2>Change password</h2>
      <form id="pw-form" autocomplete="off">
        <div class="field"><label for="pw-cur">Current password</label><input id="pw-cur" type="password" autocomplete="current-password" required></div>
        <div class="grid-2">
          <div class="field"><label for="pw-new">New password</label><input id="pw-new" type="password" minlength="6" autocomplete="new-password" required>
            <p class="hint">At least 6 characters. Longer is stronger.</p></div>
          <div class="field"><label for="pw-conf">Confirm new password</label><input id="pw-conf" type="password" minlength="6" autocomplete="new-password" required></div>
        </div>
        <p class="form-msg" id="pw-msg"></p>
        <div class="btn-row">
          <button class="btn btn-gold" id="pw-save">Update password</button>
        </div>
      </form>
      <h3 style="margin-top:28px">This device</h3>
      <p class="hint">Signed in as ${esc(user.email)}. Last sign-in: ${esc(last)}.</p>
      <button class="btn btn-ghost btn-sm" data-act="logout" type="button">Log out</button>
    </div>`;
}

function helpTab() {
    const faqs = [
        ["How do I join a course?", "Open Explore, pick a course and click Enrol. It then shows up under My Learning."],
        ["Why is a section locked?", "Your teacher decides when each section opens. It will unlock on its own once they open it."],
        ["How is my progress worked out?", "If your teacher marked some activities as required, only those count. Otherwise every activity counts."],
        ["A game won't load. What now?", "Some game sites block embedding. Try refreshing, and if it still fails, send us a problem report below."],
        ["How do I change my email or delete my account?", "Send an account request using the form below and an admin will help."]
    ];
    return `
    <div class="panel faq">
      <h2>Help</h2>
      ${faqs.map(([q, a]) => `<details><summary>${esc(q)}</summary><p>${esc(a)}</p></details>`).join("")}
    </div>
    <div class="panel" style="margin-top:24px">
      <h2>Send feedback to the admin</h2>
      <form id="fb-form">
        <div class="grid-2">
          <div class="field"><label for="fb-type">Type</label>
            <select id="fb-type">
              <option>Question</option><option>Report a problem</option>
              <option>Idea or suggestion</option><option>Account request</option><option>Other</option>
            </select></div>
          <div class="field"><label for="fb-subject">Subject</label><input id="fb-subject" maxlength="150" required></div>
        </div>
        <div class="field"><label for="fb-msg">Message</label><textarea id="fb-msg" rows="5" maxlength="3000" required></textarea></div>
        <p class="form-msg" id="fb-status"></p>
        <button class="btn btn-gold" id="fb-send">Send to admin</button>
      </form>
    </div>
    <div class="panel" style="margin-top:24px">
      <h2>Your messages</h2>
      <div id="fb-list"><p class="hint">Loading...</p></div>
    </div>`;
}

async function loadFeedback() {
    const box = document.getElementById("fb-list");
    if (!box) return;
    try {
        const items = await listMyFeedback(user);
        box.innerHTML = items.length ? items.map((f) => `
          <div class="fb-item">
            <strong>${esc(f.subject)}</strong>
            <span class="hint"> · ${esc(f.type)} · ${esc(fmtDate(f.createdAt))} · ${esc(f.status || "new")}</span>
            <p>${esc(f.message)}</p>
            ${f.reply ? `<div class="fb-reply"><strong>Admin reply:</strong> ${esc(f.reply)}</div>` : ""}
          </div>`).join("") : `<p class="hint">You haven't sent any messages yet.</p>`;
    } catch (err) {
        console.warn(err);
        box.innerHTML = `<p class="hint">Couldn't load your messages.</p>`;
    }
}

async function render() {
    const body = { profile: profileTab, achievements: achievementsTab, security: securityTab, help: helpTab }[tab]();
    app.innerHTML = `
      <div class="tabs">
        ${TABS.map(([id, label]) => `<button class="tab${id === tab ? " active" : ""}" data-tab="${id}" type="button">${label}</button>`).join("")}
      </div>
      ${body}`;
    if (tab === "help") loadFeedback();
    if (tab === "achievements" && !rows) {
        try { rows = await loadLearning(user); } catch (err) { console.warn(err); rows = []; }
        if (tab === "achievements") render();
    }
}

const authError = (err) => ({
    "auth/wrong-password": "Your current password is wrong.",
    "auth/invalid-credential": "Your current password is wrong.",
    "auth/weak-password": "The new password must be at least 6 characters.",
    "auth/requires-recent-login": "For security, please log out, log back in and try again.",
    "auth/too-many-requests": "Too many tries. Wait a bit and try again."
}[err.code] || "Something went wrong. Please try again.");

/* ---------- Clicks ---------- */
app.addEventListener("click", async (e) => {
    const tabBtn = e.target.closest("[data-tab]");
    if (tabBtn) { tab = tabBtn.dataset.tab; history.replaceState(null, "", "#" + tab); render(); return; }

    const av = e.target.closest("[data-av]");
    if (av) {
        pending = { photo: "", avatar: av.dataset.av };
        document.getElementById("avatarGrid").innerHTML = avatarGrid();
        bigAvatar();
        return;
    }

    const btn = e.target.closest("[data-act]");
    if (!btn) return;
    const act = btn.dataset.act;

    if (act === "rm-photo") {
        pending.photo = "";
        document.getElementById("avatarGrid").innerHTML = avatarGrid();
        bigAvatar();
    }
    if (act === "logout") { await logOut(); location.href = "./"; }
});

app.addEventListener("change", async (e) => {
    if (e.target.id !== "pf-file" || !e.target.files[0]) return;
    try {
        pending.photo = await resizeImage(e.target.files[0], 256, 0.8);
        document.getElementById("avatarGrid").innerHTML = avatarGrid();
        bigAvatar();
    } catch (err) { toast("Couldn't read that image.", true); }
});

app.addEventListener("submit", async (e) => {
    e.preventDefault();
    const form = e.target.id;
    const val = (id) => document.getElementById(id).value.trim();

    if (form === "pf-form") {
        const fullName = val("pf-name");
        if (!fullName) return say("pf-msg", "Your name can't be empty.", "error");
        const patch = {
            fullName, school: val("pf-school"), grade: val("pf-grade"), location: val("pf-loc"),
            interests: val("pf-int"), bio: val("pf-bio"), photo: pending.photo, avatar: pending.avatar
        };
        const btn = document.getElementById("pf-save");
        btn.disabled = true;
        try {
            await saveMyProfile(user, patch);
            Object.assign(profile, patch);
            refreshChip();
            render();
            toast("Profile saved.");
        } catch (err) {
            console.error(err);
            btn.disabled = false;
            say("pf-msg", "Couldn't save. If your photo is large, try a smaller one.", "error");
        }
    }

    if (form === "pw-form") {
        const next = document.getElementById("pw-new").value;
        if (next !== document.getElementById("pw-conf").value) return say("pw-msg", "The new passwords don't match.", "error");
        if (next === document.getElementById("pw-cur").value) return say("pw-msg", "Choose a password different from your current one.", "error");
        const btn = document.getElementById("pw-save");
        btn.disabled = true;
        try {
            await changePassword(document.getElementById("pw-cur").value, next);
            e.target.reset();
            say("pw-msg", "Password updated.", "ok");
            toast("Password updated.");
        } catch (err) {
            console.error(err);
            say("pw-msg", authError(err), "error");
        }
        btn.disabled = false;
    }

    if (form === "fb-form") {
        const btn = document.getElementById("fb-send");
        btn.disabled = true;
        try {
            await sendFeedback(user, profile, {
                type: document.getElementById("fb-type").value,
                subject: val("fb-subject"),
                message: val("fb-msg")
            });
            e.target.reset();
            say("fb-status", "Sent. An admin will get back to you.", "ok");
            loadFeedback();
        } catch (err) {
            console.error(err);
            say("fb-status", "Couldn't send that. Please try again.", "error");
        }
        btn.disabled = false;
    }
});

render();
