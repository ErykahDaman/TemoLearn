/* Public course library: category filter buttons, and click-to-open syllabus on each card.
   The cards themselves are rendered on the server (JSP); this only adds behaviour. */
const grid = document.getElementById("grid");
const filters = document.getElementById("filters");
const cards = [...grid.querySelectorAll(".course-card")];

function setOpen(card, open) {
    card.classList.toggle("open", open);
    card.querySelector(".course-head")?.setAttribute("aria-expanded", String(open));
}

grid.addEventListener("click", (e) => {
    const head = e.target.closest(".course-head");
    if (!head) return;
    const card = head.closest(".course-card");
    const willOpen = !card.classList.contains("open");
    cards.forEach((c) => setOpen(c, false));
    setOpen(card, willOpen);
    if (willOpen) card.scrollIntoView({ behavior: "smooth", block: "nearest" });
});
grid.addEventListener("keydown", (e) => {
    if ((e.key === "Enter" || e.key === " ") && e.target.classList.contains("course-head")) {
        e.preventDefault();
        e.target.click();
    }
});

const cats = ["All", ...new Set(cards.map((c) => c.dataset.category))];
if (cats.length > 2) {
    filters.innerHTML = cats.map((c, i) =>
        `<button type="button" class="filter-btn${i === 0 ? " active" : ""}" data-cat="${c.replace(/"/g, "&quot;")}"></button>`).join("");
    [...filters.children].forEach((b, i) => { b.textContent = cats[i]; });
    filters.addEventListener("click", (e) => {
        const btn = e.target.closest(".filter-btn");
        if (!btn) return;
        filters.querySelectorAll(".filter-btn").forEach((b) => b.classList.toggle("active", b === btn));
        cards.forEach((c) => {
            const show = btn.dataset.cat === "All" || c.dataset.category === btn.dataset.cat;
            c.hidden = !show;
            if (!show) setOpen(c, false);
        });
    });
}

/* A link like courses#<id> opens that course. */
const id = decodeURIComponent(location.hash.slice(1));
const target = id && cards.find((c) => c.dataset.id === id);
if (target) { setOpen(target, true); target.scrollIntoView({ block: "center" }); }
