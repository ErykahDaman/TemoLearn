import { boot, esc, plural, roleChip, ago, tally } from "../admin-shared.js";
import { listUsers, listAllCourses, listAllGames, listAllEnrollments, listAllFeedback } from "../admin-api.js";
import { avatarHTML } from "../avatar.js";

const { profile } = await boot("Overview");
const app = document.getElementById("app");
const first = (profile.fullName || "").trim().split(" ")[0] || "Admin";

const results = await Promise.allSettled([listUsers(), listAllCourses(), listAllGames(), listAllEnrollments(), listAllFeedback()]);
const [users, courses, games, enrols, feedback] = results.map((r) => (r.status === "fulfilled" ? r.value : []));
const failed = results.filter((r) => r.status === "rejected");
failed.forEach((r) => console.warn("Admin overview load failed", r.reason));

const roles = tally(users, (u) => u.role || "student");
const published = courses.filter((c) => c.status === "published").length;
const drafts = courses.length - published;
const completions = enrols.filter((e) => e.completed).length;
const learners = new Set(enrols.map((e) => e.uid)).size;
const newFb = feedback.filter((f) => (f.status || "new") === "new").length;
const disabled = users.filter((u) => u.disabled).length;
const hiddenGames = games.filter((g) => !g.visible).length;

const perCourse = tally(enrols, (e) => e.courseId);
const popular = courses
    .map((c) => ({ c, n: perCourse[c.id] || 0 }))
    .sort((a, b) => b.n - a.n).slice(0, 5);
const topN = Math.max(1, ...popular.map((p) => p.n));
const roleMax = Math.max(1, roles.student || 0, roles.teacher || 0, roles.admin || 0);

const recent = users.slice(0, 6).map((u) => `
  <li><div class="row-item">
    ${avatarHTML(u, 40)}
    <span class="row-main"><strong>${esc(u.fullName || "Unnamed")}</strong><span>${esc(u.email || "")} · ${esc(ago(u.createdAt))}</span></span>
    ${roleChip(u.role)}
  </div></li>`).join("");

const popRows = popular.length ? popular.map((p) => `
  <div class="bar-row"><div class="top"><span>${esc(p.c.icon || "📜")} ${esc(p.c.title)}</span><span>${plural(p.n, "learner")}</span></div>
    <div class="meter" style="--pct:${Math.round((p.n * 100) / topN)}%"><span></span></div></div>`).join("")
    : `<p class="muted" style="margin:0">No courses yet.</p>`;

const roleRow = (label, n) => `
  <div class="bar-row"><div class="top"><span>${label}</span><span>${n}</span></div>
    <div class="meter" style="--pct:${Math.round((n * 100) / roleMax)}%"><span></span></div></div>`;

const alert = (n, text, href, hot) =>
    `<a class="alert-row${hot && n ? " hot" : ""}" href="${href}"><b>${n}</b><span>${text}</span></a>`;

app.innerHTML = `
  <section class="a-hero">
    <div>
      <span class="hud-chip">Admin console</span>
      <h1>Hello, ${esc(first)}</h1>
      <p>Create teacher accounts, keep an eye on courses and games, and answer what people send in.</p>
    </div>
    <div class="hero-actions">
      <a class="btn btn-sage" href="portal/admin/users?new=teacher">＋ Create teacher</a>
      <a class="btn btn-ghost" href="portal/admin/feedback">✉ Feedback${newFb ? ` (${newFb})` : ""}</a>
    </div>
  </section>

  ${failed.length ? `<div class="panel-dark portal-card" style="margin-bottom:24px"><strong>Some data couldn't load.</strong>
    <span class="muted"> Please refresh and try again.</span></div>` : ""}

  <section class="stat-grid">
    <div class="panel-dark stat"><div class="num">${users.length}</div><div class="lbl">Users</div><div class="sub">${roles.student || 0} students · ${roles.teacher || 0} teachers</div></div>
    <div class="panel-dark stat"><div class="num">${courses.length}</div><div class="lbl">Courses</div><div class="sub">${published} published · ${drafts} draft</div></div>
    <div class="panel-dark stat"><div class="num">${enrols.length}</div><div class="lbl">Enrolments</div><div class="sub">${plural(learners, "learner")} · ${completions} finished</div></div>
    <div class="panel-dark stat"><div class="num">${games.length}</div><div class="lbl">Games</div><div class="sub">${games.length - hiddenGames} visible to learners</div></div>
  </section>

  <section class="portal-grid">
    <div class="stack">
      <div class="panel-dark portal-card">
        <h2>Recent sign-ups</h2>
        ${recent ? `<ul class="row-list">${recent}</ul>
          <p style="margin:16px 0 0"><a href="portal/admin/users">Manage all users →</a></p>` : `<p class="muted" style="margin:0">No users yet.</p>`}
      </div>
      <div class="panel-dark portal-card">
        <h2>Most popular courses</h2>
        <div class="bar-list">${popRows}</div>
      </div>
    </div>

    <div class="stack">
      <div class="panel-dark portal-card">
        <h2>Needs attention</h2>
        <div class="bar-list" style="gap:10px">
          ${alert(newFb, "new feedback message" + (newFb === 1 ? "" : "s"), "portal/admin/feedback", true)}
          ${alert(drafts, "course" + (drafts === 1 ? "" : "s") + " still in draft", "portal/admin/content", false)}
          ${alert(hiddenGames, "hidden game" + (hiddenGames === 1 ? "" : "s"), "portal/admin/content#games", false)}
          ${alert(disabled, "disabled account" + (disabled === 1 ? "" : "s"), "portal/admin/users", false)}
        </div>
      </div>
      <div class="panel-dark portal-card">
        <h2>Who's here</h2>
        <div class="bar-list">
          ${roleRow("Students", roles.student || 0)}
          ${roleRow("Teachers", roles.teacher || 0)}
          ${roleRow("Admins", roles.admin || 0)}
        </div>
      </div>
    </div>
  </section>`;
