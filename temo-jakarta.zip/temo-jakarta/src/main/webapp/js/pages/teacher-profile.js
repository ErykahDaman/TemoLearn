import { requireRole } from "../auth.js";
import { mountPortal, applyMode } from "../portal-layout.js";
import { saveMyProfile, changePassword, sendFeedback, listMyFeedback } from "../teacher-tools.js";
import { logOut } from "../auth.js";
import { avatarHTML, AVATARS } from "../avatar.js";
import { resizeImage } from "../images.js";
import { esc } from "../util.js";
import { toast } from "../ui.js";

const { user, profile } = await requireRole(["teacher", "admin"]);
mountPortal({ profile, active: "Profile" });

const app = document.getElementById("app");
const TABS = [["profile", "Profile"], ["appearance", "Appearance"], ["security", "Security"], ["help", "Help & feedback"]];
let tab = TABS.some(([id]) => "#" + id === location.hash) ? location.hash.slice(1) : "profile";
let pending = { photo: profile.photo || "", avatar: profile.avatar || "" };

const fmtDate = (ts) => ts && ts.toDate
    ? ts.toDate().toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" }) : "—";
const say = (id, text, kind = "") => {
    const el = document.getElementById(id);
    if (el) { el.className = "form-msg " + kind; el.textContent = text; }
};
const refreshChip = () => {
    const chip = document.querySelector(".who-chip");
    if (chip) chip.innerHTML = avatarHTML(profile, 32) + `<span class="who">${esc(profile.fullName)}</span>`;
};

/* ---------- Tabs ---------- */
function profileTab() {
    return `
    <div class="panel">
      <div class="profile-head">
        <div id="bigAvatar">${avatarHTML({ ...profile, ...pending }, 96)}</div>
        <div>
          <h2 style="margin:0 0 4px">${esc(profile.fullName)}</h2>
          <p style="margin:0 0 8px">${esc(user.email)}</p>
          <span class="status-chip published">${esc(profile.role)}</span>
          <span class="hint" style="margin-left:8px">Member since ${esc(fmtDate(profile.createdAt))}</span>
        </div>
      </div>

      <h3 style="margin-top:26px">Profile picture</h3>
      <div class="btn-row">
        <label class="btn btn-ghost btn-sm" for="pf-file" style="cursor:pointer">📷 Upload a photo</label>
        <input id="pf-file" type="file" accept="image/*" hidden>
        <button class="btn btn-ghost btn-sm" data-act="rm-photo" type="button">Remove photo</button>
      </div>
      <p class="hint">Or pick an avatar:</p>
      <div class="avatar-grid" id="avatarGrid">${avatarGrid()}</div>

      <h3>Personal details</h3>
      <form id="pf-form">
        <div class="grid-2">
          <div class="field"><label for="pf-name">Full name</label><input id="pf-name" maxlength="100" required value="${esc(profile.fullName)}"></div>
          <div class="field"><label for="pf-email">Email</label><input id="pf-email" value="${esc(user.email)}" disabled>
            <p class="hint">To change your email, send an account request under Help &amp; feedback.</p></div>
          <div class="field"><label for="pf-title">Job title</label><input id="pf-title" maxlength="80" placeholder="e.g. Lecturer, Farm advisor" value="${esc(profile.title || "")}"></div>
          <div class="field"><label for="pf-org">Organisation</label><input id="pf-org" maxlength="100" value="${esc(profile.organisation || "")}"></div>
          <div class="field"><label for="pf-phone">Phone</label><input id="pf-phone" type="tel" maxlength="30" value="${esc(profile.phone || "")}"></div>
          <div class="field"><label for="pf-loc">Location</label><input id="pf-loc" maxlength="80" placeholder="e.g. Gaborone, Botswana" value="${esc(profile.location || "")}"></div>
        </div>
        <div class="field"><label for="pf-subjects">Subjects you teach</label><input id="pf-subjects" maxlength="160" placeholder="e.g. Hydroponics, soil health" value="${esc(profile.subjects || "")}"></div>
        <div class="field"><label for="pf-bio">About you</label><textarea id="pf-bio" rows="4" maxlength="500">${esc(profile.bio || "")}</textarea></div>
        <p class="form-msg" id="pf-msg"></p>
        <button class="btn btn-gold" id="pf-save">Save profile</button>
      </form>
    </div>`;
}

function avatarGrid() {
    return AVATARS.map((a) =>
        `<button class="avatar-pick${!pending.photo && pending.avatar === a.e ? " on" : ""}" data-av="${a.e}" style="background:${a.c}" type="button" aria-label="Avatar ${a.e}">${a.e}</button>`
    ).join("");
}

function appearanceTab() {
    const cur = localStorage.getItem("tl-mode") || profile.themeMode || "dark";
    const label = { dark: "🌙 Dark", light: "☀️ Light", auto: "🖥 Auto" };
    return `
    <div class="panel">
      <h2>Appearance</h2>
      <p>Choose how the teacher portal looks.</p>
      <div class="seg">
        ${["dark", "light", "auto"].map((m) => `<button type="button" data-mode="${m}" class="${m === cur ? "on" : ""}">${label[m]}</button>`).join("")}
      </div>
      <p class="hint">Auto follows your device's setting. Your choice is saved to your account.</p>
    </div>`;
}

function securityTab() {
    const last = user.metadata && user.metadata.lastSignInTime
        ? new Date(user.metadata.lastSignInTime).toLocaleString("en-GB") : "—";
    return `
    <div class="panel">
      <h2>Change password</h2>
      <form id="pw-form" autocomplete="off">
        <div class="field"><label for="pw-cur">Current password</label><input id="pw-cur" type="password" autocomplete="current-password" required></div>
        <div class="grid-2">
          <div class="field"><label for="pw-new">New password</label><input id="pw-new" type="password" minlength="6" autocomplete="new-password" required>
            <p class="hint">At least 6 characters. Longer is stronger.</p></div>
          <div class="field"><label for="pw-conf">Confirm new password</label><input id="pw-conf" type="password" minlength="6" autocomplete="new-password" required></div>
        </div>
        <p class="form-msg" id="pw-msg"></p>
        <div class="btn-row">
          <button class="btn btn-gold" id="pw-save">Update password</button>
        </div>
      </form>
      <h3 style="margin-top:28px">This device</h3>
      <p class="hint">Signed in as ${esc(user.email)}. Last sign-in: ${esc(last)}.</p>
      <button class="btn btn-ghost btn-sm" data-act="logout" type="button">Log out</button>
    </div>`;
}

function helpTab() {
    const faqs = [
        ["How do I create a course?", "Open My Courses and click New course, or Start from the syllabus to begin with one of the 10 planned courses already filled in."],
        ["How do I lock a section?", "In the course editor, click the 🔓 button on a section. Learners can't open a locked section until you unlock it."],
        ["How do I add a game?", "Open My Games, click Add game and paste the embed code. Then add a Game activity inside a course section and pick it."],
        ["How do I enrol students?", "Open My Students, choose the course and click Enrol students. Students must have signed up first."],
        ["Why can't students see my course?", "Only published courses are visible. Click Publish in the course editor."],
        ["How do I change my email or delete my account?", "Send an account request using the form below and an admin will help."]
    ];
    return `
    <div class="panel faq">
      <h2>Help</h2>
      ${faqs.map(([q, a]) => `<details><summary>${esc(q)}</summary><p>${esc(a)}</p></details>`).join("")}
    </div>
    <div class="panel" style="margin-top:24px">
      <h2>Send feedback to the admin</h2>
      <form id="fb-form">
        <div class="grid-2">
          <div class="field"><label for="fb-type">Type</label>
            <select id="fb-type">
              <option>Question</option><option>Report a problem</option>
              <option>Idea or suggestion</option><option>Account request</option><option>Other</option>
            </select></div>
          <div class="field"><label for="fb-subject">Subject</label><input id="fb-subject" maxlength="150" required></div>
        </div>
        <div class="field"><label for="fb-msg">Message</label><textarea id="fb-msg" rows="5" maxlength="3000" required></textarea></div>
        <p class="form-msg" id="fb-status"></p>
        <button class="btn btn-gold" id="fb-send">Send to admin</button>
      </form>
    </div>
    <div class="panel" style="margin-top:24px">
      <h2>Your messages</h2>
      <div id="fb-list"><p class="hint">Loading...</p></div>
    </div>`;
}

async function loadFeedback() {
    const box = document.getElementById("fb-list");
    if (!box) return;
    try {
        const items = await listMyFeedback(user);
        box.innerHTML = items.length ? items.map((f) => `
      <div class="fb-item">
        <strong>${esc(f.subject)}</strong>
        <span class="hint"> · ${esc(f.type)} · ${esc(fmtDate(f.createdAt))} · ${esc(f.status || "new")}</span>
        <p>${esc(f.message)}</p>
        ${f.reply ? `<div class="fb-reply"><strong>Admin reply:</strong> ${esc(f.reply)}</div>` : ""}
      </div>`).join("") : `<p class="hint">You haven't sent any messages yet.</p>`;
    } catch (err) {
        console.warn(err);
        box.innerHTML = `<p class="hint">Couldn't load your messages.</p>`;
    }
}

function render() {
    const body = { profile: profileTab, appearance: appearanceTab, security: securityTab, help: helpTab }[tab]();
    app.innerHTML = `
    <div class="tabs">
      ${TABS.map(([id, label]) => `<button class="tab${id === tab ? " active" : ""}" data-tab="${id}" type="button">${label}</button>`).join("")}
    </div>
    ${body}`;
    if (tab === "help") loadFeedback();
}

const authError = (err) => ({
    "auth/wrong-password": "Your current password is wrong.",
    "auth/invalid-credential": "Your current password is wrong.",
    "auth/weak-password": "The new password must be at least 6 characters.",
    "auth/requires-recent-login": "For security, please log out, log back in and try again.",
    "auth/too-many-requests": "Too many tries. Wait a bit and try again."
}[err.code] || "Something went wrong. Please try again.");

/* ---------- Clicks ---------- */
app.addEventListener("click", async (e) => {
    const tabBtn = e.target.closest("[data-tab]");
    if (tabBtn) { tab = tabBtn.dataset.tab; history.replaceState(null, "", "#" + tab); render(); return; }

    const av = e.target.closest("[data-av]");
    if (av) {
        pending = { photo: "", avatar: av.dataset.av };
        document.getElementById("avatarGrid").innerHTML = avatarGrid();
        document.getElementById("bigAvatar").innerHTML = avatarHTML({ ...profile, ...pending }, 96);
        return;
    }

    const modeBtn = e.target.closest("[data-mode]");
    if (modeBtn) {
        const mode = modeBtn.dataset.mode;
        applyMode(mode);
        app.querySelectorAll("[data-mode]").forEach((b) => b.classList.toggle("on", b === modeBtn));
        try { await saveMyProfile(user, { themeMode: mode }); profile.themeMode = mode; toast("Appearance saved."); }
        catch (err) { console.error(err); toast("Applied here, but couldn't save to your account.", true); }
        return;
    }

    const btn = e.target.closest("[data-act]");
    if (!btn) return;
    const act = btn.dataset.act;

    if (act === "rm-photo") {
        pending.photo = "";
        document.getElementById("avatarGrid").innerHTML = avatarGrid();
        document.getElementById("bigAvatar").innerHTML = avatarHTML({ ...profile, ...pending }, 96);
    }
    if (act === "logout") { await logOut(); location.href = "./"; }
});

/* ---------- File + forms ---------- */
app.addEventListener("change", async (e) => {
    if (e.target.id !== "pf-file" || !e.target.files[0]) return;
    try {
        pending.photo = await resizeImage(e.target.files[0], 256, 0.8);
        document.getElementById("avatarGrid").innerHTML = avatarGrid();
        document.getElementById("bigAvatar").innerHTML = avatarHTML({ ...profile, ...pending }, 96);
    } catch (err) { toast("Couldn't read that image.", true); }
});

app.addEventListener("submit", async (e) => {
    e.preventDefault();
    const form = e.target.id;
    const val = (id) => document.getElementById(id).value.trim();

    if (form === "pf-form") {
        const fullName = val("pf-name");
        if (!fullName) return say("pf-msg", "Your name can't be empty.", "error");
        const patch = {
            fullName, title: val("pf-title"), organisation: val("pf-org"), phone: val("pf-phone"),
            location: val("pf-loc"), subjects: val("pf-subjects"), bio: val("pf-bio"),
            photo: pending.photo, avatar: pending.avatar
        };
        const btn = document.getElementById("pf-save");
        btn.disabled = true;
        try {
            await saveMyProfile(user, patch);
            Object.assign(profile, patch);
            refreshChip();
            render();
            toast("Profile saved.");
        } catch (err) {
            console.error(err);
            btn.disabled = false;
            say("pf-msg", "Couldn't save. If your photo is large, try a smaller one.", "error");
        }
    }

    if (form === "pw-form") {
        const next = document.getElementById("pw-new").value;
        if (next !== document.getElementById("pw-conf").value) return say("pw-msg", "The new passwords don't match.", "error");
        if (next === document.getElementById("pw-cur").value) return say("pw-msg", "Choose a password different from your current one.", "error");
        const btn = document.getElementById("pw-save");
        btn.disabled = true;
        try {
            await changePassword(document.getElementById("pw-cur").value, next);
            e.target.reset();
            say("pw-msg", "Password updated.", "ok");
            toast("Password updated.");
        } catch (err) {
            console.error(err);
            say("pw-msg", authError(err), "error");
        }
        btn.disabled = false;
    }

    if (form === "fb-form") {
        const btn = document.getElementById("fb-send");
        btn.disabled = true;
        try {
            await sendFeedback(user, profile, {
                type: document.getElementById("fb-type").value,
                subject: val("fb-subject"),
                message: val("fb-msg")
            });
            e.target.reset();
            say("fb-status", "Sent. An admin will get back to you.", "ok");
            loadFeedback();
        } catch (err) {
            console.error(err);
            say("fb-status", "Couldn't send that. Please try again.", "error");
        }
        btn.disabled = false;
    }
});

render();
