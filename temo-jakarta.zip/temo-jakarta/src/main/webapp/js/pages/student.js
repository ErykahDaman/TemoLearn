import { boot, esc, plural, loadLearning, computeBadges, badgeHTML, thumbHTML } from "../student-shared.js";
import { openCourse } from "../student-learn.js";
import { listPublishedCourses } from "../courses.js";
import { listVisibleGames, courseProgress } from "../student-api.js";

const { user, profile } = await boot("Home");
const app = document.getElementById("app");
const first = (profile.fullName || "").trim().split(" ")[0] || "there";

let rows = [], published = [], games = [];
const [r, p, g] = await Promise.allSettled([loadLearning(user), listPublishedCourses(), listVisibleGames()]);
if (r.status === "fulfilled") rows = r.value; else console.warn("Could not load your learning", r.reason);
if (p.status === "fulfilled") published = p.value;
if (g.status === "fulfilled") games = g.value;

function render() {
    const finished = rows.filter((x) => x.prog.pct === 100 || x.enr.completed);
    const active = rows.filter((x) => !(x.prog.pct === 100 || x.enr.completed));
    const activities = rows.reduce((n, x) => n + (x.enr.completedItems || []).length, 0);
    const overall = rows.length ? Math.round(rows.reduce((n, x) => n + x.prog.pct, 0) / rows.length) : 0;
    const resume = active[0];
    const enrolledIds = new Set(rows.map((x) => x.course.id));
    const suggestions = published.filter((c) => !enrolledIds.has(c.id)).slice(0, 3);
    const badges = computeBadges(rows, profile);
    const earned = badges.filter((b) => b.on).length;

    const resumeCard = resume ? `
      <div class="continue-card">
        <span class="row-icon">${esc(resume.course.icon || "📜")}</span>
        <div class="grow">
          <span class="hud-chip">Pick up where you left off</span>
          <h3 style="margin-top:8px">${esc(resume.course.title)}</h3>
          <div class="meter" style="--pct:${resume.prog.pct}%"><span></span></div>
          <span class="hint">${plural(resume.prog.done, "activity")} of ${resume.prog.total} done · ${resume.prog.pct}%</span>
        </div>
        <button class="btn btn-gold" data-open="${esc(resume.course.id)}" type="button">Continue ▶</button>
      </div>`
        : `<div class="empty"><p>${rows.length ? "You've finished everything you're enrolled in. Time to explore something new!" : "You haven't started a course yet."}</p>
           <a class="btn btn-gold" href="portal/student/explore">Explore courses</a></div>`;

    const courseRows = rows.slice(0, 5).map((x) => `
      <li><button class="row-item" data-open="${esc(x.course.id)}" type="button" style="width:100%;text-align:left;font:inherit;cursor:pointer">
        <span class="row-icon">${esc(x.course.icon || "📜")}</span>
        <span class="row-main"><strong>${esc(x.course.title)}</strong>
          <span>${esc(x.course.category || "General")} · ${x.prog.pct}% complete</span></span>
        <span class="status-chip ${x.prog.pct === 100 ? "published" : "draft"}">${x.prog.pct === 100 ? "Done" : "In progress"}</span>
      </button></li>`).join("");

    const suggestRows = suggestions.map((c) => `
      <li><a class="row-item" href="portal/student/explore?course=${encodeURIComponent(c.id)}">
        <span class="row-icon">${esc(c.icon || "📜")}</span>
        <span class="row-main"><strong>${esc(c.title)}</strong><span>${esc(c.category || "General")}</span></span>
        <span class="status-chip draft">New</span>
      </a></li>`).join("");

    app.innerHTML = `
      <section class="s-hero">
        <div>
          <span class="hud-chip">Student portal</span>
          <h1>Welcome back, ${esc(first)}</h1>
          <p>Grow your farming knowledge one lesson at a time. Your progress, courses and games are all here.</p>
        </div>
        <div class="hero-actions">
          <a class="btn btn-olive" href="portal/student/explore">🧭 Explore courses</a>
          <a class="btn btn-ghost" href="portal/student/games">🎮 Play a game</a>
        </div>
      </section>

      <section class="stat-grid">
        <div class="panel-dark stat"><div class="num">${rows.length}</div><div class="lbl">Courses</div><div class="sub">${active.length} in progress</div></div>
        <div class="panel-dark stat"><div class="num">${finished.length}</div><div class="lbl">Completed</div><div class="sub">Courses finished</div></div>
        <div class="panel-dark stat"><div class="num">${activities}</div><div class="lbl">Activities</div><div class="sub">Lessons, quizzes &amp; more</div></div>
        <div class="panel-dark stat"><div class="num">${earned}</div><div class="lbl">Badges</div><div class="sub">${badges.length - earned} still to earn</div></div>
      </section>

      <section class="portal-grid">
        <div class="stack">
          <div class="panel-dark portal-card">
            <h2>Continue learning</h2>
            ${resumeCard}
          </div>
          ${rows.length ? `
          <div class="panel-dark portal-card">
            <h2>My learning</h2>
            <ul class="row-list">${courseRows}</ul>
            <p style="margin:16px 0 0"><a href="portal/student/courses">See all my courses →</a></p>
          </div>` : ""}
        </div>

        <div class="stack">
          <div class="panel-dark portal-card">
            <h2>Overall progress</h2>
            <div class="ring-wrap">
              <div class="ring" style="--p:${overall}" data-label="${overall}%" role="img" aria-label="${overall} percent overall progress"></div>
              <p class="muted" style="margin:0;flex:1;min-width:130px">${rows.length ? `Average across ${plural(rows.length, "course")}.` : "Enrol in a course to start tracking progress."}</p>
            </div>
          </div>

          <div class="panel-dark portal-card">
            <h2>Badges</h2>
            <div class="badge-row">${badges.map(badgeHTML).join("")}</div>
            <p class="hint">Hover a locked badge to see how to earn it.</p>
          </div>

          <div class="panel-dark portal-card">
            <h2>Try something new</h2>
            ${suggestRows ? `<ul class="row-list">${suggestRows}</ul>` : `<p class="muted" style="margin:0">No new courses right now. Check back soon.</p>`}
            <p style="margin:16px 0 0">
              <a href="portal/student/explore">Browse all courses →</a><br>
              <a href="portal/student/games">${games.length ? plural(games.length, "game") + " ready to play →" : "Visit the games arcade →"}</a>
            </p>
          </div>
        </div>
      </section>`;
}

app.addEventListener("click", (e) => {
    const b = e.target.closest("[data-open]");
    if (!b) return;
    const row = rows.find((x) => x.course.id === b.dataset.open);
    if (!row) return;
    openCourse({
        user, profile, course: row.course, enr: row.enr, startItemId: row.enr.lastItem,
        onChange: () => { row.prog = courseProgress(row.enr, row.mods); render(); }
    });
});

render();
