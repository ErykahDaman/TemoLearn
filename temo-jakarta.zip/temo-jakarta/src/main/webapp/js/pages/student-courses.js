import { boot, esc, plural, loadLearning, thumbHTML } from "../student-shared.js";
import { openCourse } from "../student-learn.js";
import { courseProgress } from "../student-api.js";

const { user, profile } = await boot("My Learning");
const app = document.getElementById("app");
const tabsEl = document.getElementById("tabs");

let rows = [];
let tab = "all";
try { rows = await loadLearning(user); }
catch (err) {
    console.error(err);
    app.innerHTML = `<div class="panel-dark portal-card empty"><p>Couldn't load your courses. Check your connection and refresh.</p></div>`;
    throw err;
}

const isDone = (r) => r.prog.pct === 100 || r.enr.completed;
const FILTERS = [
    ["all", "All", () => true],
    ["progress", "In progress", (r) => !isDone(r)],
    ["done", "Completed", isDone]
];

function render() {
    tabsEl.innerHTML = FILTERS.map(([id, label, fn]) =>
        `<button class="tab${id === tab ? " active" : ""}" data-tab="${id}" type="button">${label} (${rows.filter(fn).length})</button>`).join("");

    if (!rows.length) {
        app.innerHTML = `<div class="panel-dark portal-card empty">
          <p>You aren't enrolled in any courses yet.</p>
          <a class="btn btn-gold" href="portal/student/explore">Explore courses</a></div>`;
        return;
    }
    const fn = FILTERS.find(([id]) => id === tab)[2];
    const list = rows.filter(fn);
    if (!list.length) {
        app.innerHTML = `<div class="panel-dark portal-card empty"><p>${tab === "done" ? "No finished courses yet. Keep going!" : "Nothing in progress right now."}</p></div>`;
        return;
    }
    app.innerHTML = `<div class="learn-grid">${list.map((r) => `
      <article class="panel-dark l-card">
        ${thumbHTML(r.course)}
        <div class="l-body">
          <h3>${esc(r.course.title)}</h3>
          <p>${esc(r.course.teaser || r.course.summary || "")}</p>
          <div class="meter" style="--pct:${r.prog.pct}%"><span></span></div>
          <div class="l-foot">
            <span class="l-pct">${r.prog.pct}% · ${r.prog.done}/${r.prog.total} activities</span>
            <button class="btn btn-gold btn-sm" data-open="${esc(r.course.id)}" type="button">${isDone(r) ? "Review" : (r.prog.done ? "Continue" : "Start")}</button>
          </div>
        </div>
      </article>`).join("")}</div>`;
}

function open(id, startItemId) {
    const r = rows.find((x) => x.course.id === id);
    if (!r) return;
    openCourse({
        user, profile, course: r.course, enr: r.enr, startItemId,
        onChange: () => { r.prog = courseProgress(r.enr, r.mods); render(); }
    });
}

document.addEventListener("click", (e) => {
    const t = e.target.closest("[data-tab]");
    if (t) { tab = t.dataset.tab; render(); return; }
    const b = e.target.closest("[data-open]");
    if (b) open(b.dataset.open);
});

render();
const want = new URLSearchParams(location.search).get("open");
if (want) open(want);
