<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<t:portal title="Course editor" area="teacher" active="My Courses" script="teacher-editor">
<main class="container portal-main">
    <div id="app"><p>Loading the course editor...</p></div>
</main>
</t:portal>
