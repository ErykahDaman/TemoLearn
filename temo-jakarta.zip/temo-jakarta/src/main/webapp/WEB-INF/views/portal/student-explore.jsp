<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<t:portal title="Explore" area="student" active="Explore" script="student-explore">
<main class="container portal-main">
    <div class="page-head"><h1>Explore</h1></div>
    <div class="toolbar">
        <input class="search-bar" id="q" type="search" placeholder="Search courses by name or topic…" aria-label="Search courses">
        <div class="filters" id="filters"></div>
    </div>
    <div id="app"><p>Loading courses...</p></div>
</main>
</t:portal>
