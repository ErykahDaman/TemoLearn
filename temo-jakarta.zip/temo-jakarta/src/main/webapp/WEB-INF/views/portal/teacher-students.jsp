<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<t:portal title="My Students" area="teacher" active="My Students" script="teacher-students">
<main class="container portal-main">
    <div class="page-head"><h1>My Students</h1></div>
    <div id="app"><p>Loading...</p></div>
</main>
</t:portal>
