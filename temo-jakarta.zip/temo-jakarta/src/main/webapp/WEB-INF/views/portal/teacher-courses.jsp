<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<t:portal title="My Courses" area="teacher" active="My Courses" script="teacher-courses">
<main class="container portal-main">
  <div class="page-head">
    <h1>My Courses</h1>
    <div class="btn-row">
      <button class="btn btn-gold" id="newBtn" type="button">＋ New course</button>
      <button class="btn btn-ghost" id="syllabusBtn" type="button">📚 Start from the syllabus</button>
    </div>
  </div>
  <div class="panel-dark portal-card" id="list"><p>Loading your courses...</p></div>
</main>
</t:portal>
