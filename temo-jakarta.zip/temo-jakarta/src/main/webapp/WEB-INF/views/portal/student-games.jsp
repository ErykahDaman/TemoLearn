<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<t:portal title="Games" area="student" active="Games" script="student-games">
<main class="container portal-main">
    <div class="page-head"><h1>Games</h1></div>
    <p class="muted" style="margin-top:-8px;max-width:60ch">Learn by playing. Each Temo-Learn course has its own game, and your teachers add more here too.</p>

    <h2 style="margin-top:26px">Ready to play</h2>
    <div id="playable"><p>Loading games...</p></div>

    <div class="panel-dark portal-card section-gap">
        <h2>Temo-Learn games</h2>
        <p class="muted" style="margin-top:0">One game for each of the ten courses. They'll appear in the list above as soon as they're built.</p>
        <div class="game-grid" id="builtin"></div>
    </div>
</main>
</t:portal>
