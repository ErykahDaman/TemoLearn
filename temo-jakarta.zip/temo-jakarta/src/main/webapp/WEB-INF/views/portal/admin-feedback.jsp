<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<t:portal title="Feedback" area="admin" active="Feedback" script="admin-feedback">
<main class="container portal-main">
    <div class="page-head"><h1>Feedback</h1></div>
    <div class="toolbar">
        <div class="seg" id="seg"></div>
        <input class="a-input" id="q" type="search" placeholder="Search messages…" aria-label="Search feedback">
    </div>
    <div id="app"><p>Loading messages...</p></div>
</main>
</t:portal>
