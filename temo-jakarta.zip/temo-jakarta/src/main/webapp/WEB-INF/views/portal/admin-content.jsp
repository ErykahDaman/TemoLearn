<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<t:portal title="Content" area="admin" active="Content" script="admin-content">
<main class="container portal-main">
    <div class="page-head"><h1>Content</h1></div>
    <div class="tabs" id="tabs"></div>
    <div class="toolbar"><input class="a-input" id="q" type="search" placeholder="Search…" aria-label="Search"></div>
    <div class="panel-dark" style="padding:8px 6px">
        <div class="table-wrap" id="app"><p style="padding:20px">Loading...</p></div>
    </div>
    <p class="hint" style="margin-top:14px">Admins can publish, unpublish or remove any course or game. Teachers edit their own content from the teacher portal.</p>
</main>
</t:portal>
