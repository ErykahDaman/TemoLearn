<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<t:portal title="Admin Overview" area="admin" active="Overview" script="admin">
<main class="container portal-main">
    <div id="app"><p>Loading the console...</p></div>
</main>
</t:portal>
