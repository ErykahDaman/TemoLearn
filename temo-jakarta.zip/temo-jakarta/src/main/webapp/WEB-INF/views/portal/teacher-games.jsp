<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<t:portal title="My Games" area="teacher" active="My Games" script="teacher-games">
<main class="container portal-main">
  <div class="page-head">
    <h1>My Games</h1>
    <button class="btn btn-gold" id="addBtn" type="button">＋ Add game</button>
  </div>

  <div class="panel-dark portal-card" style="margin-bottom:24px">
    <h2>How it works</h2>
    <ol class="steps">
      <li>Host your game somewhere that gives you an <strong>embed code</strong> (itch.io, GDevelop, Construct, Scratch and similar sites all do).</li>
      <li>Click <strong>Add game</strong> and paste the code or the link. We only use the link inside it.</li>
      <li>In the course editor, add a <strong>Game</strong> activity and pick your game.</li>
    </ol>
  </div>

  <div id="mine"><p>Loading your games...</p></div>

  <div class="panel-dark portal-card section-gap">
    <h2>Temo-Learn games</h2>
    <p style="margin-top:0">The ten planned games, one per course. You can already attach them from the course editor, and each will play as soon as it's built.</p>
    <div class="builtin-list" id="builtin"></div>
  </div>
</main>
</t:portal>
