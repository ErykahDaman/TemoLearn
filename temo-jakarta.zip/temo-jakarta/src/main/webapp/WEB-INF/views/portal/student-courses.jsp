<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<t:portal title="My Learning" area="student" active="My Learning" script="student-courses">
<main class="container portal-main">
    <div class="page-head">
        <h1>My Learning</h1>
        <a class="btn btn-olive" href="portal/student/explore">＋ Find a course</a>
    </div>
    <div class="tabs" id="tabs"></div>
    <div id="app"><p>Loading your courses...</p></div>
</main>
</t:portal>
