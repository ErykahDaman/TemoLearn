<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<t:portal title="Users" area="admin" active="Users" script="admin-users">
<main class="container portal-main">
    <div class="page-head">
        <h1>Users</h1>
        <button class="btn btn-sage" id="newTeacher" type="button">＋ Create teacher</button>
    </div>

    <div class="toolbar">
        <input class="a-input" id="q" type="search" placeholder="Search by name or email…" aria-label="Search users">
        <div class="seg" id="roleSeg"></div>
    </div>

    <div class="panel-dark" style="padding:8px 6px">
        <div class="table-wrap" id="app"><p style="padding:20px">Loading users...</p></div>
    </div>
    <p class="hint" style="margin-top:14px">Disabling an account signs that person out of the portal and stops them logging in. Accounts can't be deleted from here (that needs the Firebase console).</p>
</main>
</t:portal>
