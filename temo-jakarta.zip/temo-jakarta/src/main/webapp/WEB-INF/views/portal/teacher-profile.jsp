<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<t:portal title="Profile" area="teacher" active="Profile" script="teacher-profile">
<main class="container portal-main">
    <div class="page-head"><h1>Profile</h1></div>
    <div id="app"></div>
</main>
</t:portal>
