<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<t:portal title="Profile" area="student" active="Profile" script="student-profile">
<main class="container portal-main">
    <div class="page-head"><h1>Profile</h1></div>
    <div id="app"><p>Loading your profile...</p></div>
</main>
</t:portal>
