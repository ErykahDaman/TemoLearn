<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<t:portal title="Home" area="student" active="Home" script="student">
<main class="container portal-main">
    <div id="app"><p>Loading your dashboard...</p></div>
</main>
</t:portal>
