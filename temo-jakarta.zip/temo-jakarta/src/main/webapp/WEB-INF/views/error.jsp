<%@ page contentType="text/html;charset=UTF-8" isErrorPage="true" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<c:set var="code" value="${pageContext.errorData.statusCode}"/>
<t:site title="${code == 404 ? 'Page not found' : 'Something went wrong'}" bodyClass="page-error">
  <main>
    <section class="page-hero">
      <div class="container">
        <span class="hud-chip"><c:out value="${empty code or code == 0 ? 500 : code}"/></span>
        <h1 class="gold-text"><c:out value="${code == 404 ? 'Page not found' : 'Something went wrong'}"/></h1>
        <p><c:out value="${code == 404 ? 'That page does not exist, or it has moved.' : 'Please try again in a moment. If it keeps happening, contact us.'}"/></p>
        <p><a class="btn btn-gold" href="./">Back to the home page</a></p>
      </div>
    </section>
  </main>
</t:site>
