<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<t:site title="Log in" bodyClass="auth-page page-login">
  <main>
    <div class="panel frame">
      <img class="frame-logo" src="images/logo-mark.png" alt="Temo-Learn">
      <h1>Welcome back</h1>
      <p class="sub">Log in to continue learning.</p>
      <form id="form" method="post" action="login">
        <input type="hidden" name="_csrf" value="<c:out value='${csrf}'/>">
        <input type="hidden" name="next" value="<c:out value='${next}'/>">
        <div class="field"><label for="email">Email</label><input id="email" name="email" type="email" autocomplete="email" required value="<c:out value='${email}'/>"></div>
        <div class="field"><label for="password">Password</label><input id="password" name="password" type="password" autocomplete="current-password" required></div>
        <c:if test="${not empty error}"><p class="form-msg error" role="alert"><c:out value="${error}"/></p></c:if>
        <button class="btn btn-gold btn-block" id="submitBtn" type="submit">Log in</button>
      </form>
      <p class="form-alt">Forgot your password? <a href="contact">Contact us</a> and an admin will reset it.</p>
      <p class="form-alt">New here? <a href="signup">Create an account</a></p>
    </div>
  </main>
</t:site>
