<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<t:site title="About" bodyClass="page-about" active="about">
  <main>
    <section class="page-hero">
      <div class="container">
        <span class="hud-chip">Our story</span>
        <h1 class="gold-text">About Temo-Learn</h1>
        <p>Temo is Setswana for farming. We turn sustainable-farming knowledge into practical courses and games for Botswana's farmers, students and young innovators.</p>
      </div>
    </section>

    <section class="section">
      <div class="container" style="max-width:820px">
        <div class="panel prose">
          <img class="about-logo" src="images/logo-full.png" alt="Temo-Learn: Learn, Grow, Thrive">
          <h2>Our mission</h2>
          <p>Farming in drylands is changing fast. The central idea behind Temo-Learn is simple: teach people to grow more intelligently with limited water, extreme heat, variable rainfall and constrained resources.</p>
          <p>Every course combines scientific foundations, practical local applications and a game that lets you experiment safely before applying a technique in the real world. Where an idea is still experimental, like electroculture, we teach it as something to test properly, not as a promise.</p>
        </div>
      </div>
    </section>

    <section class="section" style="padding-top:0">
      <div class="container">
        <div class="section-head">
          <span class="hud-chip">What we teach</span>
          <h2 style="margin-top:14px">Four principles</h2>
        </div>
        <div class="grid-4">
          <div class="panel-dark quest-card"><div class="q-icon">💧</div><h3>Water-first farming</h3><p>Efficient irrigation, rainwater capture, water reuse and responsible borehole management.</p></div>
          <div class="panel-dark quest-card"><div class="q-icon">🌡️</div><h3>Heat-resilient production</h3><p>Shade, passive cooling, insulation and solar-powered systems.</p></div>
          <div class="panel-dark quest-card"><div class="q-icon">🌱</div><h3>Living soil ecosystems</h3><p>Organic matter, compost, soil cover, biodiversity and nutrient cycling.</p></div>
          <div class="panel-dark quest-card"><div class="q-icon">🎮</div><h3>Learn by playing</h3><p>Simulations, strategy puzzles, resource management and consequence-driven decisions.</p></div>
        </div>
      </div>
    </section>

    <section class="section" style="padding-top:0">
      <div class="container">
        <div class="section-head">
          <span class="hud-chip">Choose your role</span>
          <h2 style="margin-top:14px">Who learns here</h2>
        </div>
        <div class="grid-3">
          <div class="panel-dark quest-card"><div class="q-icon">🎒</div><h3>Learner</h3><p>Sign up, explore the courses, play the games and track your progress module by module.</p></div>
          <div class="panel-dark quest-card"><div class="q-icon">📜</div><h3>Teacher</h3><p>Build courses and modules, add quizzes and publish when they're ready. Teacher accounts are set up by an admin.</p></div>
          <div class="panel-dark quest-card"><div class="q-icon">🗝️</div><h3>Keeper</h3><p>Admins look after the platform: managing accounts, courses and messages so everything runs smoothly.</p></div>
        </div>
      </div>
    </section>

    <section class="section" style="padding-top:0">
      <div class="container">
        <div class="panel-dark cta">
          <h2>Learn. Grow. Thrive.</h2>
          <p>Create an account, pick your first course and start growing.</p>
          <a class="btn btn-gold" href="signup">Sign up</a>
          <a class="btn btn-ghost" href="contact">Ask us something</a>
        </div>
      </div>
    </section>
  </main>
</t:site>
