<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<t:site title="Sign up" bodyClass="auth-page page-signup">
  <main>
    <div class="panel frame">
      <img class="frame-logo" src="images/logo-mark.png" alt="Temo-Learn">
      <h1>Begin your journey</h1>
      <p class="sub">Create your account. Choose how you'll use Temo-Learn.</p>
      <form id="form" method="post" action="signup">
        <input type="hidden" name="_csrf" value="<c:out value='${csrf}'/>">
        <c:choose>
          <c:when test="${teachersOpen}">
            <fieldset class="role-pick">
              <legend>I want to&hellip;</legend>
              <label class="role-opt">
                <input type="radio" name="role" value="student" <c:if test="${role != 'teacher'}">checked</c:if>>
                <span class="role-card"><span class="role-icon">🌱</span><strong>Learn</strong><small>Take courses and play the farming games</small></span>
              </label>
              <label class="role-opt">
                <input type="radio" name="role" value="teacher" <c:if test="${role == 'teacher'}">checked</c:if>>
                <span class="role-card"><span class="role-icon">🎓</span><strong>Teach</strong><small>Build courses, add quizzes and enrol learners</small></span>
              </label>
            </fieldset>
          </c:when>
          <c:otherwise><input type="hidden" name="role" value="student"></c:otherwise>
        </c:choose>
        <div class="field"><label for="name">Full name</label><input id="name" name="name" autocomplete="name" maxlength="100" required value="<c:out value='${name}'/>"></div>
        <div class="field"><label for="email">Email</label><input id="email" name="email" type="email" autocomplete="email" required value="<c:out value='${email}'/>"></div>
        <div class="field"><label for="password">Password</label><input id="password" name="password" type="password" minlength="8" autocomplete="new-password" required>
          <p class="hint">At least 8 characters.</p></div>
        <div class="field"><label for="confirm">Confirm password</label><input id="confirm" name="confirm" type="password" minlength="8" autocomplete="new-password" required></div>
        <c:if test="${not empty error}"><p class="form-msg error" role="alert"><c:out value="${error}"/></p></c:if>
        <button class="btn btn-gold btn-block" id="submitBtn" type="submit">Create account</button>
      </form>
      <p class="form-alt">Already have an account? <a href="login">Log in</a></p>
    </div>
  </main>
</t:site>
