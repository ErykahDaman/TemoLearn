<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<t:site title="Learn · Grow · Thrive" bodyClass="page-home" active="home"
        description="Temo-Learn is a sustainable agriculture academy for Botswana: practical courses and farming games for water-wise, heat-resilient growing.">
  <main>
    <section class="hero">
      <div class="container hero-grid">
        <div>
          <span class="hud-chip">Learn · Grow · Thrive</span>
          <h1 class="gold-text">Learn the future of farming in Botswana</h1>
          <p class="lead">Temo-Learn is a sustainable agriculture academy. Follow practical courses, play ten farming games and learn to grow more with limited water, extreme heat and variable rain.</p>
          <div class="hero-actions">
            <a class="btn btn-gold" href="signup">Begin your journey</a>
            <a class="btn btn-ghost" href="courses">Browse courses</a>
          </div>
          <div class="hero-stats">
            <span class="hud-chip"><c:out value="${courseCount}"/> Courses</span>
            <span class="hud-chip">10 Games</span>
            <span class="hud-chip">Built for Botswana</span>
          </div>
        </div>

        <aside class="panel-dark float" aria-label="Sample quest log">
          <p class="hud-label">// Sample quest log</p>
          <div class="quest-item">
            <div class="quest-top"><span>💧 Hydroponics in the Kalahari</span><span>60%</span></div>
            <div class="meter" style="--pct:60%"><span></span></div>
          </div>
          <div class="quest-item">
            <div class="quest-top"><span>☀️ Solar-Powered Irrigation</span><span>35%</span></div>
            <div class="meter" style="--pct:35%"><span></span></div>
          </div>
          <div class="quest-item">
            <div class="quest-top"><span>🌧️ Rainwater Harvesting</span><span>15%</span></div>
            <div class="meter" style="--pct:15%"><span></span></div>
          </div>
          <div class="divider">❧</div>
          <p class="hud-label" style="margin:0">🎮 Hydro-Hero: Reservoir Rescue is ready to play</p>
        </aside>
      </div>
    </section>

    <section class="section">
      <div class="container">
        <div class="section-head">
          <span class="hud-chip">Your adventure</span>
          <h2 style="margin-top:14px">Three ways to learn</h2>
          <p>Every course pairs science and practical skills with a game where you can experiment safely.</p>
        </div>
        <div class="grid-3">
          <div class="panel-dark quest-card">
            <div class="q-icon">📜</div>
            <h3>Courses</h3>
            <p>Practical courses with four modules each, from hydroponics and soil regeneration to cold-chain agribusiness.</p>
          </div>
          <div class="panel-dark quest-card">
            <div class="q-icon">🎮</div>
            <h3>Game mode</h3>
            <p>Each course has a matching mini-game. Test decisions and see the consequences before trying them on a real farm.</p>
          </div>
          <div class="panel-dark quest-card">
            <div class="q-icon">🌍</div>
            <h3>Built for Botswana</h3>
            <p>Scenarios set in Maun, Ghanzi, Sandveld, Pandamatenga, Kasane and Gaborone, so the lessons fit real conditions.</p>
          </div>
        </div>
      </div>
    </section>

    <section class="section" style="padding-top:0">
      <div class="container">
        <div class="section-head">
          <span class="hud-chip">Featured courses</span>
          <h2 style="margin-top:14px">A taste of what's inside</h2>
          <p>Open any course to see its syllabus. Full lessons unlock when you sign in.</p>
        </div>
        <div class="grid-courses">
          <c:forEach var="course" items="${courses}"><t:course-card course="${course}" mode="link"/></c:forEach>
        </div>
        <p style="text-align:center;margin-top:34px"><a class="btn btn-ghost" href="courses">See all <c:out value="${courseCount}"/> courses</a></p>
      </div>
    </section>

    <section class="section" style="padding-top:0">
      <div class="container">
        <div class="section-head">
          <span class="hud-chip">The Temo-Learn way</span>
          <h2 style="margin-top:14px">Think like a farmer-scientist</h2>
          <p>Every challenge, in every course and game, comes back to three questions.</p>
        </div>
        <div class="grid-3">
          <div class="panel-dark quest-card"><div class="q-icon">🔍</div><h3>What is happening?</h3><p>Read the soil, crop, water, energy or market indicators.</p></div>
          <div class="panel-dark quest-card"><div class="q-icon">🧪</div><h3>Why is it happening?</h3><p>Find the underlying cause instead of guessing.</p></div>
          <div class="panel-dark quest-card"><div class="q-icon">🌱</div><h3>What's the most resilient response?</h3><p>Choose the fix that balances productivity, water, heat, cost and long-term sustainability.</p></div>
        </div>
      </div>
    </section>

    <section class="section" style="padding-top:0">
      <div class="container">
        <div class="panel-dark cta">
          <h2>Ready to start growing?</h2>
          <p>Create an account to open the full lessons and play the games.</p>
          <a class="btn btn-gold" href="signup">Create my account</a>
        </div>
      </div>
    </section>
  </main>
</t:site>
