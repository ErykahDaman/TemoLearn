<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<t:site title="Contact" bodyClass="page-contact" active="contact">
  <main>
    <section class="page-hero">
      <div class="container">
        <span class="hud-chip">Get in touch</span>
        <h1 class="gold-text">Contact us</h1>
        <p>Questions, ideas or bugs? Send a message and we'll get back to you.</p>
      </div>
    </section>

    <section class="section">
      <div class="container split">
        <div>
          <div class="panel-dark info-card"><h3>📜 Questions about a course?</h3><p>Tell us which course and what you'd like to know.</p></div>
          <div class="panel-dark info-card"><h3>🎓 Want to teach?</h3><p>You can sign up as a teacher in a minute: choose "Teach" on the sign-up page. Questions first? Message us with what you'd like to teach.</p></div>
          <div class="panel-dark info-card"><h3>🐞 Found a bug?</h3><p>Tell us what you clicked and what happened, and we'll fix it.</p></div>
        </div>
        <div class="panel">
          <h2>Write your message</h2>
          <form id="form" method="post" action="contact">
            <input type="hidden" name="_csrf" value="<c:out value='${csrf}'/>">
            <div class="field"><label for="name">Your name</label><input id="name" name="name" maxlength="100" required value="<c:out value='${empty name ? user.fullName : name}'/>"></div>
            <div class="field"><label for="email">Email</label><input id="email" name="email" type="email" maxlength="150" required value="<c:out value='${empty email ? user.email : email}'/>"></div>
            <div class="field">
              <label for="subject">Topic</label>
              <select id="subject" name="subject">
                <option>Question about a course</option>
                <option>I want to teach on Temo-Learn</option>
                <option>Report a problem</option>
                <option>Something else</option>
              </select>
            </div>
            <div class="field"><label for="message">Message</label><textarea id="message" name="message" maxlength="2000" required><c:out value="${message}"/></textarea></div>
            <input class="hp" name="website" tabindex="-1" autocomplete="off" aria-hidden="true">
            <c:if test="${not empty error}"><p class="form-msg error" role="alert"><c:out value="${error}"/></p></c:if>
            <c:if test="${sent}"><p class="form-msg ok" role="status">Message sent. Thank you, we'll be in touch.</p></c:if>
            <button class="btn btn-gold btn-block" id="send" type="submit">Send message</button>
          </form>
        </div>
      </div>
    </section>
  </main>
</t:site>
