<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<t:site title="Courses" bodyClass="page-courses" active="courses" script="courses">
  <main>
    <section class="page-hero">
      <div class="container">
        <span class="hud-chip">Course library</span>
        <h1 class="gold-text">Courses</h1>
        <p>Practical courses, four modules each. Click any card to open its syllabus and see exactly what you'll learn.</p>
      </div>
    </section>

    <section class="section">
      <div class="container">
        <div class="filters" id="filters"></div>
        <div class="grid-courses" id="grid">
          <c:forEach var="course" items="${courses}"><t:course-card course="${course}" mode="expand"/></c:forEach>
        </div>
        <c:if test="${empty courses}"><p>No courses have been published yet. Please check back soon.</p></c:if>
      </div>
    </section>
  </main>
</t:site>
