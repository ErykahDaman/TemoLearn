<%@ tag description="Layout for every signed-in page (student, teacher, admin)" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<%@ attribute name="title" required="true" %>
<%@ attribute name="area" required="true" description="student, teacher or admin" %>
<%@ attribute name="active" required="true" description="Label of the nav link to highlight" %>
<%@ attribute name="script" required="true" description="Name of the file in js/pages/ for this page" %>
<c:set var="isStudent" value="${area == 'student'}"/>
<c:set var="isAdmin" value="${area == 'admin'}"/>
<c:set var="profileHref" value="${isAdmin ? 'portal/admin' : (isStudent ? 'portal/student/profile' : 'portal/teacher/profile')}"/>
<!DOCTYPE html>
<html lang="en" data-mode="${area == 'teacher' and user.themeMode == 'light' ? 'light' : 'dark'}">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <base href="${pageContext.request.contextPath}/">
  <title><c:out value="${title}"/> | Temo-Learn</title>
  <c:if test="${area == 'teacher'}"><script src="js/mode-init.js"></script></c:if>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,400;0,600;1,400&display=swap" rel="stylesheet">
  <link rel="icon" href="images/favicon.png">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/portal.css">
  <c:choose>
    <c:when test="${isStudent}"><link rel="stylesheet" href="css/student.css"></c:when>
    <c:when test="${isAdmin}"><link rel="stylesheet" href="css/admin.css"></c:when>
    <c:otherwise>
      <link rel="stylesheet" href="css/teacher-theme.css">
      <link rel="stylesheet" href="css/teacher-editor.css">
      <link rel="stylesheet" href="css/teacher-extra.css">
      <link rel="stylesheet" href="css/teacher-light.css">
    </c:otherwise>
  </c:choose>
</head>
<body class="page-portal theme-${area}">

<header class="nav">
  <div class="container nav-inner">
    <a class="brand" href="./" aria-label="Temo-Learn home">
      <img class="brand-logo" src="images/logo-mark.png" alt="">
      <span class="brand-name">Temo-Learn</span>
    </a>
    <button class="nav-toggle" id="navToggle" aria-label="Menu" aria-expanded="false" type="button">☰</button>
    <nav class="nav-links" id="navLinks">
      <c:choose>
        <c:when test="${isStudent}">
          <a${active == 'Home' ? ' class="active"' : ''} href="portal/student">Home</a>
          <a${active == 'My Learning' ? ' class="active"' : ''} href="portal/student/courses">My Learning</a>
          <a${active == 'Explore' ? ' class="active"' : ''} href="portal/student/explore">Explore</a>
          <a${active == 'Games' ? ' class="active"' : ''} href="portal/student/games">Games</a>
          <a${active == 'Profile' ? ' class="active"' : ''} href="portal/student/profile">Profile</a>
        </c:when>
        <c:when test="${isAdmin}">
          <a${active == 'Overview' ? ' class="active"' : ''} href="portal/admin">Overview</a>
          <a${active == 'Users' ? ' class="active"' : ''} href="portal/admin/users">Users</a>
          <a${active == 'Content' ? ' class="active"' : ''} href="portal/admin/content">Content</a>
          <a${active == 'Feedback' ? ' class="active"' : ''} href="portal/admin/feedback">Feedback</a>
        </c:when>
        <c:otherwise>
          <a${active == 'Home' ? ' class="active"' : ''} href="portal/teacher">Home</a>
          <a${active == 'My Courses' ? ' class="active"' : ''} href="portal/teacher/courses">My Courses</a>
          <a${active == 'My Games' ? ' class="active"' : ''} href="portal/teacher/games">My Games</a>
          <a${active == 'My Students' ? ' class="active"' : ''} href="portal/teacher/students">My Students</a>
          <a${active == 'Profile' ? ' class="active"' : ''} href="portal/teacher/profile">Profile</a>
        </c:otherwise>
      </c:choose>
      <div class="nav-auth">
        <a class="who-chip" href="${profileHref}" title="My profile">
          <t:avatar u="${user}" size="32"/><span class="who"><c:out value="${user.fullName}"/></span>
        </a>
        <form class="inline-form" method="post" action="logout">
          <input type="hidden" name="_csrf" value="<c:out value='${csrf}'/>">
          <button class="btn btn-ghost btn-sm" type="submit">Logout</button>
        </form>
      </div>
    </nav>
  </div>
</header>

<jsp:doBody/>

<%-- Who is signed in, for the page's JavaScript. Json.stringify escapes < > & so this cannot close the tag. --%>
<script id="boot" type="application/json"><c:out value="${boot}" escapeXml="false"/></script>
<script type="module" src="js/pages/${script}.js"></script>
</body>
</html>
