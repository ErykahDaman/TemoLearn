<%@ tag description="A course card for the public pages" pageEncoding="UTF-8" body-content="empty" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ attribute name="course" required="true" type="java.util.Map" %>
<%@ attribute name="mode" description="link (whole card links to the courses page) or expand (opens its syllabus)" %>
<c:set var="expand" value="${mode == 'expand'}"/>
<c:set var="hasImg" value="${fn:startsWith(course.thumbnail, 'data:image/') or fn:startsWith(course.thumbnail, 'https:')}"/>
<c:set var="thumb">
  <div class="course-thumb">
    <c:choose>
      <c:when test="${hasImg}"><img src="<c:out value='${course.thumbnail}'/>" alt="" loading="lazy"></c:when>
      <c:otherwise><span class="course-icon"><c:out value="${empty course.icon ? '📜' : course.icon}"/></span></c:otherwise>
    </c:choose>
    <span class="hud-chip"><c:out value="${empty course.category ? 'General' : course.category}"/></span>
  </div>
</c:set>
<c:set var="body">
  <div class="course-body">
    <c:if test="${not empty course.number}"><span class="course-num">Course <c:out value="${course.number}"/></span></c:if>
    <h3><c:out value="${course.title}"/></h3>
    <p><c:out value="${course.summary}"/></p>
    <div class="course-foot">
      <span><c:out value="${course.level}"/><c:if test="${not empty course.level and not empty course.hours}"> · </c:if><c:out value="${course.hours}"/></span>
      <span class="more">Syllabus</span>
    </div>
  </div>
</c:set>
<c:choose>
  <c:when test="${expand}">
    <article class="course-card" data-id="<c:out value='${course.id}'/>" data-category="<c:out value='${empty course.category ? "General" : course.category}'/>">
      <div class="course-head" tabindex="0" role="button" aria-expanded="false">${thumb}${body}</div>
      <div class="course-details">
        <div class="details-inner">
          <div class="details-grid">
            <div class="details-main">
              <p><c:out value="${empty course.description ? course.summary : course.description}"/></p>
              <div class="meta-row">
                <c:if test="${not empty course.level}"><span class="meta-chip">🎓 <c:out value="${course.level}"/></span></c:if>
                <c:if test="${not empty course.hours}"><span class="meta-chip">⏱ <c:out value="${course.hours}"/></span></c:if>
                <span class="meta-chip">📚 <c:out value="${fn:length(course.modules)}"/> modules</span>
              </div>
              <c:if test="${not empty course.output}">
                <div class="detail-box"><h4>🎯 What you'll make</h4><p><c:out value="${course.output}"/></p></div>
              </c:if>
              <c:if test="${not empty course.game}">
                <div class="detail-box"><h4>🎮 Matching game</h4><p><c:out value="${course.game}"/></p></div>
              </c:if>
              <div class="details-cta">
                <c:choose>
                  <c:when test="${not empty user}"><a class="btn btn-gold" href="<c:out value='${homeRel}'/>">Go to my dashboard</a></c:when>
                  <c:otherwise>
                    <a class="btn btn-gold" href="signup">Sign up to start</a>
                    <a class="btn btn-ghost" href="login">Log in</a>
                  </c:otherwise>
                </c:choose>
              </div>
            </div>
            <div class="details-side">
              <h4>Syllabus</h4>
              <ol class="module-list">
                <c:forEach var="m" items="${course.modules}" varStatus="st">
                  <li>
                    <span class="module-num">${st.count}</span>
                    <div>
                      <h4><c:out value="${m.title}"/></h4>
                      <c:if test="${not empty m.points}">
                        <ul><c:forEach var="p" items="${m.points}"><li><c:out value="${p}"/></li></c:forEach></ul>
                      </c:if>
                    </div>
                  </li>
                </c:forEach>
                <c:if test="${empty course.modules}"><li><span class="module-locked">The syllabus for this course is on its way.</span></li></c:if>
              </ol>
              <c:if test="${empty user}"><p class="module-locked">🔒 Full lessons unlock when you sign in.</p></c:if>
            </div>
          </div>
        </div>
      </div>
    </article>
  </c:when>
  <c:otherwise>
    <a class="course-card" href="courses#<c:out value='${course.id}'/>" data-id="<c:out value='${course.id}'/>">${thumb}${body}</a>
  </c:otherwise>
</c:choose>
