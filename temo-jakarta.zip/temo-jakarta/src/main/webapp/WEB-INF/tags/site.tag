<%@ tag description="Layout for the public pages" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ taglib prefix="t" tagdir="/WEB-INF/tags" %>
<%@ attribute name="title" required="true" %>
<%@ attribute name="bodyClass" %>
<%@ attribute name="description" %>
<%@ attribute name="active" %>
<%@ attribute name="script" description="Name of a file in js/pages/ to load (optional)" %>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <base href="${pageContext.request.contextPath}/">
  <title><c:out value="${title}"/> | Temo-Learn</title>
  <c:if test="${not empty description}"><meta name="description" content="<c:out value='${description}'/>"></c:if>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,400;0,600;1,400&display=swap" rel="stylesheet">
  <link rel="icon" href="images/favicon.png">
  <link rel="stylesheet" href="css/style.css">
</head>
<body class="<c:out value='${bodyClass}'/>">

  <header class="nav">
    <div class="container nav-inner">
      <a class="brand" href="./" aria-label="Temo-Learn home">
        <img class="brand-logo" src="images/logo-mark.png" alt="">
        <span class="brand-name">Temo-Learn</span>
      </a>
      <button class="nav-toggle" id="navToggle" aria-label="Menu" aria-expanded="false" type="button">☰</button>
      <nav class="nav-links" id="navLinks">
        <a${active == 'home' ? ' class="active"' : ''} href="./">Home</a>
        <a${active == 'courses' ? ' class="active"' : ''} href="courses">Courses</a>
        <a${active == 'about' ? ' class="active"' : ''} href="about">About Us</a>
        <a${active == 'contact' ? ' class="active"' : ''} href="contact">Contact Us</a>
        <div class="nav-auth" id="nav-auth">
          <c:choose>
            <c:when test="${not empty user}">
              <a class="btn btn-gold btn-sm" href="<c:out value='${homeRel}'/>">My Quest Log</a>
              <form class="inline-form" method="post" action="logout">
                <input type="hidden" name="_csrf" value="<c:out value='${csrf}'/>">
                <button class="btn btn-ghost btn-sm" type="submit">Logout</button>
              </form>
            </c:when>
            <c:otherwise>
              <a class="btn btn-gold btn-sm" href="signup">Sign Up</a>
              <a class="btn btn-ghost btn-sm" href="login">Login</a>
            </c:otherwise>
          </c:choose>
        </div>
      </nav>
    </div>
  </header>

  <jsp:doBody/>

  <footer class="footer">
    <div class="container footer-inner">
      <div>
        <strong>Temo-Learn</strong>
        <p>Sustainable farming for Botswana, learned by playing.</p>
      </div>
      <nav class="footer-links">
        <a href="./">Home</a><a href="courses">Courses</a><a href="about">About Us</a><a href="contact">Contact Us</a>
        <c:if test="${empty user}"><a href="signup">Sign Up</a><a href="login">Login</a></c:if>
      </nav>
    </div>
    <p class="footer-note">© <c:out value="${year}"/> Temo-Learn · Learn · Grow · Thrive</p>
  </footer>

  <script type="module" src="js/pages/site.js"></script>
  <c:if test="${not empty script}"><script type="module" src="js/pages/${script}.js"></script></c:if>
</body>
</html>
