<%@ tag description="Round profile picture: uploaded photo, else chosen avatar, else first letter" pageEncoding="UTF-8" body-content="empty" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ attribute name="u" required="true" type="java.util.Map" %>
<%@ attribute name="size" type="java.lang.Integer" %>
<c:set var="sz" value="${empty size ? 40 : size}"/>
<c:set var="fs" value="${(sz div 2) - ((sz div 2) mod 1)}"/>
<c:choose>
  <c:when test="${fn:startsWith(u.photo, 'data:image/')}">
    <span class="avatar" style="width:${sz}px;height:${sz}px;font-size:${fs}px"><img src="<c:out value='${u.photo}'/>" alt=""></span>
  </c:when>
  <c:otherwise>
    <c:set var="col" value="${applicationScope.avatarColors[u.avatar]}"/>
    <c:set var="letter" value="${empty fn:trim(u.fullName) ? '?' : fn:toUpperCase(fn:substring(fn:trim(u.fullName), 0, 1))}"/>
    <span class="avatar" style="width:${sz}px;height:${sz}px;font-size:${fs}px;background:${empty col ? '#6A3E0D' : col}"><c:out value="${empty col ? letter : u.avatar}"/></span>
  </c:otherwise>
</c:choose>
